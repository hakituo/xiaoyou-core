# 配置管理器模块
import os
import yaml
from typing import Dict, Optional, Any
from pathlib import Path
from core.utils.logger import get_logger

logger = get_logger("CONFIG_MANAGER")


class ConfigManager:
    """
    配置管理器
    负责加载、管理和提供应用程序配置
    """
    
    def __init__(self):
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {
            "voice": {
                "tts": {
                    "enabled": True,
                    "default_engine": "coqui",
                    "use_proxy": False
                },
                "stt": {
                    "enabled": True,
                    "default_model": "whisper",
                    "use_proxy": False
                }
            },
            "image": {
                "enabled": True,
                "default_model": "stable-diffusion",
                "use_proxy": False
            },
            "multimodal": {
                "enabled": True
            }
        }
        base_dir = Path(__file__).resolve().parent.parent
        self._config_paths = [
            base_dir / "config" / "yaml" / "app.yaml",
            base_dir / "config" / "yaml" / "env.yaml",
        ]
        self._initialized = False
    
    def initialize(self):
        """
        初始化配置管理器
        加载配置文件
        """
        if self._initialized:
            return
        
        logger.info("正在初始化配置管理器...")
        
        # 首先加载默认配置
        self._config = self._deep_copy(self._default_config)
        
        # 加载配置文件
        for config_path in self._config_paths:
            if config_path.exists():
                try:
                    with open(config_path, "r", encoding="utf-8") as f:
                        config_data = yaml.safe_load(f)
                        if config_data:
                            self._merge_config(self._config, config_data)
                            logger.info(f"已加载配置文件: {config_path}")
                except Exception as e:
                    logger.error(f"加载配置文件失败 {config_path}: {str(e)}")
        
        # 尝试加载.env文件
        self._load_env_vars()
        
        self._initialized = True
        logger.info("配置管理器初始化完成")
    
    def _load_env_vars(self):
        """
        从环境变量加载配置
        """
        # 这里可以添加从环境变量加载配置的逻辑
        # 例如：检查特定前缀的环境变量并更新配置
        pass
    
    def _deep_copy(self, obj: Any) -> Any:
        """
        深度复制对象
        """
        if isinstance(obj, dict):
            return {k: self._deep_copy(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._deep_copy(item) for item in obj]
        else:
            return obj
    
    def _merge_config(self, base: Dict[str, Any], override: Dict[str, Any]):
        """
        合并配置字典
        """
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._merge_config(base[key], value)
            else:
                base[key] = value
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """
        获取配置值
        
        Args:
            key_path: 配置键路径，使用点号分隔（如 "voice.tts.enabled"）
            default: 默认值
            
        Returns:
            配置值或默认值
        """
        if not self._initialized:
            self.initialize()
        
        keys = key_path.split(".")
        current = self._config
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return default
        
        return current
    
    def set(self, key_path: str, value: Any):
        """
        设置配置值
        
        Args:
            key_path: 配置键路径，使用点号分隔
            value: 配置值
        """
        if not self._initialized:
            self.initialize()
        
        keys = key_path.split(".")
        current = self._config
        
        for key in keys[:-1]:
            if key not in current or not isinstance(current[key], dict):
                current[key] = {}
            current = current[key]
        
        current[keys[-1]] = value
        logger.info(f"已更新配置: {key_path}")
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """
        获取整个配置节
        
        Args:
            section: 配置节名称
            
        Returns:
            配置节字典
        """
        return self.get(section, {})
    
    def reload(self):
        """
        重新加载配置
        """
        logger.info("正在重新加载配置...")
        self._initialized = False
        self.initialize()
    
    def get_all_config(self) -> Dict[str, Any]:
        """
        获取所有配置
        
        Returns:
            完整的配置字典
        """
        if not self._initialized:
            self.initialize()
        return self._deep_copy(self._config)
    
    def validate_config(self) -> bool:
        """
        验证配置的有效性，确保关键配置项存在且有效
        
        Returns:
            bool: 配置是否有效
        """
        if not self._initialized:
            self.initialize()
        
        logger.info("开始验证配置有效性...")
        
        # 定义关键配置项验证规则
        validation_rules = {
            "voice.tts.enabled": (bool, True),  # 类型验证和存在性检查
            "voice.stt.enabled": (bool, True),
            "image.enabled": (bool, True),
            "multimodal.enabled": (bool, True)
        }
        
        # 定义可选配置项的默认值
        optional_configs = {
            "voice.tts.default_engine": "coqui",
            "voice.stt.default_model": "whisper",
            "image.default_model": "stable-diffusion",
            "voice.tts.use_proxy": False,
            "voice.stt.use_proxy": False,
            "image.use_proxy": False
        }
        
        # 验证关键配置项
        valid = True
        for key_path, (expected_type, required) in validation_rules.items():
            value = self.get(key_path)
            if value is None:
                if required:
                    logger.error(f"关键配置项缺失: {key_path}")
                    valid = False
            elif not isinstance(value, expected_type):
                logger.error(f"配置项类型错误: {key_path}，期望 {expected_type.__name__}，实际 {type(value).__name__}")
                valid = False
        
        # 设置可选配置项的默认值
        for key_path, default_value in optional_configs.items():
            if self.get(key_path) is None:
                self.set(key_path, default_value)
                logger.info(f"已设置可选配置项的默认值: {key_path} = {default_value}")
        
        # 验证文件路径配置（如果存在）
        path_configs = [
            "model.path",
            "data.path",
            "logs.path"
        ]
        
        for path_config in path_configs:
            path_value = self.get(path_config)
            if path_value is not None:
                path_obj = Path(path_value)
                if not path_obj.exists():
                    try:
                        path_obj.mkdir(parents=True, exist_ok=True)
                        logger.info(f"已创建配置路径: {path_value}")
                    except Exception as e:
                        logger.error(f"无法创建配置路径 {path_value}: {str(e)}")
                        valid = False
        
        if valid:
            logger.info("配置验证通过")
        else:
            logger.error("配置验证失败，请检查上述错误信息")
        
        return valid


# 全局配置管理器实例
_config_manager_instance = None


def get_config_manager() -> ConfigManager:
    """
    获取全局配置管理器实例（单例模式）
    
    Returns:
        ConfigManager: 配置管理器实例
    """
    global _config_manager_instance
    if _config_manager_instance is None:
        _config_manager_instance = ConfigManager()
        _config_manager_instance.initialize()
    return _config_manager_instance


def get_config(key_path: str, default: Any = None) -> Any:
    """
    便捷函数：获取配置值
    
    Args:
        key_path: 配置键路径
        default: 默认值
        
    Returns:
        配置值
    """
    manager = get_config_manager()
    return manager.get(key_path, default)


def set_config(key_path: str, value: Any):
    """
    便捷函数：设置配置值
    
    Args:
        key_path: 配置键路径
        value: 配置值
    """
    manager = get_config_manager()
    manager.set(key_path, value)


# 导出公共接口
__all__ = [
    "ConfigManager",
    "get_config_manager",
    "get_config",
    "set_config"
]