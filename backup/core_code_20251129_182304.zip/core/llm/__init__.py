import asyncio
from typing import Dict, Optional, Any, List, Callable, Union
from dataclasses import dataclass, field
import yaml
from pathlib import Path
from contextlib import asynccontextmanager
from core.utils.logger import get_logger
from core.utils.error_handler import error_handling

# 定义service_error_handler装饰器（兼容现有代码）
def service_error_handler(func):
    """错误处理装饰器"""
    async def async_wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            logger.error(f"服务错误: {str(e)}")
            raise
    
    def sync_wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"服务错误: {str(e)}")
            raise
    
    import inspect
    if inspect.iscoroutinefunction(func):
        return async_wrapper
    else:
        return sync_wrapper
from core.scheduler import get_global_scheduler, TaskPriority
from core.model_registry import global_model_registry
logger = get_logger("LLMModule")
@dataclass
class LLMConfig:
    """LLM配置 - 支持多模型提供商的统一配置"""
    model_name: str
    provider: str = "default"  # 模型提供商: default, openai, qwen, local等
    device: str = "auto"  # auto, cpu, cuda
    max_context_length: int = 4096
    max_tokens: int = 2048  # 最大生成长度
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 50
    use_cache: bool = True
    model_path: Optional[str] = None
    # 网络相关配置
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    # 重试和降级策略
    max_retries: int = 2
    retry_delay: float = 1.0
    timeout: int = 30
    # 降级配置
    fallback_model: Optional[str] = None
    fallback_provider: Optional[str] = None
    # 额外参数
    additional_params: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_provider(cls, provider: str, model_name: str, **kwargs) -> 'LLMConfig':
        """
        从提供商和模型名称创建配置
        Args:
            provider: 提供商名称
            model_name: 模型名称
            **kwargs: 其他配置参数
        Returns:
            LLMConfig实例
        """
        return cls(
            model_name=model_name,
            provider=provider,
            **kwargs
        )

@dataclass
class LLMResponse:
    """
    统一的LLM响应格式
    """
    content: str = ""
    success: bool = True
    error: Optional[str] = None
    model_name: str = ""
    provider: str = ""
    token_usage: Dict[str, int] = field(default_factory=dict)
    execution_time: float = 0.0
class LLMProvider:
    """
    统一的LLM提供商接口抽象基类
    所有模型适配器都应该继承此类
    """
    def __init__(self, config: LLMConfig):
        self.config = config
        self.is_initialized = False
        self._scheduler = get_global_scheduler()
        self._last_error = None
    async def initialize(self) -> bool:
        """初始化LLM"""
        raise NotImplementedError
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """生成文本"""
        raise NotImplementedError
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """聊天模式"""
        raise NotImplementedError
    async def shutdown(self) -> bool:
        """关闭LLM"""
        return True
    async def _with_retry(self, func: Callable, **kwargs) -> Any:
        """
        带重试和降级策略的函数执行
        Args:
            func: 要执行的函数
            **kwargs: 函数参数
        Returns:
            函数执行结果
        """
        import time
        start_time = time.time()
        retries = 0
        last_error = None
        while retries <= self.config.max_retries:
            try:
                result = await func(**kwargs)
                # 计算执行时间
                result.execution_time = time.time() - start_time
                return result
            except Exception as e:
                last_error = e
                retries += 1
                if retries <= self.config.max_retries:
                    delay = self.config.retry_delay * (2 ** (retries - 1))  # 指数退避
                    logger.warning(f"LLM请求失败，{delay:.2f}秒后重试 ({retries}/{self.config.max_retries}): {str(e)}")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"LLM请求达到最大重试次数: {str(e)}")
        self._last_error = str(last_error)
        # 尝试降级策略
        if self.config.fallback_model:
            return await self._handle_fallback(str(last_error), **kwargs)
        return LLMResponse(
            content="",
            success=False,
            error=str(last_error),
            model_name=self.config.model_name,
            provider=self.config.provider,
            execution_time=time.time() - start_time
        )
    async def _handle_fallback(self, original_error: str, **kwargs) -> LLMResponse:
        """
        移除降级逻辑，不再提供合成响应
        Args:
            original_error: 原始错误
            **kwargs: 原始请求参数
        Returns:
            不再返回任何合成响应，而是抛出异常以确保只使用真实数据
        """
        logger.error(f"LLM请求失败，已禁用降级策略: {original_error}")
        # 不再提供合成响应，而是直接抛出异常
        raise RuntimeError(f"LLM请求失败且降级策略已禁用: {original_error}")
# 向后兼容
class LLMInterface(LLMProvider):
    """LLM接口抽象基类 - 保持向后兼容"""
    pass
class BaseLLM(LLMProvider):
    """基础LLM实现"""
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self._model = None
        self._tokenizer = None
    async def initialize(self) -> bool:
        """初始化基础LLM，添加资源检查和超时控制"""
        if self.is_initialized:
            return True
        # 确定设备
        if self.config.device == "auto":
            import torch
            self.config.device = "cuda" if torch.cuda.is_available() else "cpu"
        # 检查可用内存
        try:
            import psutil
            available_memory = psutil.virtual_memory().available / (1024**3)  # GB
            logger.info(f"系统可用内存: {available_memory:.2f}GB")
            # 可以根据模型大小添加内存检查逻辑
        except Exception as e:
            logger.warning(f"内存检查失败: {e}")
        logger.info(
            f"正在初始化LLM: {self.config.model_name} (设备: {self.config.device}, 提供商: {self.config.provider})"
        )
        self.is_initialized = True
        return True
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """基础生成实现"""
        if not self.is_initialized:
            await self.initialize()
        # 基类不提供实际实现，子类必须重写此方法
        raise NotImplementedError("子类必须实现generate方法")
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """基础聊天实现"""
        if not self.is_initialized:
            await self.initialize()
        # 将聊天消息转换为提示
        prompt = self._format_chat_messages(messages)
        # 调用生成方法
        response = await self.generate(prompt, **kwargs)
        return response
    def _format_chat_messages(self, messages: List[Dict[str, str]]) -> str:
        """格式化聊天消息"""
        # 基础实现，子类应该重写
        formatted = ""
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            formatted += f"<{role}>{content}</{role}>\n"
        return formatted
    async def shutdown(self) -> bool:
        """关闭LLM"""
        try:
            if hasattr(self, '_model'):
                self._model = None
            if hasattr(self, '_tokenizer'):
                self._tokenizer = None
            self.is_initialized = False
            return True
        except Exception as e:
            logger.error(f"关闭LLM失败: {e}")
            return False
# 预定义的适配器类
class OpenAIAdapter(LLMProvider):
    """
    OpenAI适配器 - 支持OpenAI API和兼容的服务
    """
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self._client = None
    async def initialize(self) -> bool:
        """初始化OpenAI客户端"""
        try:
            logger.info(f"初始化OpenAI适配器: {self.config.model_name}")
            # 这里应该初始化实际的OpenAI客户端
            # 示例: import openai; self._client = openai.AsyncClient(api_key=self.config.api_key, base_url=self.config.base_url)
            self.is_initialized = True
            return True
        except Exception as e:
            logger.error(f"初始化OpenAI适配器失败: {str(e)}")
            self._last_error = str(e)
            return False
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """生成文本"""
        return await self._with_retry(self._generate_impl, prompt=prompt, **kwargs)
    async def _generate_impl(self, prompt: str, **kwargs) -> LLMResponse:
        """实际生成实现"""
        # 转换为聊天格式
        messages = [{"role": "user", "content": prompt}]
        return await self.chat(messages, **kwargs)
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """聊天完成"""
        return await self._with_retry(self._chat_impl, messages=messages, **kwargs)
    async def _chat_impl(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """实际聊天实现"""
        # 必须实现实际的OpenAI API调用
        # 移除模拟实现，强制使用真实API
        if not self._client:
            raise RuntimeError("OpenAI客户端未初始化")
        try:
            # 实际代码应该调用OpenAI API
            # 示例：
            # response = await self._client.chat.completions.create(
            #     model=self.config.model_name,
            #     messages=messages,
            #     **kwargs
            # )
            # 此处需要根据实际的OpenAI SDK进行实现
            raise NotImplementedError("需要实现实际的OpenAI API调用")
        except Exception as e:
            raise RuntimeError(f"OpenAI API调用失败: {str(e)}")
class QwenAdapter(LLMProvider):
    """
    通义千问适配器
    """
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self._client = None
    async def initialize(self) -> bool:
        """初始化通义千问客户端"""
        try:
            logger.info(f"初始化通义千问适配器: {self.config.model_name}")
            # 这里应该初始化实际的千问客户端
            # 示例: import dashscope; dashscope.api_key = self.config.api_key
            self.is_initialized = True
            return True
        except Exception as e:
            logger.error(f"初始化通义千问适配器失败: {str(e)}")
            self._last_error = str(e)
            return False
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """生成文本"""
        return await self._with_retry(self._generate_impl, prompt=prompt, **kwargs)
    async def _generate_impl(self, prompt: str, **kwargs) -> LLMResponse:
        """实际生成实现"""
        # 转换为千问格式
        messages = [{"role": "user", "content": prompt}]
        return await self.chat(messages, **kwargs)
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """聊天完成"""
        return await self._with_retry(self._chat_impl, messages=messages, **kwargs)
    async def _chat_impl(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """实际聊天实现"""
        # 必须实现实际的通义千问API调用
        # 移除模拟实现，强制使用真实API
        try:
            # 实际代码应该调用通义千问API
            # 示例：
            # response = await dashscope.Generation.call(
            #     model=self.config.model_name,
            #     messages=messages,
            #     **kwargs
            # )
            # 此处需要根据实际的千问SDK进行实现
            raise NotImplementedError("需要实现实际的通义千问API调用")
        except Exception as e:
            raise RuntimeError(f"通义千问API调用失败: {str(e)}")
class LocalModelAdapter(LLMProvider):
    """
    本地模型适配器
    """
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self._model = None
        self._tokenizer = None
    async def initialize(self) -> bool:
        """初始化本地模型"""
        try:
            if not self.config.model_path:
                raise ValueError("本地模型路径未设置")
            logger.info(f"初始化本地模型: {self.config.model_path}")
            # 这里应该加载实际的本地模型
            # 示例: from transformers import AutoModelForCausalLM; self._model = AutoModelForCausalLM.from_pretrained(self.config.model_path)
            self.is_initialized = True
            return True
        except Exception as e:
            logger.error(f"初始化本地模型失败: {str(e)}")
            self._last_error = str(e)
            return False
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """生成文本"""
        return await self._with_retry(self._generate_impl, prompt=prompt, **kwargs)
    async def _generate_impl(self, prompt: str, **kwargs) -> LLMResponse:
        """实际生成实现"""
        # 必须实现实际的本地模型调用
        # 移除模拟实现，强制使用真实模型
        if not self._model or not self._tokenizer:
            raise RuntimeError("本地模型或分词器未初始化")
        try:
            # 实际代码应该调用本地模型
            # 示例：
            # inputs = self._tokenizer(prompt, return_tensors="pt")
            # outputs = self._model.generate(**inputs, **kwargs)
            # content = self._tokenizer.decode(outputs[0], skip_special_tokens=True)
            # 此处需要根据实际的模型库进行实现
            raise NotImplementedError("需要实现实际的本地模型调用")
        except Exception as e:
            raise RuntimeError(f"本地模型推理失败: {str(e)}")
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """聊天完成"""
        return await self._with_retry(self._chat_impl, messages=messages, **kwargs)
    async def _chat_impl(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """实际聊天实现"""
        try:
            # 格式化聊天消息
            prompt = "\n".join([f"{msg['role']}: {msg['content']}" for msg in messages])
            # 调用生成方法
            response = await self._generate_impl(prompt, **kwargs)
            return response
        except Exception as e:
            raise Exception(f"本地模型聊天失败: {str(e)}")
class LLMFactory:
    """LLM工厂类 - 支持多提供商的统一创建"""
    # 注册提供商适配器
    _adapters: Dict[str, type] = {
        "openai": OpenAIAdapter,
        "qwen": QwenAdapter,
        "local": LocalModelAdapter,
        # 默认使用BaseLLM
    }

    @classmethod
    def register(cls, provider: str, adapter_class: type):
        """注册新的提供商适配器"""
        cls._adapters[provider] = adapter_class
        logger.info(f"已注册LLM提供商适配器: {provider} -> {adapter_class.__name__}")

    @classmethod
    def create(cls, config: LLMConfig) -> LLMProvider:
        """根据配置创建LLM实例"""
        provider = config.provider.lower()
        if provider not in cls._adapters:
            raise ValueError(f"不支持的LLM提供商: {provider}")
        
        adapter_class = cls._adapters[provider]
        logger.info(f"创建LLM实例: {config.model_name} ({provider})")
        return adapter_class(config)

    @classmethod
    def get_supported_providers(cls) -> List[str]:
        """获取支持的提供商列表"""
        return list(cls._adapters.keys())

    @classmethod
    def unregister(cls, provider: str):
        """注销提供商适配器"""
        if provider in cls._adapters:
            del cls._adapters[provider]
            logger.info(f"已注销LLM提供商适配器: {provider}")

class LLMManager:
    """LLM管理器，支持多实例管理"""
    def __init__(self):
        self._instances: Dict[str, LLMProvider] = {}
        self._default_instance_id: Optional[str] = None
        self._scheduler = get_global_scheduler()
        self._lock = asyncio.Lock()
        # 加载配置
        self._load_config()
        logger.info("LLM管理器初始化完成")
    def _load_config(self):
        """加载LLM配置"""
        # 使用相对路径，提高跨平台兼容性
        config_path = Path(__file__).resolve().parents[3] / "configs" / "paths.yaml"
        if config_path.exists():
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = yaml.safe_load(f)
                    if (
                        config
                        and "model_paths" in config
                        and "llm" in config["model_paths"]
                    ):
                        self._model_paths = config["model_paths"]["llm"]
            except Exception as e:
                logger.error(f"加载LLM配置失败: {e}")
                # 设置默认配置作为备选
                self._model_paths = {}
        else:
            logger.warning(f"配置文件不存在: {config_path}")
            self._model_paths = {}
    async def create_instance(
        self, instance_id: str, config: LLMConfig
    ) -> LLMProvider:
        """
        创建LLM实例
        Args:
            instance_id: 实例ID
            config: LLM配置
        Returns:
            LLMProvider实例
        """
        async with self._lock:
            if instance_id in self._instances:
                logger.warning(f"LLM实例已存在: {instance_id}")
                return self._instances[instance_id]
            # 创建实例
            logger.info(f"创建LLM实例: {instance_id} ({config.provider}/{config.model_name})")
            llm = LLMFactory.create(config)
            # 初始化LLM
            success = await llm.initialize()
            if not success:
                raise RuntimeError(f"初始化LLM实例失败: {instance_id}")
            # 注册到模型注册表
            if hasattr(llm, "_model") and llm._model is not None:
                global_model_registry.register(
                    f"llm_{instance_id}",
                    llm._model,
                    metadata={
                        "model_name": config.model_name,
                        "provider": config.provider,
                        "instance_id": instance_id,
                        "device": config.device,
                    },
                )
            # 保存实例
            self._instances[instance_id] = llm
            # 如果是第一个实例，设置为默认实例
            if self._default_instance_id is None:
                self._default_instance_id = instance_id
                logger.info(f"设置默认LLM实例: {instance_id}")
            return llm
    async def create_instance_from_provider(
        self, instance_id: str, provider: str, model_name: str, **kwargs
    ) -> LLMProvider:
        """
        从提供商和模型名称创建实例
        Args:
            instance_id: 实例ID
            provider: 提供商名称
            model_name: 模型名称
            **kwargs: 其他配置参数
        Returns:
            LLMProvider实例
        """
        config = LLMConfig.from_provider(provider, model_name, **kwargs)
        return await self.create_instance(instance_id, config)
    async def get_instance(self, instance_id: Optional[str] = None) -> LLMProvider:
        """
        获取LLM实例
        Args:
            instance_id: 实例ID，如果为None则返回默认实例
        Returns:
            LLMProvider实例
        """
        if instance_id is None:
            instance_id = self._default_instance_id
        if instance_id is None:
            raise ValueError("没有可用的LLM实例，请先创建实例")
        if instance_id not in self._instances:
            raise ValueError(f"LLM实例不存在: {instance_id}")
        return self._instances[instance_id]
    async def generate(
        self, prompt: str, instance_id: Optional[str] = None, **kwargs
    ) -> str:
        """
        生成文本
        Args:
            prompt: 提示文本
            instance_id: 实例ID
            **kwargs: 额外参数
        Returns:
            生成的文本
        Raises:
            Exception: 当生成失败时
        """
        try:
            llm = await self.get_instance(instance_id)
            # 添加超时参数，避免任务无限等待
            timeout = kwargs.pop("timeout", 300)  # 默认5分钟超时
            # 提交任务到调度器，添加错误处理和超时控制
            result = await asyncio.wait_for(
                self._scheduler.submit_task(
                    llm.generate, prompt, **kwargs, priority=TaskPriority.HIGH
                ),
                timeout=timeout,
            )
            # 处理统一的响应格式
            if isinstance(result, LLMResponse):
                if result.success:
                    logger.info(f"LLM生成成功 (实例: {instance_id}, 提供商: {result.provider}, 执行时间: {result.execution_time:.2f}s)")
                    return result.content
                else:
                    logger.error(f"LLM生成失败 (实例: {instance_id}): {result.error}")
                    raise Exception(f"LLM生成失败: {result.error}")
            else:
                # 向后兼容：如果返回的不是LLMResponse，直接返回
                return result
        except asyncio.TimeoutError:
            logger.error(f"LLM生成超时 (实例: {instance_id})")
            raise Exception(f"LLM生成超时，任务执行时间超过{timeout}秒")
        except Exception as e:
            logger.error(f"LLM生成失败 (实例: {instance_id}): {e}")
            raise
    @service_error_handler
    async def chat(
        self,
        messages: List[Dict[str, str]],
        instance_id: Optional[str] = None,
        **kwargs,
    ) -> str:
        """
        聊天模式
        Args:
            messages: 消息列表
            instance_id: 实例ID
            **kwargs: 额外参数
        Returns:
            生成的回复
        Raises:
            Exception: 当聊天生成失败时
        """
        llm = await self.get_instance(instance_id)
        # 添加超时参数
        timeout = kwargs.pop("timeout", 300)  # 默认5分钟超时
        # 提交任务到调度器，添加错误处理和超时控制
        result = await asyncio.wait_for(
            self._scheduler.submit_task(
                llm.chat, messages, **kwargs, priority=TaskPriority.HIGH
            ),
            timeout=timeout,
        )
        # 处理统一的响应格式
        if isinstance(result, LLMResponse):
            if result.success:
                logger.info(f"LLM聊天成功 (实例: {instance_id}, 提供商: {result.provider}, 执行时间: {result.execution_time:.2f}s)")
                return result.content
            else:
                logger.error(f"LLM聊天失败 (实例: {instance_id}): {result.error}")
                raise Exception(f"LLM聊天失败: {result.error}")
        else:
            # 向后兼容：如果返回的不是LLMResponse，直接返回
            return result
    async def delete_instance(self, instance_id: str):
        """
        删除LLM实例，确保资源正确释放
        Args:
            instance_id: 实例ID
        Raises:
            ValueError: 当实例不存在时
        """
        async with self._lock:
            if instance_id not in self._instances:
                raise ValueError(f"LLM实例不存在: {instance_id}")
            # 关闭实例并释放资源
            llm = self._instances[instance_id]
            try:
                success = await llm.shutdown()
                status = "成功" if success else "部分成功"
                logger.debug(f"LLM实例 {instance_id} 关闭{status}")
            except Exception as e:
                logger.error(f"关闭LLM实例时出错 {instance_id}: {e}")
            # 从模型注册表中移除
            try:
                global_model_registry.unload(f"llm_{instance_id}")
                logger.debug(f"LLM实例 {instance_id} 已从模型注册表移除")
            except Exception as e:
                logger.error(f"从模型注册表移除LLM实例时出错 {instance_id}: {e}")
            # 手动清理引用以帮助垃圾回收
            if hasattr(llm, "_model"):
                llm._model = None
            if hasattr(llm, "_tokenizer"):
                llm._tokenizer = None
            if hasattr(llm, "_client"):
                llm._client = None
            # 删除实例
            del self._instances[instance_id]
            logger.info(f"已删除LLM实例: {instance_id}")
            # 强制垃圾回收以释放内存
            import gc
            gc.collect()
            # 如果删除的是默认实例，选择新的默认实例
            if self._default_instance_id == instance_id:
                if self._instances:
                    self._default_instance_id = next(iter(self._instances.keys()))
                    logger.info(f"设置新的默认LLM实例: {self._default_instance_id}")
                else:
                    self._default_instance_id = None
    async def shutdown(self):
        """关闭所有实例"""
        instance_ids = list(self._instances.keys())
        for instance_id in instance_ids:
            try:
                await self.delete_instance(instance_id)
            except Exception as e:
                logger.error(f"关闭实例 {instance_id} 时出错: {e}")
        logger.info("LLM管理器已关闭")
    async def create_and_use(self, instance_id: str, config: LLMConfig) -> LLMProvider:
        """
        创建并使用LLM实例（便捷方法）
        Args:
            instance_id: 实例ID
            config: LLM配置
        Returns:
            LLMProvider实例
        """
        llm = await self.create_instance(instance_id, config)
        self.set_default_instance(instance_id)
        return llm
    async def create_and_use_from_provider(
        self, instance_id: str, provider: str, model_name: str, **kwargs
    ) -> LLMProvider:
        """
        从提供商创建并使用LLM实例（便捷方法）
        Args:
            instance_id: 实例ID
            provider: 提供商名称
            model_name: 模型名称
            **kwargs: 其他配置参数
        Returns:
            LLMProvider实例
        """
        config = LLMConfig.from_provider(provider, model_name, **kwargs)
        return await self.create_and_use(instance_id, config)
# 全局LLM管理器实例
def get_global_llm_manager() -> LLMManager:
    """获取全局LLM管理器实例"""
    if not hasattr(get_global_llm_manager, "_instance"):
        get_global_llm_manager._instance = LLMManager()
    return get_global_llm_manager._instance
class LLMModule:
    """LLM模块 - 支持多模型提供商"""
    def __init__(self):
        self._llm_manager = None
        self._is_initialized = False
    async def initialize(self):
        """初始化LLM模块"""
        if self._is_initialized:
            return
        logger.info("正在初始化LLM模块...")
        # 获取全局LLM管理器
        self._llm_manager = get_global_llm_manager()
        # 注册默认的适配器
        LLMFactory.register("openai", OpenAIAdapter)
        LLMFactory.register("qwen", QwenAdapter)
        LLMFactory.register("local", LocalModelAdapter)
        self._is_initialized = True
        logger.info("LLM模块初始化完成")
    async def create_llm_instance(
        self, instance_id: str, config: LLMConfig
    ) -> LLMProvider:
        """创建LLM实例"""
        if not self._is_initialized:
            await self.initialize()
        return await self._llm_manager.create_instance(instance_id, config)
    async def create_llm_instance_from_provider(
        self, instance_id: str, provider: str, model_name: str, **kwargs
    ) -> LLMProvider:
        """
        从提供商创建LLM实例
        Args:
            instance_id: 实例ID
            provider: 提供商名称
            model_name: 模型名称
            **kwargs: 其他配置参数
        Returns:
            LLMProvider实例
        """
        if not self._is_initialized:
            await self.initialize()
        return await self._llm_manager.create_instance_from_provider(
            instance_id=instance_id,
            provider=provider,
            model_name=model_name,
            **kwargs
        )
    async def generate(
        self, prompt: str, instance_id: Optional[str] = None, **kwargs
    ) -> str:
        """生成文本"""
        if not self._is_initialized:
            await self.initialize()
        return await self._llm_manager.generate(prompt, instance_id, **kwargs)
    async def chat(
        self,
        messages: List[Dict[str, str]],
        instance_id: Optional[str] = None,
        **kwargs,
    ) -> str:
        """聊天模式"""
        if not self._is_initialized:
            await self.initialize()
        return await self._llm_manager.chat(messages, instance_id, **kwargs)
    async def shutdown(self):
        """关闭模块"""
        if not self._is_initialized:
            return
        logger.info("正在关闭LLM模块...")
        if self._llm_manager:
            await self._llm_manager.shutdown()
        self._is_initialized = False
        logger.info("LLM模块已关闭")
# 获取全局LLM模块实例
def get_llm_module() -> LLMModule:
    """获取全局LLM模块实例"""
    if not hasattr(get_llm_module, "_instance"):
        get_llm_module._instance = LLMModule()
    return get_llm_module._instance
# 统一多模型支持的便捷函数
async def generate_with_provider(
    prompt: str, 
    provider: str = "openai",
    model_name: str = "gpt-3.5-turbo",
    instance_id: Optional[str] = None,
    **kwargs
) -> str:
    """
    使用指定提供商生成文本
    Args:
        prompt: 提示文本
        provider: 模型提供商
        model_name: 模型名称
        instance_id: 实例ID（可选，自动生成）
        **kwargs: 其他配置参数
    Returns:
        生成的文本
    """
    module = get_llm_module()
    # 自动生成实例ID
    if not instance_id:
        instance_id = f"{provider}_{model_name}_default"
    # 检查实例是否存在，不存在则创建
    llm_manager = module._llm_manager
    try:
        await llm_manager.get_instance(instance_id)
    except ValueError:
        # 实例不存在，创建新实例
        await llm_manager.create_instance_from_provider(
            instance_id=instance_id,
            provider=provider,
            model_name=model_name,
            **kwargs
        )
    return await module.generate(prompt, instance_id, **kwargs)
async def chat_with_provider(
    messages: List[Dict[str, str]],
    provider: str = "openai",
    model_name: str = "gpt-3.5-turbo",
    instance_id: Optional[str] = None,
    **kwargs
) -> str:
    """
    使用指定提供商进行聊天
    Args:
        messages: 消息列表
        provider: 模型提供商
        model_name: 模型名称
        instance_id: 实例ID（可选，自动生成）
        **kwargs: 其他配置参数
    Returns:
        生成的回复
    """
    module = get_llm_module()
    # 自动生成实例ID
    if not instance_id:
        instance_id = f"{provider}_{model_name}_default"
    # 检查实例是否存在，不存在则创建
    llm_manager = module._llm_manager
    try:
        await llm_manager.get_instance(instance_id)
    except ValueError:
        # 实例不存在，创建新实例
        await llm_manager.create_instance_from_provider(
            instance_id=instance_id,
            provider=provider,
            model_name=model_name,
            **kwargs
        )
    return await module.chat(messages, instance_id, **kwargs)
# 模块级便捷函数（保持向后兼容）
async def generate(prompt: str, instance_id: Optional[str] = None, **kwargs) -> str:
    """模块级文本生成函数"""
    module = get_llm_module()
    return await module.generate(prompt, instance_id, **kwargs)
async def chat(
    messages: List[Dict[str, str]], instance_id: Optional[str] = None, **kwargs
) -> str:
    """模块级聊天函数"""
    module = get_llm_module()
    return await module.chat(messages, instance_id, **kwargs)
async def create_instance(instance_id: str, config: LLMConfig) -> LLMProvider:
    """模块级创建实例函数"""
    module = get_llm_module()
    return await module.create_llm_instance(instance_id, config)
async def create_instance_with_provider(
    instance_id: str, provider: str, model_name: str, **kwargs
) -> LLMProvider:
    """
    使用指定提供商创建实例
    Args:
        instance_id: 实例ID
        provider: 提供商名称
        model_name: 模型名称
        **kwargs: 其他配置参数
    Returns:
        LLMProvider实例
    """
    module = get_llm_module()
    return await module.create_llm_instance_from_provider(
        instance_id=instance_id,
        provider=provider,
        model_name=model_name,
        **kwargs
    )
async def get_module_status() -> Dict[str, Any]:
    """获取模块状态"""
    module = get_llm_module()
    return module.get_status()
# 导出所有公共接口
__all__ = [
    # 核心类
    "LLMConfig",
    "LLMResponse",
    "LLMProvider",
    "LLMInterface",
    "BaseLLM",
    "LLMFactory",
    "LLMManager",
    "LLMModule",
    # 适配器
    "OpenAIAdapter",
    "QwenAdapter",
    "LocalModelAdapter",
    # 获取实例的函数
    "get_global_llm_manager",
    "get_llm_module",
    # 便捷函数
    "generate",
    "chat",
    "create_instance",
    "get_module_status",
    # 统一多模型支持的便捷函数
    "generate_with_provider",
    "chat_with_provider",
    "create_instance_with_provider",
]
# 模块说明
__doc__ = """
大语言模型模块 (LLM Module) - 统一多模型支持版本
该模块提供了统一的大语言模型接口，支持多模型提供商、失败重试、降级策略和资源优化。
主要特性：
- 支持多模型提供商（OpenAI、通义千问、本地模型等）
- 统一的响应格式和错误处理
- 内置失败重试和降级策略
- 支持多模型实例管理
- 统一的异步接口
- 与全局调度器集成
- 自动设备选择（CPU/CUDA）
- 模型注册表集成
使用示例：
```python
import asyncio
from core.llm import (
    generate_with_provider,
    chat_with_provider,
    LLMConfig,
    create_instance_with_provider
)
async def example():
    # 1. 使用OpenAI模型（一行代码）
    openai_response = await generate_with_provider(
        prompt="请简要介绍人工智能",
        provider="openai",
        model_name="gpt-3.5-turbo",
        api_key="your_api_key"
    )
    print(f"OpenAI响应: {openai_response}")
    # 2. 使用通义千问模型（一行代码）
    qwen_response = await chat_with_provider(
        messages=[
            {"role": "system", "content": "你是一个助手"},
            {"role": "user", "content": "你好，我是小明"}
        ],
        provider="qwen",
        model_name="qwen-plus",
        api_key="your_api_key"
    )
    print(f"通义千问响应: {qwen_response}")
    # 3. 使用本地模型
    local_response = await generate_with_provider(
        prompt="生成一首短诗",
        provider="local",
        model_name="my_local_model",
        model_path="/path/to/model",
        device="cuda"
    )
    print(f"本地模型响应: {local_response}")
    # 4. 使用自定义配置（包含重试和降级策略）
    config = LLMConfig.from_provider(
        provider="openai",
        model_name="gpt-4",
        max_retries=3,
        retry_delay=2.0,
        timeout=60,
        fallback_model="gpt-3.5-turbo",  # 降级模型
        fallback_provider="openai"
    )
    llm_instance = await create_instance_with_provider(
        instance_id="my_llm",
        provider="openai",
        model_name="gpt-4",
        **config.__dict__
    )
    # 5. 使用事件总线集成
    from core import get_event_bus
    event_bus = get_event_bus()
    # 订阅LLM相关事件
    async def handle_llm_response(event_data):
        print(f"收到LLM响应事件: {event_data}")
    # 发布消息到事件总线（需要在Core Engine中实现）
    # await event_bus.publish("user_message", {"content": "你好", "model": "openai:gpt-3.5-turbo"})
# 运行示例
if __name__ == "__main__":
    asyncio.run(example())
```
注意事项：
- 请确保安装了相应的依赖库
- API密钥请妥善保管，不要硬编码在代码中
- 本地模型需要先下载到指定路径
- 降级功能需要正确配置fallback_model参数
"""
# 模块版本
__version__ = "2.0.0"
