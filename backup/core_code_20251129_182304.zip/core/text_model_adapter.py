#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文本模型适配器
专注于文本生成任务的适配器
"""

import os
import logging
import json
import time
import asyncio
import torch
import threading
import re
from typing import Dict, Optional, Any, Union, List
from llama_cpp import Llama
from .model_manager import get_model_manager
from .utils.base_adapter import BaseAdapter

logger = logging.getLogger(__name__)


class TextModelAdapter(BaseAdapter):
    """
    文本模型适配器
    处理文本生成、对话等任务
    """
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        # 默认配置
        default_config = {
            'model_type': 'transformers',  # transformers, ollama, vllm, infer_service
            'text_model_path': '',
            'device': 'auto',
            'quantization': {
                'enabled': False,
                'load_in_8bit': False,
                'load_in_4bit': False,
                'torch_dtype': torch.float16 if torch.cuda.is_available() else torch.float32
            },
            'ollama_base_url': 'http://localhost:11434',
            'ollama_model': 'llama3',
            'vllm_base_url': 'http://localhost:8000/generate',
            'vllm_model': 'facebook/opt-125m',
            'timeout': 60,
            'max_retries': 3
        }
        
        # 合并配置
        self.config = default_config.copy()
        if config:
            self.config.update(config)
        
        # 设置模型类型
        self._model_type = self.config['model_type']
        
        # 设置模型名称
        model_name = f"text_{self._model_type}_{hash(self.config['text_model_path'])}" if self.config['text_model_path'] else f"text_{self._model_type}"
        
        # 调用父类初始化
        super().__init__(get_model_manager(), 'text', model_name)
        
        # 注册模型到管理器
        self._register_model()
        self._llama = None

    def _register_model(self):
        """注册模型到模型管理器"""
        try:
            # 即使text_model_path为空，也注册模型，使用默认路径或占位符
            model_path = self.config['text_model_path'] if self.config['text_model_path'] else 'default_model'
            success = self.model_manager.register_model(
                model_name=self._model_name,
                model_type='llm',
                model_path=model_path
            )
            if success:
                logger.info(f"文本模型已注册: {self._model_name}")
            else:
                logger.warning(f"文本模型注册失败或已存在: {self._model_name}")
                # 如果模型已存在，确保锁已创建
                if self._model_name not in self.model_manager._model_locks:
                    self.model_manager._model_locks[self._model_name] = threading.Lock()
        except Exception as e:
            logger.error(f"注册文本模型失败: {str(e)}")
            # 即使出错也要确保锁已创建
            if not hasattr(self.model_manager, '_model_locks'):
                self.model_manager._model_locks = {}
            if self._model_name not in self.model_manager._model_locks:
                self.model_manager._model_locks[self._model_name] = threading.Lock()

    def _prepare_model_load_params(self) -> Dict[str, Any]:
        """
        准备模型加载参数
        
        Returns:
            Dict: 模型加载参数
        """
        if self._model_type != 'transformers':
            return {}
            
        load_kwargs = {
            'device': self.config['device'],
            'torch_dtype': self.config['quantization']['torch_dtype'],
            'quantized': self.config['quantization']['enabled'],
            'model_kwargs': {}
        }
        
        # 添加量化参数到model_kwargs中，避免与quantization_config冲突
        if self.config['quantization']['load_in_8bit']:
            load_kwargs['model_kwargs']['load_in_8bit'] = True
        elif self.config['quantization']['load_in_4bit']:
            load_kwargs['model_kwargs']['load_in_4bit'] = True
        q = self.config['quantization']
        load_kwargs['quantization_config'] = {
            'enabled': q.get('enabled', False),
            'load_in_4bit': q.get('load_in_4bit', False),
            'load_in_8bit': q.get('load_in_8bit', False),
            'bnb_4bit_quant_type': q.get('bnb_4bit_quant_type', 'nf4'),
            'bnb_4bit_compute_dtype': q.get('torch_dtype', q.get('bnb_4bit_compute_dtype', None)),
            'bnb_4bit_use_double_quant': q.get('bnb_4bit_use_double_quant', True),
            'bitsandbytes': True
        }
        
        return load_kwargs
        
    def load_model(self) -> bool:
        """
        加载文本模型
        
        Returns:
            bool: 是否加载成功
        """
        try:
            if self._model_type != 'transformers':
                self._is_loaded = True
                return True
            
            # 使用基类的加载方法
            return super().load_model()
        except Exception as e:
            logger.error(f"加载文本模型时出错: {str(e)}")
            return False

    def chat(self, 
             messages: Optional[List[Dict[str, str]]] = None,
             prompt: Optional[str] = None,
             max_tokens: int = 512, 
             temperature: float = 0.7, 
             top_p: float = 0.9,
             stop_phrases: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        使用文本模型生成对话响应
        
        Args:
            messages: 消息列表，格式为[{"role": "user", "content": "..."}, ...]
            prompt: 输入提示（兼容旧接口）
            max_tokens: 最大生成token数
            temperature: 生成温度
            top_p: top_p采样参数
            
        Returns:
            包含状态和响应的字典
        """
        try:
            # 兼容messages和prompt两种参数格式
            if messages is not None and isinstance(messages, list) and len(messages) > 0:
                # 从messages中提取最后一个用户消息作为prompt
                user_messages = [msg['content'] for msg in messages if msg.get('role') == 'user']
                if user_messages:
                    prompt = user_messages[-1]  # 使用最后一个用户消息
                else:
                    prompt = messages[-1]['content']  # 兜底使用最后一条消息
            elif prompt is None:
                return {"status": "error", "error": "必须提供messages或prompt参数"}
            
            # 参数验证
            if not prompt or not isinstance(prompt, str):
                return {"status": "error", "error": "无效的提示文本"}
            
            # 使用性能跟踪器开始计时
            self._performance_tracker.start_tracking()
            
            # 确保模型已加载
            if not self._ensure_model_loaded():
                if not self.load_model():
                    return {"status": "error", "error": "模型加载失败"}
            
            # 根据模型类型调用不同的生成方法
            if self._model_type == 'transformers':
                response = self._chat_with_transformers(prompt, max_tokens, temperature, top_p, messages, stop_phrases)
            elif self._model_type == 'ollama':
                response = self._chat_with_ollama(prompt, max_tokens, temperature, top_p)
            elif self._model_type == 'vllm':
                response = self._chat_with_vllm(prompt, max_tokens, temperature, top_p)
            elif self._model_type == 'infer_service':
                response = self._chat_with_infer_service(prompt, max_tokens, temperature, top_p)
            elif self._model_type == 'llama_cpp':
                response = self._chat_with_llama_cpp(prompt, max_tokens, temperature, top_p)
            else:
                return {"status": "error", "error": f"不支持的模型类型: {self._model_type}"}
            
            # 结束性能跟踪
            self._performance_tracker.end_tracking()
            
            return {"status": "success", "response": response}
            
        except Exception as e:
            # 结束性能跟踪并标记错误
            self._performance_tracker.end_tracking(error_occurred=True)
            logger.error(f"生成文本时出错: {str(e)}")
            return {"status": "error", "error": f"生成错误: {str(e)}"}

    def _chat_with_transformers(self, 
                              prompt: str, 
                              max_tokens: int, 
                              temperature: float, 
                              top_p: float,
                              messages: Optional[List[Dict[str, str]]] = None,
                              stop_phrases: Optional[List[str]] = None) -> str:
        """
        使用本地Transformers模型生成响应
        """
        logger.info(f"准备使用transformers模型生成响应，模型名称: {self._model_name}")
        
        # 获取模型和分词器
        model = self.model_manager.get_model(self._model_name)
        tokenizer = self.model_manager.get_tokenizer(self._model_name)
        
        logger.info(f"获取模型结果: model={model is not None}, tokenizer={tokenizer is not None}")
        
        if not model:
            raise Exception(f"模型未加载: {self._model_name}")
        if not tokenizer:
            raise Exception(f"分词器未加载: {self._model_name}")
        
        try:
            device = next(model.parameters()).device
            use_chat = False
            chat_messages = messages if isinstance(messages, list) and messages else None
            if chat_messages is None and hasattr(tokenizer, 'apply_chat_template'):
                try:
                    lines = str(prompt or '').splitlines()
                    sys_buf = []
                    parsed = []
                    name = None
                    for ln in lines:
                        if not ln:
                            continue
                        m_user = re.match(r'^\s*用户\s*:\s*(.*)$', ln)
                        if m_user:
                            if sys_buf:
                                parsed.append({'role': 'system', 'content': '\n'.join(sys_buf).strip()})
                                sys_buf = []
                            parsed.append({'role': 'user', 'content': m_user.group(1).strip()})
                            continue
                        m_asst = re.match(r'^\s*([^:]+)\s*:\s*(.*)$', ln)
                        if m_asst and m_asst.group(1).strip() != '用户':
                            name = m_asst.group(1).strip()
                            content = m_asst.group(2).strip()
                            if content:
                                parsed.append({'role': 'assistant', 'content': content})
                            continue
                        sys_buf.append(ln)
                    if sys_buf:
                        parsed.insert(0, {'role': 'system', 'content': '\n'.join(sys_buf).strip()})
                    parsed = [m for m in parsed if isinstance(m, dict) and m.get('content')]
                    if any(m.get('role') == 'user' for m in parsed):
                        chat_messages = parsed
                except Exception:
                    chat_messages = None
            if chat_messages is not None and hasattr(tokenizer, 'apply_chat_template'):
                try:
                    input_ids = tokenizer.apply_chat_template(chat_messages, add_generation_prompt=True, return_tensors='pt')
                    input_ids = input_ids.to(device)
                    stopping = None
                    if stop_phrases:
                        from transformers import StoppingCriteria, StoppingCriteriaList
                        class PhraseStop(StoppingCriteria):
                            def __init__(self, phrases_ids):
                                super().__init__()
                                self.phrases_ids = phrases_ids
                            def __call__(self, input_ids, scores, **kwargs):
                                seq = input_ids[0].tolist()
                                for p in self.phrases_ids:
                                    L = len(p)
                                    if L > 0 and len(seq) >= L and seq[-L:] == p:
                                        return True
                                return False
                        phrases_ids = []
                        for s in stop_phrases:
                            try:
                                ids = tokenizer(s, add_special_tokens=False, return_tensors='pt').input_ids[0].tolist()
                                if ids:
                                    phrases_ids.append(ids)
                            except Exception:
                                pass
                        if phrases_ids:
                            stopping = StoppingCriteriaList([PhraseStop(phrases_ids)])
                    with torch.no_grad():
                        output = model.generate(
                            input_ids=input_ids,
                            max_new_tokens=max_tokens,
                            temperature=temperature,
                            top_p=top_p,
                            do_sample=True,
                            pad_token_id=tokenizer.eos_token_id,
                            stopping_criteria=stopping
                        )
                    gen_ids = output[0][input_ids.shape[-1]:]
                    response = tokenizer.decode(gen_ids, skip_special_tokens=True)
                    return response.strip()
                except Exception:
                    pass
            inputs = tokenizer(prompt, return_tensors='pt')
            inputs = {k: v.to(device) for k, v in inputs.items()}
            stopping = None
            if stop_phrases:
                from transformers import StoppingCriteria, StoppingCriteriaList
                class PhraseStop(StoppingCriteria):
                    def __init__(self, phrases_ids):
                        super().__init__()
                        self.phrases_ids = phrases_ids
                    def __call__(self, input_ids, scores, **kwargs):
                        seq = input_ids[0].tolist()
                        for p in self.phrases_ids:
                            L = len(p)
                            if L > 0 and len(seq) >= L and seq[-L:] == p:
                                return True
                        return False
                phrases_ids = []
                for s in stop_phrases:
                    try:
                        ids = tokenizer(s, add_special_tokens=False, return_tensors='pt').input_ids[0].tolist()
                        if ids:
                            phrases_ids.append(ids)
                    except Exception:
                        pass
                if phrases_ids:
                    stopping = StoppingCriteriaList([PhraseStop(phrases_ids)])
            with torch.no_grad():
                output = model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temperature,
                    top_p=top_p,
                    do_sample=True,
                    pad_token_id=tokenizer.eos_token_id,
                    stopping_criteria=stopping
                )
            response = tokenizer.decode(output[0], skip_special_tokens=True)
            if response.startswith(prompt):
                response = response[len(prompt):].strip()
            elif prompt in response:
                parts = response.split(prompt)
                if len(parts) > 1:
                    response = parts[-1].strip()
            unwanted_starters = ['吧。', '的。', '了。', '呢。', '啊。', '！', '？', '。', '，', '：', '；']
            for starter in unwanted_starters:
                if response.startswith(starter):
                    response = response[len(starter):].strip()
                    break
            return response
        except Exception as e:
            logger.error(f"生成响应时出错: {str(e)}", exc_info=True)
            raise

    def _chat_with_llama_cpp(self,
                             prompt: str,
                             max_tokens: int,
                             temperature: float,
                             top_p: float) -> str:
        if self._llama is None:
            model_path = self.config.get('text_model_path') or ''
            if not model_path:
                raise Exception('缺少GGUF模型路径')
            self._llama = Llama(model_path=model_path, n_ctx=max(1024, max_tokens * 2), n_threads=8, n_batch=256, n_gpu_layers=-1)
        out = self._llama.create_completion(prompt=prompt, max_tokens=max_tokens, temperature=temperature, top_p=top_p)
        txt = ''
        ch = out.get('choices')
        if isinstance(ch, list) and ch:
            txt = str(ch[0].get('text', ''))
        return txt.strip()

    def _chat_with_ollama(self, 
                         prompt: str, 
                         max_tokens: int, 
                         temperature: float, 
                         top_p: float) -> str:
        """
        使用Ollama API生成响应
        """
        try:
            import requests
            
            url = f"{self.config['ollama_base_url']}/generate"
            model_name = self.config.get("ollama_model", "llama3")
            
            payload = {
                "model": model_name,
                "prompt": prompt,
                "options": {
                    "num_predict": max_tokens,
                    "temperature": temperature,
                    "top_p": top_p
                },
                "stream": False
            }
            
            headers = {"Content-Type": "application/json"}
            timeout = self.config.get("timeout", 60)
            
            logger.info(f"调用Ollama API: {url}, 模型: {model_name}")
            response = requests.post(url, json=payload, headers=headers, timeout=timeout)
            
            if response.status_code == 200:
                data = response.json()
                return data.get("response", "")
            else:
                error_msg = f"Ollama API调用失败: HTTP {response.status_code}, {response.text}"
                logger.error(error_msg)
                raise Exception(error_msg)
                
        except ImportError:
            raise Exception("需要安装requests库")
        except Exception as e:
            logger.error(f"Ollama处理错误: {str(e)}")
            raise Exception(f"Ollama处理错误: {str(e)}")

    def _chat_with_vllm(self, 
                        prompt: str, 
                        max_tokens: int, 
                        temperature: float, 
                        top_p: float) -> str:
        """
        使用vLLM API生成响应
        """
        try:
            import requests
            
            url = self.config["vllm_base_url"]
            model_name = self.config.get("vllm_model", "facebook/opt-125m")
            
            payload = {
                "prompt": prompt,
                "model": model_name,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "top_p": top_p,
                "skip_special_tokens": True
            }
            
            headers = {"Content-Type": "application/json"}
            timeout = self.config.get("timeout", 60)
            
            logger.info(f"调用vLLM API: {url}, 模型: {model_name}")
            response = requests.post(url, json=payload, headers=headers, timeout=timeout)
            
            if response.status_code == 200:
                data = response.json()
                return data.get("text", "")
            else:
                error_msg = f"vLLM API调用失败: HTTP {response.status_code}, {response.text}"
                logger.error(error_msg)
                raise Exception(error_msg)
                
        except ImportError:
            raise Exception("需要安装requests库")
        except Exception as e:
            logger.error(f"vLLM处理错误: {str(e)}")
            raise Exception(f"vLLM处理错误: {str(e)}")

    def _chat_with_infer_service(self, 
                                prompt: str, 
                                max_tokens: int, 
                                temperature: float, 
                                top_p: float) -> str:
        """
        使用推理服务生成响应
        """
        try:
            # 尝试导入推理服务客户端
            from .llm.infer_service_client import get_infer_client
            INFER_SERVICE_AVAILABLE = True
        except ImportError:
            INFER_SERVICE_AVAILABLE = False
            raise Exception("推理服务客户端不可用")
        
        try:
            # 初始化推理服务客户端
            infer_client = get_infer_client()
            
            # 调用异步方法生成响应
            result = asyncio.run(infer_client.generate(
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p
            ))
            
            # 解析结果
            return result.get("text", "")
            
        except Exception as e:
            logger.error(f"推理服务处理错误: {str(e)}")
            raise Exception(f"推理服务处理错误: {str(e)}")

    def unload(self) -> bool:
        """
        卸载模型
        
        Returns:
            bool: 是否卸载成功
        """
        return self.unload_model()

    def health_check(self) -> Dict[str, Any]:
        """
        健康检查
        
        Returns:
            健康状态信息
        """
        try:
            result = {
                "status": "healthy",
                "model_type": self._model_type,
                "timestamp": time.time()
            }
            
            if self._model_type == 'transformers':
                # 检查本地模型
                result["model_loaded"] = self.is_loaded
                result["model_path"] = self.config["text_model_path"]
                
                if not self.is_loaded:
                    result["status"] = "warning"
                    result["message"] = "模型未加载，但可以按需加载"
                    
            elif self._model_type == 'ollama':
                # 测试Ollama API连接
                try:
                    import requests
                    url = f"{self.config['ollama_base_url']}/tags"
                    response = requests.get(url, timeout=5)
                    if response.status_code == 200:
                        result["ollama_connected"] = True
                        result["ollama_models"] = [model["name"] for model in response.json().get("models", [])]
                    else:
                        result["status"] = "unhealthy"
                        result["error"] = f"Ollama API连接失败: HTTP {response.status_code}"
                        result["ollama_connected"] = False
                except Exception as e:
                    result["status"] = "unhealthy"
                    result["error"] = f"Ollama连接错误: {str(e)}"
                    result["ollama_connected"] = False
                    
            elif self._model_type == 'vllm':
                # 测试vLLM API连接
                try:
                    # 使用简单的请求测试vLLM连接
                    test_prompt = "Hello, are you working?"
                    test_response = self._chat_with_vllm(test_prompt, 10, 0.7, 0.9)
                    result["vllm_connected"] = True
                    result["test_response"] = test_response[:50] + "..." if len(test_response) > 50 else test_response
                except Exception as e:
                    result["status"] = "unhealthy"
                    result["error"] = f"vLLM连接错误: {str(e)}"
                    result["vllm_connected"] = False
                    
            elif self._model_type == 'infer_service':
                # 测试推理服务连接
                try:
                    from .llm.infer_service_client import get_infer_client
                    infer_client = get_infer_client()
                    health_result = asyncio.run(infer_client.health_check())
                    result["infer_service_connected"] = True
                    result["health_status"] = health_result.get("status", "unknown")
                except Exception as e:
                    result["status"] = "unhealthy"
                    result["error"] = f"推理服务连接错误: {str(e)}"
                    result["infer_service_connected"] = False
                    
            return result
            
        except Exception as e:
            logger.error(f"健康检查失败: {str(e)}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": time.time()
            }


# 便捷函数
def create_text_adapter(config: Optional[Dict[str, Any]] = None) -> TextModelAdapter:
    """
    创建文本模型适配器实例
    
    Args:
        config: 配置参数
        
    Returns:
        TextModelAdapter实例
    """
    return TextModelAdapter(config)
