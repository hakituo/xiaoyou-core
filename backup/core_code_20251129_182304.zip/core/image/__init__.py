import asyncio
from typing import Dict, Optional, Any, List, Callable
from dataclasses import dataclass
import yaml
from pathlib import Path
import numpy as np
from PIL import Image
import io
from core.utils.logger import get_logger
from core.scheduler import get_global_scheduler, TaskPriority
from core.model_registry import global_model_registry

logger = get_logger("ImageModule")


@dataclass
class ImageConfig:
    """图像模型配置"""

    model_name: str
    device: str = "auto"  # auto, cpu, cuda
    output_width: int = 512
    output_height: int = 512
    num_inference_steps: int = 50
    guidance_scale: float = 7.5
    use_cache: bool = True
    model_path: Optional[str] = None


class ImageInterface:
    """图像模型接口抽象基类"""

    def __init__(self, config: ImageConfig):
        self.config = config
        self.is_initialized = False
        self._scheduler = get_global_scheduler()

    async def initialize(self):
        """初始化图像模型"""
        raise NotImplementedError

    async def generate(self, prompt: str, **kwargs) -> bytes:
        """生成图像"""
        raise NotImplementedError

    async def process(self, image_data: bytes, **kwargs) -> Dict[str, Any]:
        """处理图像（如识别、分类等）"""
        raise NotImplementedError

    async def shutdown(self):
        """关闭模型"""
        pass
class BaseImageModel(ImageInterface):
    """基础图像模型实现"""

    def __init__(self, config: ImageConfig):
        super().__init__(config)
        self._model = None
        self._tokenizer = None
        self._pipe = None

    async def initialize(self):
        """初始化基础图像模型"""
        if self.is_initialized:
            return

        # 确定设备
        if self.config.device == "auto":
            import torch

            self.config.device = "cuda" if torch.cuda.is_available() else "cpu"

        logger.info(
            f"正在初始化图像模型: {self.config.model_name} (设备: {self.config.device})"
        )
        self.is_initialized = True

    def _image_to_bytes(self, image) -> bytes:
        """将PIL图像或numpy数组转换为字节"""
        if isinstance(image, bytes):
            return image

        buffer = io.BytesIO()

        if isinstance(image, np.ndarray):
            # 确保是RGB格式
            if len(image.shape) == 2:
                image = np.stack((image,) * 3, axis=-1)
            elif image.shape[-1] == 4:
                image = image[..., :3]

            pil_image = Image.fromarray(image.astype("uint8"))
            pil_image.save(buffer, format="PNG")
        elif hasattr(image, "save"):
            # 假设是PIL图像
            image.save(buffer, format="PNG")
        else:
            raise ValueError(f"不支持的图像类型: {type(image)}")

        buffer.seek(0)
        return buffer.read()

    def _bytes_to_image(self, image_data: bytes) -> Image.Image:
        """将字节数据转换为PIL图像"""
        buffer = io.BytesIO(image_data)
        return Image.open(buffer)


class ImageModelFactory:
    """图像模型工厂类"""

    _creators: Dict[str, Callable] = {}

    @classmethod
    def register(cls, model_name: str, creator: Callable):
        """注册图像模型创建器"""
        cls._creators[model_name] = creator
        logger.info(f"注册图像模型创建器: {model_name}")

    @classmethod
    def create(cls, config: ImageConfig) -> ImageInterface:
        """创建图像模型实例"""
        if config.model_name not in cls._creators:
            # 默认返回基础模型
            logger.warning(f"未找到图像模型创建器: {config.model_name}，返回基础模型")
            return BaseImageModel(config)
        return cls._creators[config.model_name](config)
class ImageModelManager:
    """图像模型管理器"""

    def __init__(self):
        self._instances: Dict[str, ImageInterface] = {}
        self._default_instance_id: Optional[str] = None
        self._scheduler = get_global_scheduler()
        self._lock = asyncio.Lock()

        # 加载配置
        self._load_config()
        logger.info("图像模型管理器初始化完成")

    def _load_config(self):
        """加载图像模型配置"""
        config_path = Path("d:/AI/xiaoyou-core/configs/paths.yaml")
        if config_path.exists():
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = yaml.safe_load(f)
                    if (
                        config
                        and "model_paths" in config
                        and "image" in config["model_paths"]
                    ):
                        # 可以在这里添加更多配置处理
                        pass
            except Exception as e:
                logger.error(f"加载图像模型配置失败: {e}")

    async def create_instance(
        self, instance_id: str, config: ImageConfig
    ) -> ImageInterface:
        """
        创建图像模型实例

        Args:
            instance_id: 实例ID
            config: 图像模型配置

        Returns:
            图像模型实例
        """
        async with self._lock:
            if instance_id in self._instances:
                logger.warning(f"图像模型实例已存在: {instance_id}")
                return self._instances[instance_id]

            # 创建实例
            logger.info(f"创建图像模型实例: {instance_id} ({config.model_name})")
            model = ImageModelFactory.create(config)

            # 初始化模型
            await model.initialize()

            # 注册到模型注册表
            if hasattr(model, "_model") and model._model is not None:
                global_model_registry.register(
                    f"image_{instance_id}",
                    model._model,
                    metadata={
                        "model_name": config.model_name,
                        "instance_id": instance_id,
                        "device": config.device,
                    },
                )

            # 保存实例
            self._instances[instance_id] = model

            # 如果是第一个实例，设置为默认实例
            if self._default_instance_id is None:
                self._default_instance_id = instance_id
                logger.info(f"设置默认图像模型实例: {instance_id}")

            return model

    async def get_instance(self, instance_id: Optional[str] = None) -> ImageInterface:
        """
        获取图像模型实例

        Args:
            instance_id: 实例ID，如果为None则返回默认实例

        Returns:
            图像模型实例
        """
        if instance_id is None:
            instance_id = self._default_instance_id

        if instance_id is None:
            raise ValueError("没有可用的图像模型实例，请先创建实例")

        if instance_id not in self._instances:
            raise ValueError(f"图像模型实例不存在: {instance_id}")

        return self._instances[instance_id]
    async def generate_image(
        self, prompt: str, instance_id: Optional[str] = None, **kwargs
    ) -> bytes:
        """
        生成图像

        Args:
            prompt: 提示文本
            instance_id: 实例ID
            **kwargs: 额外参数

        Returns:
            图像数据（PNG格式）
        """
        model = await self.get_instance(instance_id)

        # 提交任务到调度器
        result = await self._scheduler.submit_task(
            model.generate, prompt, **kwargs, priority=TaskPriority.HIGH
        )

        return result

    async def process_image(
        self, image_data: bytes, instance_id: Optional[str] = None, **kwargs
    ) -> Dict[str, Any]:
        """
        处理图像

        Args:
            image_data: 图像数据
            instance_id: 实例ID
            **kwargs: 额外参数

        Returns:
            处理结果
        """
        model = await self.get_instance(instance_id)

        # 提交任务到调度器
        result = await self._scheduler.submit_task(
            model.process, image_data, **kwargs, priority=TaskPriority.NORMAL
        )

        return result

    async def delete_instance(self, instance_id: str):
        """
        删除图像模型实例

        Args:
            instance_id: 实例ID
        """
        async with self._lock:
            if instance_id not in self._instances:
                raise ValueError(f"图像模型实例不存在: {instance_id}")

            # 关闭实例
            model = self._instances[instance_id]
            await model.shutdown()

            # 从模型注册表中移除
            global_model_registry.unload(f"image_{instance_id}")

            # 删除实例
            del self._instances[instance_id]
            logger.info(f"已删除图像模型实例: {instance_id}")

            # 如果删除的是默认实例，选择新的默认实例
            if self._default_instance_id == instance_id:
                if self._instances:
                    self._default_instance_id = next(iter(self._instances.keys()))
                    logger.info(
                        f"设置新的默认图像模型实例: {self._default_instance_id}"
                    )
                else:
                    self._default_instance_id = None
    async def shutdown(self):
        """关闭所有实例"""
        instance_ids = list(self._instances.keys())
        for instance_id in instance_ids:
            await self.delete_instance(instance_id)

        logger.info("图像模型管理器已关闭")

    async def create_and_use(
        self, instance_id: str, config: ImageConfig
    ) -> ImageInterface:
        """
        创建并使用图像模型实例（便捷方法）

        Args:
            instance_id: 实例ID
            config: 图像模型配置

        Returns:
            图像模型实例
        """
        model = await self.create_instance(instance_id, config)
        self.set_default_instance(instance_id)
        return model


# 全局图像模型管理器实例
def get_global_image_manager() -> ImageModelManager:
    """获取全局图像模型管理器实例"""
    if not hasattr(get_global_image_manager, "_instance"):
        get_global_image_manager._instance = ImageModelManager()
    return get_global_image_manager._instance


class ImageModule:
    """图像模块"""

    def __init__(self, use_proxy: bool = False):
        self._image_manager = None
        self._is_initialized = False
        self.use_proxy = use_proxy
        self.proxy_client = None

    async def initialize(self):
        """初始化图像模块"""
        if self._is_initialized:
            return

        logger.info("正在初始化图像模块...")
        logger.info(f"使用代理模式: {self.use_proxy}")
        
        if self.use_proxy:
            # 代理模式：初始化代理客户端
            try:
                from core.image.image_service_client import get_image_service_client
                self.proxy_client = get_image_service_client()
                
                # 尝试连接到代理服务
                connected = await self.proxy_client.connect()
                if connected:
                    logger.info("成功连接到图像服务代理")
                else:
                    logger.warning("连接图像服务代理失败，将尝试直接模式")
                    self.use_proxy = False
                    self.proxy_client = None
            except ImportError as e:
                logger.warning(f"无法导入代理客户端: {str(e)}，使用直接模式")
                self.use_proxy = False
        
        if not self.use_proxy:
            # 直接模式：获取全局图像模型管理器
            self._image_manager = get_global_image_manager()

        self._is_initialized = True
        logger.info("图像模块初始化完成")

    async def create_model_instance(
        self, instance_id: str, config: ImageConfig
    ) -> ImageInterface:
        """创建图像模型实例"""
        if not self._is_initialized:
            await self.initialize()

        return await self._image_manager.create_instance(instance_id, config)

    async def generate_image(
        self, prompt: str, instance_id: Optional[str] = None, **kwargs
    ) -> bytes:
        """生成图像"""
        if not self._is_initialized:
            await self.initialize()
        
        if self.use_proxy and self.proxy_client:
            # 代理模式
            logger.info(f"代理模式: 生成图像 {prompt[:50]}...")
            
            # 发送请求到代理服务
            response = await self.proxy_client.generate_image(
                prompt=prompt,
                width=kwargs.get('width', 512),
                height=kwargs.get('height', 512),
                num_inference_steps=kwargs.get('num_inference_steps', 1),
                guidance_scale=kwargs.get('guidance_scale', 0.0),
                instance_id=instance_id or "default",
                save_to_file=kwargs.get("save_to_file", False)
            )
            
            # 从响应中获取图像数据
            if response.get("status") == "success" and response.get("image_data"):
                image_hex = response["image_data"]
                image_data = bytes.fromhex(image_hex)
                logger.info("图像生成成功 (代理模式)")
                return image_data
            else:
                raise RuntimeError(f"代理生成图像失败: {response.get('error', '未知错误')}")

        return await self._image_manager.generate_image(prompt, instance_id, **kwargs)

    async def process_image(
        self, image_data: bytes, instance_id: Optional[str] = None, **kwargs
    ) -> Dict[str, Any]:
        """处理图像"""
        if not self._is_initialized:
            await self.initialize()
            
        if self.use_proxy and self.proxy_client:
            # 代理模式
            logger.info("代理模式: 处理图像")
            
            # 发送请求到代理服务
            response = await self.proxy_client.process_image(
                image_data=image_data,
                instance_id=instance_id or "default"
            )
            
            return response

        return await self._image_manager.process_image(
            image_data, instance_id, **kwargs
        )
    async def shutdown(self):
        """关闭模块"""
        if not self._is_initialized:
            return

        logger.info("正在关闭图像模块...")
        
        # 关闭代理客户端
        if self.proxy_client:
            await self.proxy_client.disconnect()
            self.proxy_client = None

        # 关闭图像管理器
        if self._image_manager:
            await self._image_manager.shutdown()

        self._is_initialized = False
        logger.info("图像模块已关闭")


# 获取全局图像模块实例

def get_image_module(use_proxy: bool = None) -> ImageModule:
    """获取全局图像模块实例"""
    # 自动检测是否使用代理
    _default_use_proxy = False
    
    # 检查环境变量
    import os
    if "XIAOYOU_IMAGE_USE_PROXY" in os.environ:
        _default_use_proxy = os.environ["XIAOYOU_IMAGE_USE_PROXY"].lower() in ("true", "1", "yes")
    
    # 检查虚拟环境
    venv_name = os.environ.get("VIRTUAL_ENV", "")
    if "venv_base" in venv_name:
        # 在base环境中默认使用代理
        _default_use_proxy = True
    
    # 确定是否使用代理
    actual_use_proxy = _default_use_proxy if use_proxy is None else use_proxy
    
    if not hasattr(get_image_module, "_instance"):
        get_image_module._instance = ImageModule(use_proxy=actual_use_proxy)
    else:
        # 如果已存在实例但代理设置不同，则重新创建
        if get_image_module._instance.use_proxy != actual_use_proxy:
            import asyncio
            logger.warning(f"重新创建图像模块实例 (代理设置从 {get_image_module._instance.use_proxy} 改为 {actual_use_proxy})")
            # 关闭旧实例
            asyncio.create_task(get_image_module._instance.shutdown())
            # 创建新实例
            get_image_module._instance = ImageModule(use_proxy=actual_use_proxy)
            
    return get_image_module._instance


# 模块级便捷函数
async def generate_image(
    prompt: str, instance_id: Optional[str] = None, **kwargs
) -> bytes:
    """模块级图像生成函数"""
    module = get_image_module()
    return await module.generate_image(prompt, instance_id, **kwargs)


async def process_image(
    image_data: bytes, instance_id: Optional[str] = None, **kwargs
) -> Dict[str, Any]:
    """模块级图像处理函数"""
    module = get_image_module()
    return await module.process_image(image_data, instance_id, **kwargs)


async def create_model_instance(
    instance_id: str, config: ImageConfig
) -> ImageInterface:
    """模块级创建模型实例函数"""
    module = get_image_module()
    return await module.create_model_instance(instance_id, config)


async def get_module_status() -> Dict[str, Any]:
    """获取模块状态"""
    module = get_image_module()
    return module.get_status()


# 辅助函数
# 导出所有公共接口
__all__ = [
    # 核心类
    "ImageConfig",
    "ImageInterface",
    "BaseImageModel",
    "ImageModelFactory",
    "ImageModelManager",
    "ImageModule",
    # 获取实例的函数
    "get_global_image_manager",
    "get_image_module",
    # 便捷函数
    "generate_image",
    "process_image",
    "create_model_instance",
    "get_module_status",
    "save_image",
    "load_image",
]

# 模块说明
__doc__ = """
图像处理模块 (Image Module)

该模块提供了统一的图像生成与处理接口，支持多种模型管理和异步调度。

主要特性：
- 支持图像生成模型
- 支持图像处理（识别、分类等）
- 异步处理与全局调度器集成
- 自动设备选择（CPU/CUDA）
- 模型注册表集成

使用示例：

```python
import asyncio
from core.image import (
    ImageConfig, 
    create_model_instance, 
    generate_image, 
    process_image,
    get_image_module,
    save_image
)

async def example():
    # 创建图像模型实例
    config = ImageConfig(
        model_name="stable-diffusion",
        device="auto",
        output_width=512,
        output_height=512,
        num_inference_steps=30,
        guidance_scale=7.5
    )
    
    await create_model_instance("default_image_model", config)
    
    # 生成图像
    image_data = await generate_image("一只可爱的小猫坐在草地上")
    
    # 保存图像
    save_image(image_data, "output/cat.png")
    
    # 处理图像
    result = await process_image(image_data)
    print(f"图像处理结果: {result}")
    
    # 或者使用模块实例
    image_module = get_image_module()
    await image_module.initialize()
    
    # 关闭模块
    await image_module.shutdown()

# 运行示例
if __name__ == "__main__":
    asyncio.run(example())
```
"""

# 模块版本
__version__ = "1.0.0"
