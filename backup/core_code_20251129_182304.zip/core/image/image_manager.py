#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
图像管理器
负责管理图像模型的生命周期和图像生成处理
"""

import asyncio
import logging
import os
import uuid
import tempfile
from datetime import datetime
from typing import Dict, Any, Optional, Union
from pathlib import Path

# 导入必要的机器学习库
import torch
from diffusers import FluxPipeline

# 导入项目模块
# 注意：确保这些模块的路径在 sys.path 中
try:
    from core.utils.logger import get_logger
    from core.task_scheduler import get_global_scheduler, TaskPriority
    from core.model_registry import global_model_registry
    from core.config_manager import get_config_manager
    from core.image.prompt_processor import get_global_prompt_processor, process_image_prompt
    from core.resource_manager import (
        get_global_resource_manager, 
        ResourcePriority, 
        get_current_memory_usage,
        cleanup_memory
    )
except ImportError as e:
    print(f"CRITICAL: Failed to import core modules: {e}")
    # 提供一个备用的 get_logger
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("IMAGE_MANAGER_FALLBACK")
    print("Using fallback logger.")
    
    # 定义备用函数和类，以允许文件至少能被解析
    def get_global_resource_manager(): return None
    def get_global_prompt_processor(): return None
    def process_image_prompt(prompt, **kwargs): return {**kwargs, "prompt": prompt, "negative_prompt": ""}
    
    class MockGlobalModelRegistry:
        def register(self, *args, **kwargs): pass
        def unload(self, *args, **kwargs): pass
    global_model_registry = MockGlobalModelRegistry()

    class MockResourceManager:
        def optimize_resources(self): pass
        def get_optimal_precision(self): return "fp16"
        def should_use_low_memory_mode(self): return True
        def register_memory_cleanup_callback(self, *args, **kwargs): pass
        def unregister_memory_cleanup_callback(self, *args, **kwargs): pass
        def register_model(self, *args, **kwargs): pass
        def unregister_model(self, *args, **kwargs): pass
        def is_memory_pressure_high(self): return False
        def record_resource_usage(self, *args, **kwargs): pass
    
    original_get_global_resource_manager = get_global_resource_manager
    async def get_global_resource_manager():
        return MockResourceManager()

    logger.warning("Core modules import failed. Using mock objects.")


logger = get_logger("IMAGE_MANAGER")

# 图像输出目录
DEFAULT_IMAGE_OUTPUT_DIR = Path("d:\\AI\\xiaoyou-core") / "output" / "image"

class ImageGenerationConfig:
    """
    图像生成配置类
    """
    def __init__(self,
                 width: int = 512,
                 height: int = 512,
                 num_inference_steps: int = 30,
                 guidance_scale: float = 7.5,
                 seed: Optional[int] = None,
                 negative_prompt: Optional[str] = None,
                 lora_path: Optional[str] = None,
                 lora_weight: float = 0.7,
                 **kwargs):
        self.width = width
        self.height = height
        self.num_inference_steps = num_inference_steps
        self.guidance_scale = guidance_scale
        self.seed = seed
        self.negative_prompt = negative_prompt
        self.lora_path = lora_path
        self.lora_weight = lora_weight
        self.additional_params = kwargs

# 模型路径常量定义
CHECKPOINT_DIR = "d:\\AI\\xiaoyou-core\\models\\check_point"
ARCHIVE_DIR = "d:\\AI\\xiaoyou-core\\models\\archive"

class ImageManager:
    """
    图像管理器类
    负责图像模型的初始化、图像生成和资源管理
    """
    def __init__(self):
        self._models: Dict[str, Any] = {}
        self._default_model_id: Optional[str] = None
        self._is_initialized = False
        self._lock = asyncio.Lock()
        self._output_dir = DEFAULT_IMAGE_OUTPUT_DIR
        
        # 确保输出目录存在
        self._ensure_output_dir()
        
        # 资源管理器
        self._resource_manager = None
        
        # 性能统计
        self._performance_stats = {
            'total_generations': 0,
            'total_time': 0,
            'avg_time': 0,
            'peak_memory': 0
        }
        
        logger.info("图像管理器已初始化")
    
    def _ensure_output_dir(self):
        """
        确保输出目录存在
        """
        try:
            self._output_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"图像输出目录: {self._output_dir}")
        except Exception as e:
            logger.error(f"创建图像输出目录失败: {e}")
    
    async def initialize(self) -> bool:
        """
        初始化图像管理器
        """
        if self._is_initialized:
            return True
        
        try:
            # 加载配置
            # config_manager = get_config_manager()
            # image_config = config_manager.get_config("image", {})
            image_config = {} # 简化，避免依赖
            
            # 设置输出目录（如果配置中有）
            if "output_dir" in image_config:
                self._output_dir = Path(image_config["output_dir"])
                self._ensure_output_dir()
            
            # 尝试获取资源管理器
            try:
                self._resource_manager = await get_global_resource_manager()
                if self._resource_manager:
                    self._resource_manager.register_memory_cleanup_callback(self._cleanup_memory)
            except Exception as resource_err:
                logger.warning(f"获取资源管理器失败: {resource_err}，将在无资源管理器的情况下继续")
                self._resource_manager = None
            
            # 初始化默认模型（如果配置中有）
            if "default_model" in image_config:
                try:
                    await self.load_model(
                        image_config["default_model"],
                        model_type=image_config.get("model_type", "diffusion")
                    )
                except Exception as model_err:
                    logger.warning(f"初始化默认模型失败: {model_err}，将继续初始化")
            
            self._is_initialized = True
            logger.info("图像管理器初始化完成")
            return True
        except Exception as e:
            logger.error(f"图像管理器初始化失败: {e}")
            self._is_initialized = True # 即使失败也标记，避免重复尝试
            return False # 返回 False
    
    async def load_model(self, model_id: str, model_type: str = "diffusion", config: Optional[Dict[str, Any]] = None) -> bool:
        """
        加载图像模型 - 修复版：包含真实加载逻辑
        """
        async with self._lock:
            try:
                if model_id in self._models:
                    logger.info(f"模型 {model_id} 已加载")
                    return True
                
                if self._resource_manager:
                    await self._resource_manager.optimize_resources()
                    if config is None: config = {}
                    config['generation'] = config.get('generation', {})
                    config['generation']['low_vram_mode'] = self._resource_manager.should_use_low_memory_mode()
                
                logger.info(f"正在加载真实图像模型: {model_id} (类型: {model_type})")
                
                real_model = None
                
                # 检查是否是在线模型名称（不包含路径分隔符的简单字符串）
                is_online_model = '/' in model_id and not os.path.exists(model_id)
                if is_online_model:
                    logger.info(f"检测到在线模型名称: {model_id}，将从Hugging Face下载")
                elif not os.path.exists(model_id):
                    possible_path = r"d:\AI\xiaoyou-core\models\archive"
                    logger.info(f"[图像生成] 检查模型路径: {possible_path}")
                    if os.path.exists(possible_path):
                        model_id = possible_path
                        logger.info(f"[图像生成] 使用模型路径: {model_id}")
                    else:
                        logger.error(f"模型路径不存在: {possible_path}")
                        raise FileNotFoundError(f"模型路径不存在: {model_id}")

                try:
                    if "flux" in model_id.lower() or "flux" in model_type.lower():
                        logger.info("检测到 Flux 模型，正在初始化 Diffusers Pipeline...")
                        
                        import gc
                        gc.collect()
                        torch.cuda.empty_cache()
                        torch.cuda.ipc_collect()

                        # ======================================================
                        # 关键修复：移除 device_map，仅使用 low_cpu_mem_usage
                        # 和 enable_sequential_cpu_offload。
                        # 这通常是用于低VRAM环境的最稳定组合。
                        # ======================================================
                        
                        if os.path.isfile(model_id):
                             logger.info(f"使用 from_single_file 加载 Flux 模型: {model_id}")
                             pipe = FluxPipeline.from_single_file(
                                model_id,
                                torch_dtype=torch.bfloat16,
                                use_safetensors=True,
                                low_cpu_mem_usage=True,
                            )
                        else:
                            logger.info(f"使用 from_pretrained 加载 Flux 模型: {model_id}")
                            pipe = FluxPipeline.from_pretrained(
                                model_id,
                                torch_dtype=torch.bfloat16,
                                use_safetensors=True,
                                low_cpu_mem_usage=True,     # 降低加载时的内存占用
                                # 移除: device_map="balanced" 
                            )

                        # 强制使用最节省显存的顺序CPU卸载策略
                        logger.info("强制启用顺序 CPU 卸载以防止崩溃...")
                        pipe.enable_sequential_cpu_offload() # <--- 确保这是 *唯一* 的卸载策略
                        
                        # VAE 优化
                        pipe.vae.enable_slicing()
                        pipe.vae.enable_tiling()
                        
                        real_model = pipe
                    else:
                        from diffusers import StableDiffusionPipeline
                        try:
                            from diffusers import StableDiffusionXLPipeline
                        except Exception:
                            StableDiffusionXLPipeline = None
                    
                        # 检查是否为safetensors文件
                        if model_id.endswith('.safetensors'):
                            # 首先检查文件名中是否有'nsffw'拼写错误
                            if 'nsffw' in model_id.lower():
                                # 修复拼写错误
                                corrected_model_id = model_id.replace('nsffw', 'nsfw', 1)
                                logger.warning(f"修复文件名拼写错误: {model_id} -> {corrected_model_id}")
                                # 检查修正后的文件是否存在
                                if os.path.exists(corrected_model_id):
                                    logger.info(f"修正后的文件存在，使用: {corrected_model_id}")
                                    model_id = corrected_model_id
                                else:
                                    logger.warning(f"修正后的文件不存在: {corrected_model_id}，尝试使用原始路径")
                            # 另外，即使文件名正确，但如果文件不存在，也尝试检查是否存在拼写错误的版本
                            elif not os.path.exists(model_id):
                                # 尝试修正文件名并检查
                                possible_corrected_id = model_id.replace('nsfw', 'nsffw', 1)
                                if os.path.exists(possible_corrected_id):
                                    logger.warning(f"检测到可能的拼写错误文件存在: {possible_corrected_id}，尝试使用")
                                    model_id = possible_corrected_id
                            is_sdxl = ('sdxl' in os.path.basename(model_id).lower()) or ('xl' in os.path.basename(model_id).lower())
                            if is_sdxl and StableDiffusionXLPipeline is not None:
                                logger.info(f"检测到SDXL模型，使用StableDiffusionXLPipeline.from_single_file加载: {model_id}")
                                real_model = StableDiffusionXLPipeline.from_single_file(
                                    model_id,
                                    torch_dtype=torch.float16,
                                    low_cpu_mem_usage=True
                                )
                            else:
                                logger.info(f"检测到safetensors文件，使用StableDiffusionPipeline.from_single_file加载: {model_id}")
                                real_model = StableDiffusionPipeline.from_single_file(
                                    model_id,
                                    torch_dtype=torch.float16,
                                    low_cpu_mem_usage=True,
                                    safety_checker=None
                                )
                            # 优化内存使用
                            if torch.cuda.is_available():
                                real_model.enable_sequential_cpu_offload()
                            else:
                                real_model.enable_attention_slicing()
                        else:
                            # 普通模型文件
                            is_sdxl_dir = ('sdxl' in os.path.basename(model_id).lower()) or ('xl' in os.path.basename(model_id).lower())
                            if is_sdxl_dir and StableDiffusionXLPipeline is not None:
                                logger.info(f"使用StableDiffusionXLPipeline.from_pretrained加载模型: {model_id}")
                                real_model = StableDiffusionXLPipeline.from_pretrained(
                                    model_id,
                                    torch_dtype=torch.float16,
                                    use_safetensors=False,
                                    low_cpu_mem_usage=True
                                )
                            else:
                                logger.info(f"使用标准StableDiffusionPipeline.from_pretrained加载模型: {model_id}")
                                real_model = StableDiffusionPipeline.from_pretrained(
                                    model_id, 
                                    torch_dtype=torch.float16,
                                    use_safetensors=False,
                                    low_cpu_mem_usage=True
                                )
                        
                    # 根据可用设备移动模型
                    if torch.cuda.is_available():
                        real_model = real_model.to("cuda")
                    else:
                        real_model = real_model.to("cpu")
                        
                except Exception as load_err:
                    logger.error(f"Diffusers 加载失败: {load_err}")
                    import traceback
                    traceback.print_exc() # 打印完整的错误堆栈
                    raise load_err

                model_instance = {
                    "model_id": model_id,
                    "model_type": model_type,
                    "config": config,
                    "model": real_model,  # <--- 放入真正的模型对象
                    "loaded_at": asyncio.get_event_loop().time()
                }
                
                # 关键修复：显式添加模型到字典并确认
                try:
                    self._models[model_id] = model_instance
                    logger.info(f"模型 {model_id} 已添加到模型字典，字典长度: {len(self._models)}")
                    logger.info(f"模型字典当前键: {list(self._models.keys())}")
                except Exception as dict_err:
                    logger.error(f"将模型添加到字典失败: {dict_err}")
                    raise
                
                # 尝试注册到全局注册表 (容错)
                try:
                    global_model_registry.register(f"image_{model_id}", model_instance, metadata={"model_id": model_id, "model_type": model_type, "category": "image"})
                    logger.info(f"模型已注册到全局注册表")
                except Exception as registry_err:
                    logger.warning(f"注册模型到全局注册表失败 (将继续使用): {registry_err}")
                
                # 尝试注册到资源管理器 (容错)
                if self._resource_manager:
                    try:
                        self._resource_manager.register_model(model_id=model_id, model_type='image_gen', priority=ResourcePriority.MEDIUM, load_func=lambda: True, unload_func=lambda: True, memory_usage_mb=500)
                        logger.info(f"模型已注册到资源管理器")
                    except Exception as resource_err:
                        logger.warning(f"注册模型到资源管理器失败 (将继续使用): {resource_err}")
                
                # 关键修复：强制设置默认模型ID，确保不为None
                try:
                    self._default_model_id = model_id
                    logger.info(f"已设置默认图像模型ID: {self._default_model_id}")
                except Exception as default_err:
                    logger.error(f"设置默认模型失败: {default_err}")
                
                logger.info(f"图像模型加载成功: {model_id}")
                return True
            
            except Exception as e:
                logger.error(f"加载图像模型失败 {model_id}: {e}")
                import traceback
                traceback.print_exc() # 确保打印崩溃的详细信息
                return False
    
    async def unload_model(self, model_id: Optional[str] = None) -> bool:
        # (保持不变)
        async with self._lock:
            try:
                if model_id is None:
                    model_id = self._default_model_id
                
                if model_id is None or model_id not in self._models:
                    logger.error(f"模型不存在: {model_id}")
                    return False
                
                logger.info(f"正在卸载图像模型: {model_id}")
                
                try:
                    global_model_registry.unload(f"image_{model_id}")
                except Exception as e:
                    logger.error(f"从模型注册表移除失败: {e}")
                
                if self._resource_manager:
                    self._resource_manager.unregister_model(model_id)
                
                # 显式删除模型对象以帮助释放 VRAM
                if "model" in self._models[model_id]:
                    del self._models[model_id]["model"]
                    
                del self._models[model_id]
                
                # 垃圾回收
                import gc
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                
                if self._default_model_id == model_id:
                    if self._models:
                        self._default_model_id = next(iter(self._models.keys()))
                        logger.info(f"设置新的默认图像模型: {self._default_model_id}")
                    else:
                        self._default_model_id = None
                
                logger.info(f"图像模型卸载成功: {model_id}")
                return True
            except Exception as e:
                logger.error(f"卸载图像模型失败 {model_id}: {e}")
                return False
    
    async def generate_image(self,
                           prompt: str,
                           config: Optional[ImageGenerationConfig] = None,
                           model_id: Optional[str] = None,
                           save_to_file: bool = True) -> Dict[str, Any]:
        """
        生成图像
        """
        logger.info(f"[图像生成请求] 提示词: {prompt[:30]}...")
        
        if not prompt or not prompt.strip():
            logger.error("[图像生成请求] 空提示词")
            return {"success": False, "error": "空提示词", "error_code": "EMPTY_PROMPT"}
        
        if not self._is_initialized:
            logger.info("[图像生成请求] 图像管理器未初始化，正在初始化...")
            init_success = await self.initialize()
            if not init_success:
                logger.error("[图像生成请求] 图像管理器初始化失败")
                return {"success": False, "error": "图像管理器初始化失败", "error_code": "INITIALIZATION_FAILED"}
        
        # ==========================================================
        # 关键修复：修复自动加载逻辑
        # ==========================================================
        
        # 1. 确定要使用的 model_id
        # 关键修复：增强模型ID选择逻辑，确保始终有一个有效的模型ID
        logger.info(f"[图像生成请求] 当前默认模型ID: {self._default_model_id}")
        logger.info(f"[图像生成请求] 当前模型字典键: {list(self._models.keys())}")
        
        use_model_id = model_id or self._default_model_id
        logger.info(f"[图像生成请求] 尝试使用模型: {use_model_id}")
        
        # 检查模型ID是否可能存在拼写错误，并提前处理
        if use_model_id and 'nsfw' in use_model_id.lower():
            # 如果只提供了文件名而不是完整路径，构建可能的路径
            if not os.path.exists(use_model_id) and not os.path.isabs(use_model_id):
                # 尝试构建完整路径并检查
                full_path = os.path.join(CHECKPOINT_DIR, use_model_id)
                # 检查原始路径
                if os.path.exists(full_path):
                    logger.info(f"[图像生成请求] 找到完整路径: {full_path}")
                    use_model_id = full_path
                # 检查可能的拼写错误版本
                elif 'nsfw' in use_model_id.lower():
                    possible_spelled_id = use_model_id.replace('nsfw', 'nsffw', 1)
                    possible_path = os.path.join(checkpoint_dir, possible_spelled_id)
                    if os.path.exists(possible_path):
                        logger.warning(f"[图像生成请求] 找到可能的拼写错误文件: {possible_path}")
                        use_model_id = possible_path
        
        # 2. 检查模型是否已加载
        if use_model_id is None or use_model_id not in self._models:
            error_msg = f"模型 {use_model_id} 不可用"
            logger.error(f"[图像生成请求] {error_msg}")
            logger.info("[图像生成请求] 尝试自动加载默认模型...")
            
            # 额外的日志记录模型字典状态
            logger.info(f"[图像生成请求] 模型字典当前状态: 长度={len(self._models)}, 键={list(self._models.keys())}")
            
            _loaded_model_id = None # 用于在循环外获取ID
            
            try:
                checkpoint_dir = CHECKPOINT_DIR
                models_dir = "d:\\AI\\xiaoyou-core\\models"
                flux_paths = []
                search_dirs = [checkpoint_dir, models_dir]
                for search_dir in search_dirs:
                    logger.debug(f"[图像生成请求] 检查目录: {search_dir}")
                    if os.path.exists(search_dir):
                        try:
                            for root, _, files in os.walk(search_dir):
                                for f in files:
                                    if f.endswith('.safetensors') or f.endswith('.ckpt'):
                                        file_path = os.path.join(root, f)
                                        flux_paths.append(file_path)
                                        logger.debug(f"[图像生成请求] 发现模型文件: {file_path}")
                                        if 'nsffw' in f.lower():
                                            corrected_file = f.replace('nsffw', 'nsfw', 1)
                                            corrected_path = os.path.join(root, corrected_file)
                                            if os.path.exists(corrected_path):
                                                flux_paths.append(corrected_path)
                        except Exception as e:
                            logger.error(f"[图像生成请求] 读取目录 {search_dir} 失败: {e}")
                    else:
                        logger.warning(f"[图像生成请求] 目录不存在: {search_dir}")
                special_dir = os.path.join(models_dir, 'stable-diffusion-webui-forge-main', 'models', 'Stable-diffusion')
                if os.path.exists(special_dir):
                    try:
                        for root, _, files in os.walk(special_dir):
                            for f in files:
                                if f.endswith('.safetensors') or f.endswith('.ckpt'):
                                    flux_paths.append(os.path.join(root, f))
                    except Exception as e:
                        logger.error(f"[图像生成请求] 读取目录 {special_dir} 失败: {e}")
                if use_model_id and not os.path.isabs(use_model_id) and use_model_id not in self._models:
                    try:
                        for p in flux_paths:
                            if os.path.basename(p) == use_model_id:
                                _loaded_model_id = p
                                break
                    except Exception:
                        pass
                for flux_path in flux_paths:
                    if os.path.exists(flux_path):
                        logger.info(f"[图像生成请求] 尝试加载模型: {flux_path}")
                        model_type = "flux" if "flux" in flux_path.lower() else "stable_diffusion"
                        if flux_path.endswith('.safetensors') and "flux" not in flux_path.lower():
                            model_type = "stable_diffusion"
                        load_success = await self.load_model(flux_path, model_type=model_type)
                        if load_success:
                            _loaded_model_id = flux_path
                            logger.info(f"[图像生成请求] 成功加载本地模型: {_loaded_model_id}")
                            break
                        else:
                            logger.warning(f"[图像生成请求] 加载模型失败: {flux_path}")
                    else:
                        logger.warning(f"[图像生成请求] 模型路径不存在: {flux_path}")
            except Exception as auto_load_error:
                logger.error(f"[图像生成请求] 自动加载模型异常: {auto_load_error}")
            
            # 循环后，使用 _loaded_model_id 更新 use_model_id
            if _loaded_model_id:
                use_model_id = _loaded_model_id
                # 关键修复：显式更新默认模型ID并确认
                self._default_model_id = _loaded_model_id
                logger.info(f"[图像生成请求] 已更新默认模型ID: {self._default_model_id}")
                logger.info(f"[图像生成请求] 更新后模型字典: 长度={len(self._models)}, 键={list(self._models.keys())}")
            
            # 最终检查：如果仍然没有可用模型，返回错误
            if use_model_id is None or use_model_id not in self._models:
                logger.error(f"[图像生成请求] 自动加载失败，最终 model_id 为: {use_model_id}")
                logger.error(f"[图像生成请求] 模型字典最终状态: 长度={len(self._models)}, 键={list(self._models.keys())}")
                return {
                    "success": False,
                    "error": f"模型 {use_model_id} 不可用，自动加载失败",
                    "error_code": "MODEL_NOT_AVAILABLE"
                }
        # ==========================================================
        
        if config is None:
            config = ImageGenerationConfig()
            logger.info(f"[图像生成请求] 使用默认配置")
        
        # 直接执行图像生成
        try:
            result = await self._generate_image_impl(
                prompt=prompt,
                config=config,
                model_id=use_model_id, # <--- 确保传递最终确定的 model_id
                save_to_file=save_to_file
            )
            logger.info(f"[图像生成请求] 图像生成完成，结果: {'成功' if result.get('success', False) else '失败'}")
            return result
        except Exception as e:
            logger.error(f"[图像生成请求] 图像生成过程发生异常: {e}")
            import traceback
            traceback.print_exc()
            return {
                "success": False,
                "error": f"图像生成过程发生异常: {str(e)}",
                "error_code": "UNKNOWN_ERROR",
                "prompt": prompt[:50] + "..."
            }
    
    async def _generate_image_impl(self,
                                 prompt: str,
                                 config: ImageGenerationConfig,
                                 model_id: str,
                                 save_to_file: bool = True) -> Dict[str, Any]:
        """
        实际的图像生成实现
        """
        import traceback
        import numpy as np
        from PIL import Image, ImageDraw, ImageFont
        
        start_time = asyncio.get_event_loop().time()
        current_pid = os.getpid()
        start_memory = get_current_memory_usage() if self._resource_manager else 0
        generation_id = str(uuid.uuid4())
        
        logger.info(f"[图像生成-{generation_id}] 开始 - PID: {current_pid}, 模型: {model_id}")
        
        try:
            # 1. 处理提示词
            logger.info(f"[图像生成-{generation_id}] 处理提示词...")
            try:
                processed_input = await process_image_prompt(
                    prompt=prompt, width=config.width, height=config.height,
                    num_inference_steps=config.num_inference_steps, guidance_scale=config.guidance_scale,
                    seed=config.seed, custom_negative=config.negative_prompt
                )
            except Exception as prompt_error:
                logger.error(f"[图像生成-{generation_id}] 提示词处理失败: {prompt_error}")
                processed_input = {"prompt": prompt, "negative_prompt": config.negative_prompt or "", "width": config.width, "height": config.height, "num_inference_steps": config.num_inference_steps, "guidance_scale": config.guidance_scale, "seed": config.seed}
                logger.warning(f"[图像生成-{generation_id}] 使用原始提示词作为回退")
            
            processed_prompt = processed_input["prompt"]
            negative_prompt = processed_input["negative_prompt"]
            width = processed_input["width"]
            height = processed_input["height"]
            num_inference_steps = processed_input["num_inference_steps"]
            guidance_scale = processed_input["guidance_scale"]
            seed = processed_input.get("seed")
            
            logger.info(f"[图像生成-{generation_id}] 参数 - 尺寸: {width}x{height}, 步数: {num_inference_steps}")
            
            # 3. 资源管理 - 修复：使用安全的检查方式
            # 安全检查：避免调用不存在的方法
            memory_pressure_high = False
            if self._resource_manager:
                try:
                    memory_pressure_high = self._resource_manager.is_memory_pressure_high()
                    logger.info(f"[内存压力检查] 内存压力状态: {memory_pressure_high}")
                except AttributeError:
                    logger.warning(f"[内存压力检查] ResourceManager 没有 is_memory_pressure_high 方法")
                    memory_pressure_high = False
            
            if memory_pressure_high:
                logger.warning(f"[图像生成-{generation_id}] 检测到高内存压力，执行内存清理")
                await self._cleanup_memory()
            
            # 3. 准备文件路径
            image_id = str(uuid.uuid4())[:8]
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            image_filename = f"image_{timestamp}_{image_id}.png"
            image_path = str(self._output_dir / image_filename)
            
            try:
                os.makedirs(self._output_dir, exist_ok=True)
            except Exception as dir_error:
                logger.error(f"[图像生成-{generation_id}] 创建输出目录失败: {dir_error}")
                image_path = str(Path(tempfile.gettempdir()) / image_filename)
            
            logger.info(f"[图像生成-{generation_id}] 输出路径: {image_path}")

            # 4. 生成图像
            image_result = None
            try:
                model_info = self._models.get(model_id)
                if not model_info:
                    raise ValueError(f"模型 {model_id} 未在 _models 字典中找到")
                
                if "model" not in model_info or model_info["model"] is None:
                    logger.error(f"[图像生成-{generation_id}] 模型信息中未找到 'model' 实例！")
                    raise ValueError(f"模型 {model_id} 已加载但 'model' 实例为空")
                
                model = model_info["model"]
                logger.info(f"[图像生成-{generation_id}] 获取到模型实例: {type(model).__name__}")
                
                model_start_time = asyncio.get_event_loop().time()
                
                # 确定生成器
                generator = None
                if seed:
                    generator = torch.Generator(device="cuda" if torch.cuda.is_available() else "cpu").manual_seed(seed)

                if isinstance(model, FluxPipeline):
                    logger.info(f"[图像生成-{generation_id}] 调用 Flux Pipeline 生成...")
                    pipeline_output = await asyncio.to_thread(
                        model,
                        prompt=processed_prompt,
                        width=width,
                        height=height,
                        num_inference_steps=num_inference_steps,
                        guidance_scale=guidance_scale,
                        generator=generator,
                        output_type="pil"
                    )
                    image_result = pipeline_output.images[0]
                else:
                    # 其他模型的通用调用
                    logger.warning(f"[图像生成-{generation_id}] 模型类型 {type(model).__name__} 未知, 尝试标准调用")
                    # 准备生成参数，包含LoRA配置
                    gen_kwargs = {
                        "prompt": processed_prompt,
                        "width": width,
                        "height": height,
                        "num_inference_steps": num_inference_steps,
                        "guidance_scale": guidance_scale,
                        "generator": generator,
                        "output_type": "pil"
                    }
                    
                    # 应用LoRA（如果提供），避免将未知参数传入pipeline调用
                    try:
                        if hasattr(config, 'lora_path') and config.lora_path:
                            logger.info(f"[图像生成-{generation_id}] 尝试应用LoRA: {config.lora_path}")
                            if hasattr(model, 'load_lora_weights'):
                                model.load_lora_weights(config.lora_path)
                                if hasattr(model, 'fuse_lora'):
                                    try:
                                        model.fuse_lora(lora_scale=float(getattr(config, 'lora_weight', 0.7)))
                                    except Exception:
                                        pass
                            elif hasattr(model, 'unet') and hasattr(model.unet, 'load_attn_procs'):
                                model.unet.load_attn_procs(config.lora_path)
                                if hasattr(model, 'fuse_lora'):
                                    try:
                                        model.fuse_lora(lora_scale=float(getattr(config, 'lora_weight', 0.7)))
                                    except Exception:
                                        pass
                            else:
                                logger.warning(f"[图像生成-{generation_id}] 当前pipeline不支持自动应用LoRA")
                    except Exception as lora_err:
                        logger.warning(f"[图像生成-{generation_id}] 应用LoRA失败: {lora_err}")
                    
                    pipeline_output = await asyncio.to_thread(model, **gen_kwargs)
                    image_result = pipeline_output.images[0]
                
                model_time = asyncio.get_event_loop().time() - model_start_time
                logger.info(f"[图像生成-{generation_id}] 模型调用完成，耗时: {model_time:.2f}秒")
                
                # 5. 保存图像
                image_saved = False
                if isinstance(image_result, Image.Image):
                    logger.info(f"[图像生成-{generation_id}] 直接使用PIL.Image对象")
                    image_result.save(image_path, 'PNG')
                    image_saved = True
                
                if not image_saved:
                    logger.error(f"[图像生成-{generation_id}] 无法识别图像格式或保存失败")
                    raise IOError("无法识别或保存图像")
                    
                file_size = os.path.getsize(image_path) / 1024
                logger.info(f"[图像生成-{generation_id}] 图像保存成功，路径: {image_path}, 大小: {file_size:.2f}KB")
                        
            except Exception as e:
                error_trace = traceback.format_exc()
                logger.error(f"[图像生成-{generation_id}] 图像生成失败: {e}")
                logger.error(f"[图像生成-{generation_id}] 错误堆栈: {error_trace}")
                
                # 创建错误图像
                error_image = Image.new('RGB', (width, height), color=(255, 0, 0))
                draw = ImageDraw.Draw(error_image)
                draw.text((10, 10), f"Error: {str(e)[:60]}...", fill=(255, 255, 255))
                error_path = str(self._output_dir / f"error_{timestamp}_{image_id}.png")
                try:
                    error_image.save(error_path, 'PNG')
                    image_path = error_path
                except Exception as error_save_error:
                    logger.error(f"[图像生成-{generation_id}] 错误图像保存失败: {error_save_error}")
                
                raise # 重新抛出异常
            
            # 6. 构建成功结果
            generation_time = asyncio.get_event_loop().time() - start_time
            end_memory = get_current_memory_usage() if self._resource_manager else 0
            memory_used = end_memory - start_memory
            
            logger.info(f"[图像生成-{generation_id}] 生成完成，总耗时: {generation_time:.2f}秒")
            
            result = {
                "success": True,
                "image_id": image_id,
                "generation_id": generation_id,
                "prompt": processed_prompt,
                "width": width, "height": height,
                "num_inference_steps": num_inference_steps,
                "guidance_scale": guidance_scale,
                "seed": seed,
                "model_id": model_id,
                "generation_time": generation_time,
                "image_path": image_path if save_to_file else None, # 根据save_to_file决定是否返回路径
                "metadata": { "timestamp": timestamp, "memory_used_mb": memory_used, "status": "completed" }
            }
            
            if not save_to_file:
                # 如果不保存文件，则可能需要返回图像数据
                # result["image_data"] = ... (e.g., base64 encoded)
                # 并且删除临时文件
                if os.path.exists(image_path):
                    os.remove(image_path)
            
            self._update_performance_stats(generation_time)
            
            # 安全地调用资源管理器，避免AttributeError异常
            if self._resource_manager:
                try:
                    # self._resource_manager.record_resource_usage('image_gen', memory_used_mb=memory_used, execution_time_ms=int(generation_time * 1000))
                    pass  # 已注释掉可能导致崩溃的代码
                except AttributeError:
                    logger.warning("ResourceManager不支持record_resource_usage方法")
            
            return result
        
        except Exception as e:
            # 捕获所有 _generate_image_impl 内部的异常
            generation_time = asyncio.get_event_loop().time() - start_time
            error_type = type(e).__name__
            error_trace = traceback.format_exc()
            error_msg = str(e)
            
            logger.error(f"[图像生成-{generation_id}] 生成失败 - 类型: {error_type}, 消息: {error_msg}")
            logger.debug(f"[图像生成-{generation_id}] 错误堆栈: {error_trace}")
            
            return {
                "success": False, "error": error_msg, "error_type": error_type,
                "prompt": prompt[:100] + "...", "model_id": model_id,
                "error_code": "IMAGE_GENERATION_FAILED", "generation_id": generation_id,
                "generation_time": generation_time,
                "metadata": { "status": "failed" }
            }
    
    async def get_available_models(self) -> Dict[str, Dict[str, Any]]:
        # (保持不变)
        return {model_id: {
            "model_id": model_info["model_id"],
            "model_type": model_info["model_type"],
            "loaded_at": model_info["loaded_at"],
            "is_default": model_id == self._default_model_id
        } for model_id, model_info in self._models.items()}
    
    async def shutdown(self):
        # (保持不变)
        logger.info("正在关闭图像管理器...")
        model_ids = list(self._models.keys())
        for model_id in model_ids:
            await self.unload_model(model_id)
        if self._resource_manager:
            self._resource_manager.unregister_memory_cleanup_callback(self._cleanup_memory)
        self._is_initialized = False
        logger.info("图像管理器已关闭")
    
    async def _cleanup_memory(self):
        # (保持不变)
        logger.info("执行内存清理...")
        try:
            if len(self._models) > 1:
                for model_id in list(self._models.keys()):
                    if model_id != self._default_model_id:
                        await self.unload_model(model_id)
                        logger.info(f"清理内存时卸载了模型: {model_id}")
            import gc
            gc.collect()
            logger.info("内存清理完成")
            return True
        except Exception as e:
            logger.error(f"内存清理失败: {str(e)}")
            return False
    
    def _update_performance_stats(self, execution_time: float):
        # (保持不变)
        try:
            self._performance_stats['total_generations'] += 1
            self._performance_stats['total_time'] += execution_time
            self._performance_stats['avg_time'] = (self._performance_stats['total_time'] / self._performance_stats['total_generations'])
            current_memory = get_current_memory_usage()
            if current_memory > self._performance_stats['peak_memory']:
                self._performance_stats['peak_memory'] = current_memory
        except Exception as e:
            logger.error(f"更新性能统计失败: {str(e)}")

    def discover_local_models(self) -> list:
        try:
            checkpoint_dir = CHECKPOINT_DIR
            models_dir = "d:\\AI\\xiaoyou-core\\models"
            paths = []
            for search_dir in [checkpoint_dir, models_dir]:
                if os.path.exists(search_dir):
                    for root, _, files in os.walk(search_dir):
                        for f in files:
                            if f.endswith('.safetensors') or f.endswith('.ckpt'):
                                paths.append(os.path.join(root, f))
            special_dir = os.path.join(models_dir, 'stable-diffusion-webui-forge-main', 'models', 'Stable-diffusion')
            if os.path.exists(special_dir):
                for root, _, files in os.walk(special_dir):
                    for f in files:
                        if f.endswith('.safetensors') or f.endswith('.ckpt'):
                            paths.append(os.path.join(root, f))
            return paths
        except Exception:
            return []

# 全局图像管理器实例
_image_manager_instance = None
_image_manager_lock = asyncio.Lock()

async def get_global_image_manager() -> ImageManager:
    # (保持不变)
    global _image_manager_instance
    async with _image_manager_lock:
        if _image_manager_instance is None:
            _image_manager_instance = ImageManager()
            await _image_manager_instance.initialize()
    return _image_manager_instance

# 别名函数
async def get_image_manager() -> ImageManager:
    # (保持不变)
    return await get_global_image_manager()

# 便捷函数
async def generate_image(prompt: str, **kwargs) -> Dict[str, Any]:
    manager = await get_global_image_manager()
    config = None
    if any(k in kwargs for k in ["width", "height", "num_inference_steps", "guidance_scale", "lora_path", "lora_weight", "seed", "negative_prompt"]):
        config = ImageGenerationConfig(
            width=kwargs.pop("width", 512),
            height=kwargs.pop("height", 512),
            num_inference_steps=kwargs.pop("num_inference_steps", 30),
            guidance_scale=kwargs.pop("guidance_scale", 7.5),
            seed=kwargs.pop("seed", None),
            negative_prompt=kwargs.pop("negative_prompt", None),
            lora_path=kwargs.pop("lora_path", None),
            lora_weight=kwargs.pop("lora_weight", 0.7)
        )
    return await manager.generate_image(prompt, config=config, **kwargs)

# 模块版本
__version__ = "1.0.0"
