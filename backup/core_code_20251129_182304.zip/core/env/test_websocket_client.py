import unittest
from core.env.websocket_client import WebSocketMessage, WebSocketClient


class TestWebSocketClient(unittest.TestCase):
    def test_message_dict_roundtrip(self):
        payload = {
            "type": "env_message",
            "data": {"k": "v"},
            "message_id": "mid-123",
            "topic": "t",
            "target_env": "envA",
            "source_env": "envB",
            "timestamp": 1730000000.0,
        }
        msg = WebSocketMessage.from_dict(payload)
        self.assertEqual(msg.to_dict()["type"], "env_message")
        self.assertEqual(msg.to_dict()["data"], {"k": "v"})
        self.assertEqual(msg.to_dict()["message_id"], "mid-123")
        self.assertEqual(msg.to_dict()["topic"], "t")
        self.assertEqual(msg.to_dict()["target_env"], "envA")
        self.assertEqual(msg.to_dict()["source_env"], "envB")
        self.assertEqual(msg.to_dict()["timestamp"], 1730000000.0)

    def test_register_unregister_handler(self):
        client = WebSocketClient(env_id="test")

        async def handler(_):
            return None

        client.register_handler("status_response", handler)
        self.assertIn("status_response", client.message_handlers)
        self.assertEqual(len(client.message_handlers["status_response"]), 1)

        client.unregister_handler("status_response", handler)
        self.assertIn("status_response", client.message_handlers)
        self.assertEqual(len(client.message_handlers["status_response"]), 0)


if __name__ == "__main__":
    unittest.main()