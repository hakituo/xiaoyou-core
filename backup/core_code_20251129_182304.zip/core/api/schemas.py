"""
API数据模型定义
使用Pydantic v2定义请求和响应的数据结构
"""
from pydantic import BaseModel, Field, field_validator
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
import os


class MessageRequest(BaseModel):
    """
    消息请求模型
    """
    message: str = Field(..., min_length=1, max_length=4096, description="用户消息内容")
    user_id: str = Field(..., min_length=1, max_length=100, description="用户ID")
    conversation_id: Optional[str] = Field(None, max_length=100, description="对话ID")
    model: Optional[str] = Field(None, max_length=100, description="使用的模型名称")
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0, description="生成温度")
    max_tokens: Optional[int] = Field(None, ge=1, le=8192, description="最大生成长度")
    history: Optional[List[Dict[str, str]]] = Field(None, description="历史对话记录")
    
    @field_validator('message')
    @classmethod
    def validate_message_not_empty(cls, v):
        if not v.strip():
            raise ValueError('消息内容不能为空')
        return v


class FileUploadRequest(BaseModel):
    """
    文件上传请求模型
    """
    # 注意：文件上传通常通过multipart/form-data处理
    # 此模型用于元数据验证，文件本身通过Flask的request.files获取
    purpose: Optional[str] = Field(None, max_length=50, description="文件用途")
    user_id: Optional[str] = Field(None, max_length=100, description="用户ID")
    
    @field_validator('purpose')
    @classmethod
    def validate_purpose(cls, v):
        if v and v not in ['image', 'audio', 'document']:
            raise ValueError('无效的文件用途')
        return v


class STTRequest(BaseModel):
    """
    语音转文本请求模型
    """
    # 音频文件通过multipart/form-data处理
    language: Optional[str] = Field("auto", max_length=10, description="语言代码")
    model: Optional[str] = Field(None, max_length=100, description="STT模型")
    
    @field_validator('language')
    @classmethod
    def validate_language(cls, v):
        # 支持的语言列表
        supported_languages = ['auto', 'zh', 'en', 'ja', 'ko', 'fr', 'de', 'es', 'ru', 'ar']
        if v not in supported_languages:
            raise ValueError(f'不支持的语言: {v}')
        return v


class TTSRequest(BaseModel):
    """
    文本转语音请求模型
    """
    text: str = Field(..., min_length=1, max_length=5000, description="待转换的文本")
    voice: Optional[str] = Field(None, max_length=50, description="语音名称")
    speed: Optional[float] = Field(1.0, ge=0.5, le=2.0, description="语速")
    language: Optional[str] = Field("zh-CN", max_length=10, description="语言代码")
    format: Optional[str] = Field("mp3", max_length=10, description="音频格式")
    
    @field_validator('text')
    @classmethod
    def validate_text_not_empty(cls, v):
        if not v.strip():
            raise ValueError('文本内容不能为空')
        return v
    
    @field_validator('format')
    @classmethod
    def validate_format(cls, v):
        supported_formats = ['mp3', 'wav', 'ogg', 'aac']
        if v not in supported_formats:
            raise ValueError(f'不支持的音频格式: {v}')
        return v


class WebSocketMessage(BaseModel):
    """
    WebSocket消息模型
    """
    type: str = Field(..., max_length=50, description="消息类型")
    data: Dict[str, Any] = Field(..., description="消息数据")
    timestamp: Optional[float] = Field(None, description="时间戳")
    
    @field_validator('type')
    @classmethod
    def validate_message_type(cls, v):
        valid_types = ['chat', 'ping', 'pong', 'system', 'error', 'typing']
        if v not in valid_types:
            raise ValueError(f'无效的消息类型: {v}')
        return v


class HealthCheckResponse(BaseModel):
    """
    健康检查响应模型
    """
    status: str = Field(..., description="服务状态")
    service: str = Field(..., description="服务名称")
    timestamp: float = Field(..., description="时间戳")
    version: Optional[str] = Field(None, description="服务版本")


class ErrorResponse(BaseModel):
    """
    错误响应模型
    """
    error: str = Field(..., description="错误消息")
    code: str = Field(..., description="错误代码")
    details: Optional[Dict[str, Any]] = Field(None, description="错误详情")
    request_id: Optional[str] = Field(None, description="请求ID")


class SuccessResponse(BaseModel):
    """
    成功响应模型
    """
    success: bool = Field(True, description="操作是否成功")
    message: str = Field(..., description="响应消息")
    data: Optional[Dict[str, Any]] = Field(None, description="响应数据")


class TokenRequest(BaseModel):
    """
    Token请求模型（用于WebSocket等需要令牌的接口）
    """
    token: str = Field(..., min_length=1, description="认证令牌")


class FileResponse(BaseModel):
    """
    文件上传响应模型
    """
    filename: str = Field(..., description="文件名")
    file_path: str = Field(..., description="文件路径")
    file_type: str = Field(..., description="文件类型")
    file_size: float = Field(..., description="文件大小(MB)")
    upload_time: datetime = Field(..., description="上传时间")


class ModelInfo(BaseModel):
    """
    模型信息模型
    """
    name: str = Field(..., description="模型名称")
    type: str = Field(..., description="模型类型")
    description: Optional[str] = Field(None, description="模型描述")
    version: Optional[str] = Field(None, description="模型版本")
    available: bool = Field(True, description="模型是否可用")


class ConfigUpdateRequest(BaseModel):
    """
    配置更新请求模型
    """
    # 注意：实际使用时应该根据具体配置项进行细粒度验证
    config_key: str = Field(..., max_length=100, description="配置键")
    config_value: Union[str, int, float, bool, None] = Field(..., description="配置值")
    
    @field_validator('config_key')
    @classmethod
    def validate_config_key(cls, v):
        # 防止访问敏感配置
        sensitive_keys = ['password', 'secret', 'key', 'token', 'credential']
        for sensitive_key in sensitive_keys:
            if sensitive_key in v.lower():
                raise ValueError('禁止修改敏感配置项')
        return v