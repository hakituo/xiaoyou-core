import os
import time
import threading
import asyncio
import traceback
from typing import List, Dict, Any, Optional, Callable, Tuple
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, AutoModel
import logging
import gc
import psutil

# 全局变量
_model_manager = None
_model_lock = threading.RLock()

# 配置日志
logger = logging.getLogger(__name__)

# 尝试导入推理服务客户端
try:
    from .llm.infer_service_client import get_infer_client
    INFER_SERVICE_AVAILABLE = True
except ImportError:
    INFER_SERVICE_AVAILABLE = False

# 导入配置管理
from config import get_settings

# 导入模型管理器
from core.model_manager import ModelManager, get_model_manager

# 全局变量
_model_manager = None
_model_lock = threading.RLock()


def load_model(model_path: Optional[str] = None, device: Optional[str] = None, model_id: str = "default") -> Tuple[Any, Any]:
    """
    加载模型和分词器

    Args:
        model_path: 模型路径
        device: 设备
        model_id: 模型标识符

    Returns:
        Tuple[Any, Any]: (model, tokenizer)
    """
    global _model_manager
    
    # 获取设置
    settings = get_settings()
    
    # 先获取量化设置，确保在整个函数中可用
    quantization = "none"
    try:
        # 优先从环境变量获取量化设置
        if os.environ.get("USE_4BIT_QUANTIZATION", "False").lower() == "true" or \
           os.environ.get("MODEL_LOAD_IN_4BIT", "False").lower() == "true":
            quantization = "4bit"
            logger.info("通过环境变量启用4bit量化")
        else:
            # 尝试从model_adapter.text_model读取量化配置（config.json结构）
            if hasattr(settings, "model_adapter") and hasattr(settings.model_adapter, "text_model") and hasattr(settings.model_adapter.text_model, "quantization"):
                quant_config = settings.model_adapter.text_model.quantization
                if quant_config and isinstance(quant_config, dict):
                    if quant_config.get("enabled", False) and quant_config.get("load_in_4bit", False):
                        quantization = "4bit"
                        logger.info("通过model_adapter.text_model配置启用4bit量化")
            # 尝试获取settings.model.quantization
            elif hasattr(settings, "model") and hasattr(settings.model, "quantization"):
                quantization = settings.model.quantization or "none"
            # 尝试获取settings.llm.quantization
            elif hasattr(settings, "llm") and hasattr(settings.llm, "quantization"):
                quantization = settings.llm.quantization or "none"
    except Exception:
        quantization = "none"
    
    with _model_lock:
        # 初始化模型管理器
        if _model_manager is None:
            _model_manager = get_model_manager()
        
        # 获取模型路径
    if model_path is None:
        try:
            # 尝试从model_adapter.text_model读取配置（config.json结构）
            if hasattr(settings, "model_adapter") and hasattr(settings.model_adapter, "text_model") and hasattr(settings.model_adapter.text_model, "text_model_path"):
                model_path = settings.model_adapter.text_model.text_model_path
        except Exception:
            model_path = ""
    
    if not model_path:
        try:
            # 尝试获取settings.model.path
            if hasattr(settings, "model") and hasattr(settings.model, "path"):
                model_path = settings.model.path
        except Exception:
            model_path = ""
    
    if not model_path:
        try:
            # 尝试获取settings.llm.model_path
            if hasattr(settings, "llm") and hasattr(settings.llm, "model_path"):
                model_path = settings.llm.model_path
        except Exception:
            model_path = ""
        
        if not model_path:
            # 在实际环境中应该使用配置的模型路径，但为了演示目的，这里提供一个友好的提示
            logger.info("未配置模型路径，请在配置中设置 'model.path' 或 'llm.model_path'")
            logger.info("由于这是演示模式，我们将返回一个模拟的模型对象")
            
            # 返回模拟的模型对象以便继续演示
            class MockModel:
                def __init__(self, q_type="none"):
                    # 添加量化属性以反映配置状态
                    self.quantized = q_type == "4bit"
                    self.quantization_type = q_type
                    
                def to(self, device):
                    return self
                
                def eval(self):
                    return self
                
                def parameters(self):
                    # 创建一个模拟的参数对象
                    class MockParameter:
                        def __init__(self):
                            self.device = 'cpu'  # 模拟设备类型
                    
                    # 返回一个包含模拟参数的生成器
                    yield MockParameter()
            
            class MockTokenizer:
                def decode(self, tokens, skip_special_tokens=True, clean_up_tokenization_spaces=True):
                    return "这是一个模拟响应，因为没有配置实际的模型路径。"
                
                def __call__(self, *args, **kwargs):
                    return {"input_ids": [[0, 1, 2]]}
            
            # 模拟模型加载成功
            end_time = time.time()
            # 获取当前函数的开始时间，如果不存在则使用当前时间
            if 'start_time' in locals():
                logger.info(f"模拟模型加载完成，耗时: {end_time - start_time:.2f}秒")
            else:
                logger.info("模拟模型加载完成")
            
            return MockModel(quantization), MockTokenizer()
        
        # 获取设备
    if device is None:
        try:
            # 尝试获取settings.model.device
            if hasattr(settings, "model") and hasattr(settings.model, "device"):
                device = settings.model.device
            else:
                device = "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # 注册并加载模型
        model_info = _model_manager.register_model(
            model_id=model_id,
            model_path=model_path,
            device=device,
            quantization=quantization
        )
        
        # 加载模型
        model_info = _model_manager.load_model(model_id)
        
        return model_info.model, model_info.tokenizer


def _unload_model(model_id: str = "default"):
    """
    内部函数：卸载模型和分词器，释放内存
    """
    global _model_manager
    
    if _model_manager is not None:
        logger.info(f"卸载模型: {model_id}")
        _model_manager.unload_model(model_id)
        logger.info(f"模型 {model_id} 卸载完成")


def generate_response(
    history: List[Dict[str, str]],
    max_new_tokens: int = 512,
    temperature: float = 0.7,
    top_p: float = 0.9,
    repetition_penalty: float = 1.0,
    use_retry: bool = True,
    timeout: int = 60,
    force_local: bool = False,
    fallback_to_smaller_params: bool = True
) -> str:
    """
    根据对话历史生成响应，支持失败重试、降级策略和全面的异常处理

    Args:
        history: 对话历史列表，格式为 [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]
        max_new_tokens: 最大生成长度
        temperature: 生成温度
        top_p: 核采样参数
        repetition_penalty: 重复惩罚参数
        use_retry: 是否启用重试机制
        timeout: 超时时间
        force_local: 是否强制使用本地模型，忽略配置
        fallback_to_smaller_params: 在资源不足时是否自动尝试使用更小的参数

    Returns:
        str: 生成的响应文本
        
    Raises:
        RuntimeError: 当所有重试和降级策略都失败时抛出
    """
    # 检查是否使用推理服务
    settings = get_settings()
    use_infer_service = not force_local and INFER_SERVICE_AVAILABLE and getattr(settings, "infer_service", None) and getattr(settings.infer_service, "enabled", False)
    
    if use_infer_service:
        logger.info("使用推理服务生成响应")
        try:
            return _generate_with_infer_service(
                history, max_new_tokens, temperature, top_p, repetition_penalty, use_retry, timeout
            )
        except Exception as e:
            logger.error(f"推理服务生成失败: {str(e)}")
            # 如果推理服务失败且允许重试，回退到本地模型
            if use_retry:
                logger.info("回退到本地模型生成")
            else:
                raise RuntimeError(f"推理服务调用失败: {str(e)}")
    
    # 使用本地模型
    if use_retry:
        try:
            return _generate_with_retry(
                history, max_new_tokens, temperature, top_p, repetition_penalty, timeout
            )
        except MemoryError as e:
            # 如果发生内存错误且允许降级到更小参数
            if fallback_to_smaller_params:
                logger.warning(f"内存不足，尝试使用更小的参数: {str(e)}")
                # 降低生成长度并重试
                reduced_max_tokens = max(50, max_new_tokens // 2)
                logger.info(f"降低生成长度从 {max_new_tokens} 到 {reduced_max_tokens}")
                return _generate_with_retry(
                    history, reduced_max_tokens, temperature, top_p, repetition_penalty, timeout
                )
            else:
                raise
        except TimeoutError as e:
            # 如果发生超时错误且允许降级到更小参数
            if fallback_to_smaller_params:
                logger.warning(f"生成超时，尝试使用更小的参数: {str(e)}")
                # 降低生成长度并重试
                reduced_max_tokens = max(50, max_new_tokens // 2)
                logger.info(f"降低生成长度从 {max_new_tokens} 到 {reduced_max_tokens}")
                return _generate_with_retry(
                    history, reduced_max_tokens, temperature, top_p, repetition_penalty, timeout // 2
                )
            else:
                raise
    else:
        try:
            return _generate_response_inner(
                history, max_new_tokens, temperature, top_p, repetition_penalty
            )
        except MemoryError as e:
            # 如果发生内存错误且允许降级到更小参数
            if fallback_to_smaller_params:
                logger.warning(f"内存不足，尝试使用更小的参数: {str(e)}")
                # 降低生成长度并重试
                reduced_max_tokens = max(50, max_new_tokens // 2)
                logger.info(f"降低生成长度从 {max_new_tokens} 到 {reduced_max_tokens}")
                return _generate_response_inner(
                    history, reduced_max_tokens, temperature, top_p, repetition_penalty
                )
            else:
                raise


def _generate_with_infer_service(
    history: List[Dict[str, str]],
    max_new_tokens: int = 512,
    temperature: float = 0.7,
    top_p: float = 0.9,
    repetition_penalty: float = 1.0,
    use_retry: bool = True,
    timeout: int = 60
) -> str:
    """
    使用推理服务生成响应
    
    Args:
        history: 对话历史
        max_new_tokens: 最大生成长度
        temperature: 生成温度
        top_p: 核采样参数
        repetition_penalty: 重复惩罚参数
        use_retry: 是否启用重试机制
        timeout: 超时时间
    
    Returns:
        str: 生成的响应文本
    """
    retry_count = 0
    MAX_RETRIES = 3 if use_retry else 0
    
    while retry_count <= MAX_RETRIES:
        try:
            # 指数退避重试
            if retry_count > 0:
                wait_time = min(2 ** (retry_count - 1), 8)  # 最大等待8秒
                logger.warning(f"推理服务第 {retry_count} 次重试，等待 {wait_time} 秒...")
                time.sleep(wait_time)
            
            # 获取推理客户端
            client = get_infer_client()
            
            # 执行生成请求
            result = asyncio.run(client.generate(
                history=history,
                max_tokens=max_new_tokens,
                temperature=temperature,
                top_p=top_p,
                repetition_penalty=repetition_penalty,
                timeout=timeout
            ))
            
            # 验证结果
            if not result or "text" not in result:
                raise ValueError(f"无效的推理结果: {result}")
            
            return result["text"]
            
        except Exception as e:
            logger.error(f"推理服务请求失败 (尝试 {retry_count+1}/{MAX_RETRIES+1}): {str(e)}")
            if retry_count >= MAX_RETRIES:
                raise
            
        retry_count += 1


def _generate_with_retry(
    history: List[Dict[str, str]],
    max_new_tokens: int = 512,
    temperature: float = 0.7,
    top_p: float = 0.9,
    repetition_penalty: float = 1.0,
    timeout: int = 60
) -> str:
    """
    带智能重试机制的响应生成，针对不同错误类型采取不同策略
    
    Args:
        history: 对话历史
        max_new_tokens: 最大生成长度
        temperature: 生成温度
        top_p: 核采样参数
        repetition_penalty: 重复惩罚参数
        timeout: 超时时间
    
    Returns:
        str: 生成的响应文本
        
    Raises:
        RuntimeError: 当所有重试都失败时抛出
        MemoryError: 内存不足且无法通过重试解决时抛出
    """
    retry_count = 0
    current_timeout = timeout if timeout > 0 else 60  # 初始超时时间
    last_exception = None
    
    # 根据错误类型动态调整的参数
    current_max_tokens = max_new_tokens
    current_temperature = temperature
    
    # 设置合理的最大重试次数
    MAX_RETRIES = 3
    while retry_count <= MAX_RETRIES:
        try:
            # 指数退避重试，但对不同错误类型采用不同策略
            if retry_count > 0:
                # 根据最后一次异常类型调整等待时间和策略
                if isinstance(last_exception, (MemoryError, torch.cuda.OutOfMemoryError)):
                    # 内存错误需要更长的等待和更激进的资源清理
                    wait_time = min(3 ** retry_count, 15)  # 最大等待15秒
                    logger.warning(f"第 {retry_count} 次重试（内存错误恢复），等待 {wait_time} 秒...")
                    # 主动清理资源
                    torch.cuda.empty_cache() if torch.cuda.is_available() else None
                    gc.collect()
                    time.sleep(wait_time)
                    
                    # 降低生成长度
                    current_max_tokens = max(50, int(current_max_tokens * 0.7))
                    logger.info(f"降低生成长度: {current_max_tokens}")
                    
                    # 降低温度以减少随机性和计算量
                    current_temperature = max(0.3, current_temperature - 0.1)
                    logger.info(f"降低温度: {current_temperature}")
                    
                elif isinstance(last_exception, TimeoutError):
                    # 超时错误需要调整超时设置
                    wait_time = min(2 ** retry_count, 10)  # 最大等待10秒
                    logger.warning(f"第 {retry_count} 次重试（超时恢复），等待 {wait_time} 秒...")
                    time.sleep(wait_time)
                    
                    # 减少生成长度
                    current_max_tokens = max(50, int(current_max_tokens * 0.8))
                    logger.info(f"降低生成长度: {current_max_tokens}")
                    
                    # 减少超时时间
                    current_timeout = min(300, current_timeout * 1.2)
                    logger.info(f"调整超时时间: {current_timeout}秒")
                    
                else:
                    # 其他错误使用标准退避
                    wait_time = min(2 ** (retry_count - 1), 8)  # 最大等待8秒
                    logger.warning(f"第 {retry_count} 次重试，等待 {wait_time} 秒...")
                    time.sleep(wait_time)
                    
                    # 增加超时时间，但不超过最大值
                    current_timeout = min(300, current_timeout * 1.5)  # 最大5分钟
                    logger.info(f"增加超时时间: {current_timeout}秒")
            
            # 记录当前尝试的参数
            logger.info(f"尝试生成 - 第{retry_count+1}次 - 参数: max_tokens={current_max_tokens}, "
                       f"temp={current_temperature}, timeout={current_timeout}")
            
            # 执行生成
            response = _generate_response_inner(
                history, 
                current_max_tokens, 
                current_temperature, 
                top_p, 
                repetition_penalty
            )
            
            # 如果成功生成，记录重试信息并返回响应
            if retry_count > 0:
                logger.info(f"经过 {retry_count} 次重试后成功生成响应")
            
            return response
                
        except MemoryError as e:
            # 内存错误特殊处理
            last_exception = e
            logger.error(f"内存不足错误 (尝试 {retry_count+1}/{MAX_RETRIES+1}): {str(e)}")
            
            # 强制清理资源
            torch.cuda.empty_cache() if torch.cuda.is_available() else None
            gc.collect()
            
            # 如果已经是最后一次重试，抛出异常
            if retry_count >= MAX_RETRIES:
                logger.critical("所有重试都因内存不足而失败")
                raise MemoryError(f"无法生成响应：{str(e)}。建议：1. 减少输入长度 2. 增加系统内存 3. 启用量化加载")
                
        except TimeoutError as e:
            # 超时错误特殊处理
            last_exception = e
            logger.error(f"生成超时错误 (尝试 {retry_count+1}/{MAX_RETRIES+1}): {str(e)}")
            
            # 如果已经是最后一次重试，抛出异常
            if retry_count >= MAX_RETRIES:
                logger.critical("所有重试都因超时而失败")
                raise TimeoutError(f"生成响应超时：{str(e)}。建议：减少生成长度或降低复杂度")
                
        except torch.cuda.OutOfMemoryError as e:
            # CUDA OOM错误特殊处理
            last_exception = MemoryError(f"CUDA内存不足: {str(e)}")
            logger.error(f"CUDA内存不足错误 (尝试 {retry_count+1}/{MAX_RETRIES+1}): {str(e)}")
            
            # 强制清理CUDA缓存
            torch.cuda.empty_cache()
            gc.collect()
            
        except Exception as e:
            # 其他类型异常
            last_exception = e
            logger.error(f"生成失败 (尝试 {retry_count+1}/{MAX_RETRIES+1}): {str(e)}")
            
            # 检查是否为致命错误（不需要重试）
            if isinstance(e, (ValueError, TypeError)) and retry_count > 0:
                # 输入错误，重试也没用
                logger.warning(f"检测到输入错误，不再重试")
                raise RuntimeError(f"生成失败：{str(e)}")
        
        retry_count += 1
    
    # 所有重试都失败
    error_msg = f"所有重试都失败: {str(last_exception) if last_exception else '未知错误'}"
    logger.error(error_msg)
    
    # 根据最后一次异常类型抛出相应的异常
    if isinstance(last_exception, MemoryError):
        raise last_exception
    elif isinstance(last_exception, TimeoutError):
        raise last_exception
    else:
        raise RuntimeError(f"文本生成失败：{str(last_exception) if last_exception else '未知错误'}")


def _generate_response_inner(
    history: List[Dict[str, str]],
    max_new_tokens: int = 200,
    temperature: float = 0.7,
    top_p: float = 0.95,
    repetition_penalty: float = 1.05,
    model_id: str = "default"
) -> str:
    """
    内部响应生成实现，带全面的异常处理和资源保护
    
    Args:
        history: 对话历史
        max_new_tokens: 最大生成长度
        temperature: 生成温度
        top_p: 核采样参数
        repetition_penalty: 重复惩罚参数
        model_id: 模型标识符
        
    Returns:
        str: 生成的响应文本
    
    Raises:
        RuntimeError: 生成失败时抛出，包含详细的错误信息和可能的解决方案
        MemoryError: 内存不足时抛出，包含清理建议
        TimeoutError: 生成超时时抛出
    """
    global _model_manager
    start_time = time.time()
    
    # 记录开始前的系统资源状态
    try:
        process = psutil.Process()
        mem_before = process.memory_info().rss / (1024 * 1024)
        if torch.cuda.is_available():
            gpu_mem_before = torch.cuda.memory_allocated() / (1024 * 1024)
            logger.info(f"开始生成前 - 内存使用: {mem_before:.2f}MB, GPU内存: {gpu_mem_before:.2f}MB")
        else:
            logger.info(f"开始生成前 - 内存使用: {mem_before:.2f}MB")
    except Exception as e:
        logger.warning(f"无法获取系统资源信息: {str(e)}")

    # 验证输入参数
    if not isinstance(history, list):
        logger.error("历史参数必须是列表类型")
        raise ValueError("历史参数必须是列表类型")

    if not history:
        logger.error("历史记录为空")
        raise ValueError("历史记录不能为空")

    # 确保模型管理器已初始化
    if _model_manager is None:
        _model_manager = get_model_manager()

    # 获取或加载模型
    model_info = None
    model = None
    tokenizer = None
    inputs = None
    outputs = None
    
    try:
        model_info = _model_manager.get_model(model_id)
        if model_info is None or model_info.status != "loaded":
            logger.info(f"模型 {model_id} 未加载，开始加载")
            
            # 在加载前检查资源
            if torch.cuda.is_available():
                gpu_mem_total = torch.cuda.get_device_properties(0).total_memory / (1024 * 1024)
                gpu_mem_available = gpu_mem_total - torch.cuda.memory_allocated() / (1024 * 1024)
                logger.info(f"GPU内存状态 - 已用: {torch.cuda.memory_allocated() / (1024 * 1024):.2f}MB, "
                          f"可用: {gpu_mem_available:.2f}MB, 总计: {gpu_mem_total:.2f}MB")
                
                # 如果GPU内存不足，尝试清理缓存
                if gpu_mem_available < 1000:  # 少于1GB可用
                    logger.warning("GPU内存不足，尝试清理缓存")
                    torch.cuda.empty_cache()
                    gc.collect()
                    gpu_mem_available = gpu_mem_total - torch.cuda.memory_allocated() / (1024 * 1024)
                    logger.info(f"清理后可用GPU内存: {gpu_mem_available:.2f}MB")
                    
                    # 如果仍然不足，尝试卸载其他模型
                    if gpu_mem_available < 1000:
                        logger.warning("GPU内存仍然不足，尝试卸载未使用的模型")
                        _model_manager.unload_unused_models()
                        torch.cuda.empty_cache()
                        gc.collect()
            
            model_info = _model_manager.load_model(model_id)
    except torch.cuda.OutOfMemoryError:
        # 处理CUDA OOM错误
        logger.error("CUDA内存不足错误", exc_info=True)
        torch.cuda.empty_cache()
        gc.collect()
        raise MemoryError("GPU内存不足。建议：1. 减少max_new_tokens参数 2. 启用量化加载 3. 卸载其他未使用的模型")
    except Exception as e:
        logger.error(f"模型加载错误: {e}", exc_info=True)
        raise RuntimeError(f"模型加载失败: {str(e)}")

    try:
        # 获取模型和分词器
        model = model_info.model
        tokenizer = model_info.tokenizer

        # 构建输入文本（优化版本）
        input_text = _build_prompt(history)

        # 编码输入
        try:
            inputs = tokenizer(
                input_text, return_tensors="pt", truncation=True, max_length=4096
            ).to(model.device)
        except Exception as e:
            logger.error(f"输入编码失败: {str(e)}", exc_info=True)
            raise RuntimeError(f"输入处理失败: {str(e)}")

        # 使用传入的参数，移除不合理的限制
        adjusted_max_new_tokens = max_new_tokens
        adjusted_temperature = temperature
        adjusted_top_p = top_p
        
        logger.info(f"使用参数: max_tokens={adjusted_max_new_tokens}, temp={adjusted_temperature}")
        
        # 生成配置（优化的生成参数）
        common_kwargs = {
            "max_new_tokens": adjusted_max_new_tokens,
            "temperature": adjusted_temperature,
            "top_p": adjusted_top_p,
            "repetition_penalty": max(1.0, min(repetition_penalty, 2.0)),  # 重复惩罚
            "do_sample": True,
            "pad_token_id": tokenizer.eos_token_id,
            "eos_token_id": tokenizer.eos_token_id,
            "use_cache": True,  # 使用KV缓存提升性能
            "num_return_sequences": 1,
        }

        # 针对不同设备的额外优化
        if torch.cuda.is_available():
            # GPU优化
            pass
        else:
            # CPU优化
            common_kwargs["num_beams"] = 1  # CPU上禁用束搜索以提升性能
            # CPU模式下适当放宽限制，但仍需注意内存
            # 将硬限制从200提升到2048，避免回复被截断
            common_kwargs["max_new_tokens"] = min(common_kwargs["max_new_tokens"], 2048)

        # 生成响应，添加超时控制
        def generate_in_thread():
            with torch.no_grad():  # 禁用梯度计算，节省内存
                return model.generate(**inputs, **common_kwargs)

        # 使用线程和超时控制
        import threading

        result_container = [None]
        exception_container = [None]

        def target():
            try:
                result_container[0] = generate_in_thread()
            except torch.cuda.OutOfMemoryError as e:
                # 特定处理CUDA OOM错误
                logger.error("CUDA内存不足错误", exc_info=True)
                exception_container[0] = MemoryError("GPU内存不足。建议：1. 减少max_new_tokens参数 2. 启用量化加载 3. 卸载其他未使用的模型")
            except Exception as e:
                logger.error(f"线程内生成响应失败: {e}", exc_info=True)
                exception_container[0] = e

        generate_thread = threading.Thread(target=target)
        generate_thread.daemon = True
        generate_thread.start()
        
        # 设置合理的超时时间，根据生成长度动态调整
        timeout = min(60 + (common_kwargs["max_new_tokens"] * 0.1), 300)  # 基础60秒 + 每token0.1秒，最多5分钟
        logger.info(f"设置生成超时时间: {timeout}秒")
        
        generate_thread.join(timeout=timeout)

        if generate_thread.is_alive():
            logger.error("模型生成响应超时")
            # 尝试终止线程并清理资源
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            gc.collect()
            raise TimeoutError(f"生成响应超时（超过{timeout}秒）。建议：减少生成长度或降低复杂度")

        if exception_container[0]:
            # 捕获并记录详细的异常信息
            exc_info = exception_container[0]
            logger.error(f"线程内生成响应失败: {str(exc_info)}")
            # 清理资源
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            gc.collect()
            raise exc_info

        outputs = result_container[0]
        if outputs is None:
            raise RuntimeError("模型未返回任何输出")

        # 解码输出（只解码新增的部分）
        try:
            response = tokenizer.decode(
                outputs[0][inputs.input_ids.shape[1] :],
                skip_special_tokens=True,
                clean_up_tokenization_spaces=True,
            )
        except Exception as e:
            logger.error(f"输出解码失败: {str(e)}", exc_info=True)
            raise RuntimeError(f"输出处理失败: {str(e)}")

        # 清理响应
        response = response.strip()
        
        # 验证响应
        if not response or len(response) < 2:
            logger.warning(f"生成的响应过短或为空: '{response}'")
            # 不抛出异常，让调用方处理短响应

        end_time = time.time()
        logger.info(f"生成响应耗时: {end_time - start_time:.2f}秒, 响应长度: {len(response)}字符")
        
        # 记录结束后的系统资源状态
        try:
            mem_after = process.memory_info().rss / (1024 * 1024)
            if torch.cuda.is_available():
                gpu_mem_after = torch.cuda.memory_allocated() / (1024 * 1024)
                logger.info(f"生成后 - 内存使用: {mem_after:.2f}MB (增加: {mem_after-mem_before:.2f}MB), "
                          f"GPU内存: {gpu_mem_after:.2f}MB (增加: {gpu_mem_after-gpu_mem_before:.2f}MB)")
            else:
                logger.info(f"生成后 - 内存使用: {mem_after:.2f}MB (增加: {mem_after-mem_before:.2f}MB)")
        except Exception as e:
            logger.warning(f"无法获取系统资源信息: {str(e)}")

        return response
    except torch.cuda.OutOfMemoryError:
        # 处理CUDA OOM错误
        logger.error("CUDA内存不足错误", exc_info=True)
        torch.cuda.empty_cache()
        gc.collect()
        raise MemoryError("GPU内存不足。建议：1. 减少max_new_tokens参数 2. 启用量化加载 3. 卸载其他未使用的模型")
    except Exception as e:
        logger.error(f"生成响应时出错: {e}", exc_info=True)
        # 清理资源
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()
        
        # 根据异常类型提供具体的错误信息和建议
        if isinstance(e, TimeoutError):
            raise
        elif isinstance(e, MemoryError):
            raise
        else:
            raise RuntimeError(f"文本生成失败: {str(e)}. 详细错误信息请查看日志")
    finally:
        # 确保清理资源
        try:
            # 清空中间变量，帮助垃圾回收
            if 'inputs' in locals():
                del inputs
            if 'outputs' in locals():
                del outputs
            # 不要删除model和tokenizer，它们由model_manager管理
            
            # 尝试清理CUDA缓存和Python垃圾回收
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            gc.collect()
        except Exception as e:
            logger.warning(f"资源清理时出错: {str(e)}")


def _build_prompt(history: List[Dict[str, str]]) -> str:
    """
    根据对话历史构建提示词，带完善的错误处理和输入验证

    Args:
        history: 对话历史

    Returns:
        str: 构建好的提示词
        
    Raises:
        ValueError: 当输入格式严重错误且无法恢复时抛出
    """
    # 检查history是否为有效的列表
    if not isinstance(history, list):
        error_msg = f"history必须是列表类型，收到的类型是: {type(history).__name__}"
        logger.error(error_msg)
        
        # 尝试基本转换为字符串
        try:
            history_str = str(history)
            # 限制转换后的字符串长度
            if len(history_str) > 1000:
                history_str = history_str[:1000] + "... (截断过长的输入)"
            
            logger.warning("尝试将非列表输入转换为用户消息")
            history = [{"role": "user", "content": history_str}]
        except Exception as e:
            logger.critical(f"无法处理的输入类型: {str(e)}")
            raise ValueError(f"构建提示词失败: {error_msg}")
    
    # 检查历史记录是否为空
    if not history:
        logger.warning("对话历史为空，返回默认提示")
        return "<|im_start|>assistant"
    
    # 构建提示词
    prompt = []
    valid_roles = {"user", "assistant", "system"}
    max_message_length = 5000  # 单个消息的最大长度限制
    max_total_length = 20000  # 总提示词的最大长度限制
    
    try:
        for msg in history:
            # 检查消息类型
            if not isinstance(msg, dict):
                logger.warning(f"跳过无效的消息格式: {type(msg).__name__}")
                continue
            
            # 获取角色和内容
            role = msg.get("role")
            content = msg.get("content", "").strip()
            
            # 验证角色
            if role not in valid_roles:
                logger.warning(f"未知的角色类型: {role}")
                continue
                
            # 跳过空内容
            if not content:
                continue
            
            # 验证内容类型
            if not isinstance(content, str):
                try:
                    content = str(content)
                    logger.warning(f"将非字符串内容转换为字符串: {role}")
                except Exception as e:
                    logger.error(f"无法转换内容为字符串: {str(e)}")
                    content = "[无法显示的内容]"
            
            # 限制单个消息长度
            if len(content) > max_message_length:
                logger.warning(f"消息内容过长，截断到{max_message_length}字符")
                content = content[:max_message_length] + "... (截断)"
            
            # 限制总提示词长度
            potential_addition = f"<|im_start|>{role}\n{content}<|im_end|>"
            
            # 计算当前总长度和潜在添加后的总长度
            current_total = len("\n".join(prompt))
            estimated_total = current_total + len(potential_addition)
            
            if estimated_total > max_total_length:
                logger.warning("提示词已达到最大长度，停止添加更多消息")
                break
            
            # 处理user角色的特殊前缀
            if role == "user":
                # 移除可能的前缀
                content = content.replace("User says: ", "", 1)
                prompt.append(f"<|im_start|>user\n{content}<|im_end|>")
            elif role == "system":
                prompt.append(f"<|im_start|>system\n{content}<|im_end|>")
            elif role == "assistant":
                prompt.append(f"<|im_start|>assistant\n{content}<|im_end|>")
    
    except Exception as e:
        logger.error(f"构建提示词时发生错误: {str(e)}")
        # 尝试返回安全的最小提示词
        try:
            return "<|im_start|>assistant"
        except Exception:
            # 最后防线，确保总是返回一个字符串
            return ""
    
    # 添加当前生成的开始标记
    prompt.append("<|im_start|>assistant")
    
    return "\n".join(prompt)
def get_model_info(model_id: str = "default") -> Dict[str, Any]:
    """
    获取当前模型信息

    Args:
        model_id: 模型标识符

    Returns:
        dict: 模型信息
    """
    # 检查是否使用推理服务
    settings = get_settings()
    use_infer_service = False
    try:
        if INFER_SERVICE_AVAILABLE and hasattr(settings, "infer_service") and hasattr(settings.infer_service, "enabled"):
            use_infer_service = bool(settings.infer_service.enabled)
    except Exception:
        use_infer_service = False
    
    if use_infer_service:
        # 返回推理服务信息
        try:
            # 获取推理服务状态
            health_status = check_infer_service_health()
            return {
                "infer_service": True,
                "status": health_status.get("status", "unknown"),
                "service_info": health_status
            }
        except Exception as e:
            logger.error(f"获取推理服务状态失败: {str(e)}")
            return {
                "infer_service": True,
                "status": "error",
                "error": str(e)
            }
    
    # 返回本地模型信息
    global _model_manager

    with _model_lock:
        if _model_manager is None:
            return {
                "infer_service": False,
                "loaded": False,
                "error": "模型管理器未初始化"
            }
        
        model_info = _model_manager.get_model(model_id)
        if model_info is None:
            return {
                "infer_service": False,
                "loaded": False,
                "error": f"模型 {model_id} 未注册"
            }
        
        info = {
            "infer_service": False,
            "loaded": model_info.status == "loaded",
            "model_id": model_id,
            "model_path": model_info.model_path,
            "device": model_info.device,
            "quantization": model_info.quantization,
            "status": model_info.status
        }

        if model_info.model:
            info["model_type"] = type(model_info.model).__name__
            info["num_parameters"] = sum(p.numel() for p in model_info.model.parameters())
            info["quantized"] = model_info.quantization != "none"

        return info


def check_infer_service_health(timeout: int = 5) -> Dict[str, Any]:
    """
    检查推理服务健康状态，带超时控制和多级异常处理
    
    Args:
        timeout: 超时时间，单位秒
    
    Returns:
        Dict[str, Any]: 健康状态信息
    """
    # 验证输入参数
    if timeout <= 0:
        timeout = 5
        logger.warning(f"超时参数无效，使用默认值: {timeout}秒")
    
    if not INFER_SERVICE_AVAILABLE:
        return {
            "status": "unavailable",
            "message": "推理服务客户端未安装"
        }
    
    try:
        client = get_infer_client()
        
        # 添加超时控制的异步健康检查
        async def health_check_with_timeout():
            try:
                return await asyncio.wait_for(client.health_check(), timeout=timeout)
            except asyncio.TimeoutError:
                logger.warning(f"推理服务健康检查超时: {timeout}秒")
                raise
        
        health_result = asyncio.run(health_check_with_timeout())
        
        # 验证健康检查结果
        if not health_result:
            logger.warning("健康检查返回空结果")
            return {
                "status": "unhealthy",
                "error": "空的健康检查结果"
            }
            
        return {
            "status": "healthy" if health_result else "unhealthy",
            "service_status": health_result.get("status", "unknown") if health_result else "unknown",
            "model_status": health_result.get("model_status", "unknown") if health_result else "unknown",
            "check_time": time.time(),
            "timeout_used": timeout
        }
    except asyncio.TimeoutError as e:
        logger.error(f"推理服务健康检查超时: {str(e)}")
        return {
            "status": "timeout",
            "error": f"服务响应超时，超过{timeout}秒",
            "timeout_used": timeout
        }
    except ConnectionError as e:
        logger.error(f"连接到推理服务失败: {str(e)}")
        return {
            "status": "connection_error",
            "error": f"连接错误: {str(e)}"
        }
    except Exception as e:
        logger.error(f"检查推理服务健康状态失败: {str(e)}")
        return {
            "status": "unhealthy",
            "error": str(e)
        }
    finally:
        # 清理可能的资源
        pass


# 示例使用
def example_inference():
    """
    示例推理函数，用于测试模型加载和生成
    """
    # 检查推理服务状态
    settings = get_settings()
    use_infer_service = False
    try:
        if INFER_SERVICE_AVAILABLE and hasattr(settings, "infer_service") and hasattr(settings.infer_service, "enabled"):
            use_infer_service = bool(settings.infer_service.enabled)
    except Exception:
        use_infer_service = False
    
    if use_infer_service:
        print("\n==== 推理服务模式 ====")
        health_status = check_infer_service_health()
        print(f"推理服务健康状态: {health_status}")
    else:
        print("\n==== 本地模型模式 ====")
        # 加载模型
        print("加载模型...")
        model, tokenizer = load_model()
        print(f"模型已加载，设备: {next(model.parameters()).device}")
    
    # 检查是否是模拟模型并显示量化状态
    if hasattr(model, 'quantized'):
        print(f"模拟模型量化状态: {'已启用' if model.quantized else '未启用'}")
        print(f"量化类型: {model.quantization_type}")

    # 测试输入
    history = [{"role": "user", "content": "你好，请介绍一下你自己。"}]

    # 生成响应
    print("\n生成响应...")
    start_time = time.time()
    
    # 检查是否为模拟模型，对于模拟模型直接使用tokenizer生成响应
    if 'model' in locals() and model.__class__.__name__ == 'MockModel':
        # 这是我们的模拟模型，直接使用tokenizer生成响应
        response = "这是一个模拟响应，因为没有配置实际的模型路径。"
    else:
        # 正常使用生成函数
        try:
            response = generate_response(history, max_new_tokens=200)
        except Exception as e:
            response = f"生成失败: {str(e)}"
    
    end_time = time.time()
    print(f"Response: {response}")
    print(f"生成耗时: {end_time - start_time:.2f}秒")

    # 测试强制使用本地模型
    if use_infer_service:
        print("\n==== 强制使用本地模型 ====")
        start_time = time.time()
        
        # 强制使用本地模型时也检查是否为模拟模型
        if 'model' not in locals():
            model, tokenizer = load_model()
        
        if model.__class__.__name__ == 'MockModel':
            response = "这是一个模拟响应，因为没有配置实际的模型路径。"
        else:
            try:
                response = generate_response(history, max_new_tokens=200, force_local=True)
            except Exception as e:
                response = f"生成失败: {str(e)}"
            
        end_time = time.time()
        print(f"Response: {response}")
        print(f"生成耗时: {end_time - start_time:.2f}秒")

    # 获取模型信息
    print("\n==== 模型信息 ====")
    model_info = get_model_info()
    print(f"模型信息: {model_info}")
    
    # 检查是否有模拟模型的量化信息
    if model_info.get('loaded') and 'model' in locals() and hasattr(model, 'quantized'):
        print(f"模型量化状态: {'已启用' if model.quantized else '未启用'}")
        print(f"量化类型: {model.quantization_type}")


if __name__ == "__main__":
    example_inference()