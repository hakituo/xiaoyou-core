#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CPU密集型任务处理器
提供线程池隔离机制，避免CPU密集型任务阻塞事件循环
"""
import asyncio
import concurrent.futures
import time
import logging
from typing import Any, Callable, Dict, Optional, TypeVar, cast
from functools import wraps
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)

T = TypeVar('T')


class CPUTaskProcessor:
    """
    CPU密集型任务处理器
    使用独立线程池隔离CPU密集型任务
    """
    
    def __init__(self, 
                 pool_size: int = 4, 
                 max_queue_size: int = 1000, 
                 task_timeout: int = 300):
        """
        初始化CPU任务处理器
        
        Args:
            pool_size: 线程池大小
            max_queue_size: 最大队列大小
            task_timeout: 任务超时时间(秒)
        """
        self.pool_size = pool_size
        self.max_queue_size = max_queue_size
        self.task_timeout = task_timeout
        self._executor: Optional[concurrent.futures.ThreadPoolExecutor] = None
        self._queue: Optional[asyncio.Queue] = None
        self._is_running = False
        self._stats: Dict[str, Any] = {
            "total_tasks": 0,
            "completed_tasks": 0,
            "failed_tasks": 0,
            "average_execution_time": 0,
            "active_tasks": 0
        }
        self._task_semaphore: Optional[asyncio.Semaphore] = None
        
    async def initialize(self):
        """
        初始化处理器
        """
        if self._is_running:
            return
        
        logger.info(f"初始化CPU任务处理器: pool_size={self.pool_size}")
        self._executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=self.pool_size,
            thread_name_prefix="CPU-Task-"
        )
        self._queue = asyncio.Queue(maxsize=self.max_queue_size)
        self._task_semaphore = asyncio.Semaphore(self.max_queue_size)
        self._is_running = True
        
        # 启动工作协程
        self._worker_task = asyncio.create_task(self._worker_loop())
        logger.info("CPU任务处理器初始化完成")
    
    async def shutdown(self):
        """
        关闭处理器
        """
        if not self._is_running:
            return
        
        logger.info("正在关闭CPU任务处理器...")
        self._is_running = False
        
        # 取消工作协程
        if hasattr(self, '_worker_task') and not self._worker_task.done():
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        
        # 关闭线程池
        if self._executor:
            self._executor.shutdown(wait=True)
            self._executor = None
        
        logger.info("CPU任务处理器已关闭")
    
    async def _worker_loop(self):
        """
        工作协程循环，处理队列中的任务
        """
        while self._is_running:
            try:
                task_info = await self._queue.get()
                
                # 解包任务信息
                task_func = task_info['func']
                task_args = task_info['args']
                task_kwargs = task_info['kwargs']
                future = task_info['future']
                task_id = task_info['task_id']
                start_time = task_info['start_time']
                
                try:
                    # 使用线程池执行CPU密集型任务
                    result = await asyncio.get_event_loop().run_in_executor(
                        self._executor, 
                        lambda: task_func(*task_args, **task_kwargs)
                    )
                    
                    # 更新统计信息
                    execution_time = time.time() - start_time
                    self._update_stats(True, execution_time)
                    
                    # 设置future结果
                    future.set_result(result)
                    logger.debug(f"CPU任务 {task_id} 完成，耗时: {execution_time:.2f}s")
                    
                except Exception as e:
                    # 更新统计信息
                    execution_time = time.time() - start_time
                    self._update_stats(False, execution_time)
                    
                    # 设置future异常
                    future.set_exception(e)
                    logger.error(f"CPU任务 {task_id} 失败: {str(e)}", exc_info=True)
                    
                finally:
                    self._queue.task_done()
                    if self._task_semaphore:
                        self._task_semaphore.release()
                    self._stats["active_tasks"] -= 1
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"CPU任务工作协程错误: {str(e)}", exc_info=True)
    
    def _update_stats(self, success: bool, execution_time: float):
        """
        更新统计信息
        """
        self._stats["total_tasks"] += 1
        if success:
            self._stats["completed_tasks"] += 1
        else:
            self._stats["failed_tasks"] += 1
        
        # 更新平均执行时间
        current_avg = self._stats["average_execution_time"]
        count = self._stats["total_tasks"]
        self._stats["average_execution_time"] = (
            (current_avg * (count - 1)) + execution_time
        ) / count
    
    async def submit_task(self, 
                          func: Callable[..., T], 
                          *args, 
                          **kwargs) -> T:
        """
        提交CPU密集型任务
        
        Args:
            func: 要执行的函数
            *args: 函数参数
            **kwargs: 函数关键字参数
            
        Returns:
            函数执行结果
        """
        if not self._is_running:
            raise RuntimeError("CPU任务处理器未启动")
        
        # 等待信号量，限制队列大小
        if self._task_semaphore:
            await self._task_semaphore.acquire()
        
        # 创建future
        future = asyncio.Future()
        task_id = f"task_{int(time.time() * 1000)}_{id(future)}"
        start_time = time.time()
        
        # 提交任务到队列
        task_info = {
            'func': func,
            'args': args,
            'kwargs': kwargs,
            'future': future,
            'task_id': task_id,
            'start_time': start_time
        }
        
        try:
            # 尝试立即放入队列，超时则拒绝
            await asyncio.wait_for(
                self._queue.put(task_info), 
                timeout=1.0
            )
            self._stats["active_tasks"] += 1
            
            # 等待任务完成，设置超时
            result = await asyncio.wait_for(
                future, 
                timeout=self.task_timeout
            )
            return result
            
        except asyncio.TimeoutError:
            if self._task_semaphore:
                self._task_semaphore.release()
            raise TimeoutError(f"CPU任务 {task_id} 超时 ({self.task_timeout}秒)")
        except Exception:
            if self._task_semaphore:
                self._task_semaphore.release()
            raise
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取处理器统计信息
        """
        return dict(self._stats)
    
    def is_healthy(self) -> bool:
        """
        检查处理器健康状态
        """
        return self._is_running and self._executor is not None


# 全局CPU任务处理器实例
_cpu_processor: Optional[CPUTaskProcessor] = None


def get_cpu_processor() -> CPUTaskProcessor:
    """
    获取全局CPU任务处理器实例
    """
    global _cpu_processor
    if _cpu_processor is None:
        from core.config_manager import ConfigManager
        config = ConfigManager().get_all_config()
        task_config = config.get("task_scheduler", {})
        _cpu_processor = CPUTaskProcessor(
            pool_size=task_config.get("cpu_thread_pool_size", 4),
            max_queue_size=task_config.get("queue_size", 1000),
            task_timeout=task_config.get("task_timeout", 300)
        )
    return _cpu_processor


async def initialize_cpu_processor():
    """
    初始化全局CPU任务处理器
    """
    processor = get_cpu_processor()
    await processor.initialize()


async def shutdown_cpu_processor():
    """
    关闭全局CPU任务处理器
    """
    global _cpu_processor
    if _cpu_processor:
        await _cpu_processor.shutdown()
        _cpu_processor = None


# 任务装饰器
def cpu_task(func: Callable[..., T]) -> Callable[..., asyncio.Future[T]]:
    """
    CPU密集型任务装饰器
    将同步函数包装为异步函数，并在线程池中执行
    
    Args:
        func: 要装饰的同步函数
        
    Returns:
        异步包装函数
    """
    @wraps(func)
    async def wrapper(*args, **kwargs) -> T:
        processor = get_cpu_processor()
        return await processor.submit_task(func, *args, **kwargs)
    
    # 标记为CPU任务
    wrapper.__is_cpu_task__ = True
    return wrapper


@asynccontextmanager
async def cpu_task_context():
    """
    CPU任务上下文管理器
    用于临时初始化和关闭CPU任务处理器
    """
    try:
        await initialize_cpu_processor()
        yield get_cpu_processor()
    finally:
        await shutdown_cpu_processor()