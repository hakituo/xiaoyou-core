#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
API加密传输模块

此模块提供API请求和响应的加密传输功能，确保数据在传输过程中的安全性。
支持AES-256加密算法，提供请求加密、响应解密以及密钥管理功能。
"""

import os
import json
import base64
import hashlib
from typing import Dict, Any, Optional, Union
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from core.utils.logger import get_logger
from core.config_manager import get_config

logger = get_logger("ENCRYPTION")

class EncryptionService:
    """加密服务类，处理API请求和响应的加密解密"""
    
    def __init__(self):
        """初始化加密服务"""
        # 获取加密配置
        self._enabled = get_config("security.encryption.enabled", False)
        self._secret_key = get_config("security.encryption.secret_key", "")
        self._algorithm = get_config("security.encryption.algorithm", "AES-256-CBC")
        
        # 初始化加密密钥
        self._key = None
        if self._enabled and self._secret_key:
            self._initialize_key()
            logger.info("API加密传输功能已启用")
        else:
            if not self._secret_key and self._enabled:
                logger.warning("加密已启用但未配置密钥，加密功能将被禁用")
                self._enabled = False
            else:
                logger.info("API加密传输功能已禁用")
    
    def _initialize_key(self) -> None:
        """根据配置的密钥生成加密密钥"""
        # 使用SHA-256对用户提供的密钥进行哈希，生成固定长度的256位密钥
        key_bytes = self._secret_key.encode('utf-8')
        self._key = hashlib.sha256(key_bytes).digest()
    
    def is_enabled(self) -> bool:
        """检查加密功能是否启用
        
        Returns:
            bool: 加密功能是否启用
        """
        return self._enabled and self._key is not None
    
    def update_config(self, enabled: Optional[bool] = None, secret_key: Optional[str] = None) -> None:
        """更新加密配置
        
        Args:
            enabled: 是否启用加密
            secret_key: 加密密钥
        """
        if enabled is not None:
            self._enabled = enabled
        
        if secret_key is not None:
            self._secret_key = secret_key
            if self._enabled:
                self._initialize_key()
        
        logger.info(f"加密配置已更新 - 启用状态: {self._enabled}")
    
    def encrypt(self, data: Dict[str, Any]) -> str:
        """加密数据
        
        Args:
            data: 要加密的数据字典
            
        Returns:
            str: 加密后的base64字符串
        """
        if not self.is_enabled():
            # 如果加密未启用，返回原始数据的JSON字符串
            return json.dumps(data)
        
        try:
            # 序列化数据
            plaintext = json.dumps(data, ensure_ascii=False).encode('utf-8')
            
            # 生成随机IV (初始化向量)
            iv = os.urandom(16)  # AES-256-CBC需要16字节IV
            
            # 创建填充器
            padder = padding.PKCS7(128).padder()  # 128位=16字节块大小
            padded_data = padder.update(plaintext) + padder.finalize()
            
            # 创建加密器
            cipher = Cipher(algorithms.AES(self._key), modes.CBC(iv), backend=default_backend())
            encryptor = cipher.encryptor()
            
            # 加密数据
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            
            # 将IV和密文组合并base64编码
            combined = iv + ciphertext
            encrypted_data = base64.b64encode(combined).decode('utf-8')
            
            logger.debug(f"数据加密成功，原始大小: {len(plaintext)} 字节")
            return encrypted_data
            
        except Exception as e:
            logger.error(f"数据加密失败: {e}")
            raise RuntimeError(f"加密失败: {str(e)}")
    
    def decrypt(self, encrypted_data: str) -> Dict[str, Any]:
        """解密数据
        
        Args:
            encrypted_data: 加密的base64字符串
            
        Returns:
            Dict[str, Any]: 解密后的数据字典
        """
        # 如果加密未启用，尝试将输入作为JSON解析
        if not self.is_enabled():
            try:
                return json.loads(encrypted_data)
            except json.JSONDecodeError:
                # 如果不是有效的JSON，返回空字典
                return {}
        
        try:
            # Base64解码
            combined = base64.b64decode(encrypted_data)
            
            # 提取IV (前16字节)
            iv = combined[:16]
            ciphertext = combined[16:]
            
            # 创建解密器
            cipher = Cipher(algorithms.AES(self._key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()
            
            # 解密数据
            padded_data = decryptor.update(ciphertext) + decryptor.finalize()
            
            # 移除填充
            unpadder = padding.PKCS7(128).unpadder()
            plaintext = unpadder.update(padded_data) + unpadder.finalize()
            
            # 反序列化JSON
            data = json.loads(plaintext.decode('utf-8'))
            
            logger.debug(f"数据解密成功，解密后大小: {len(plaintext)} 字节")
            return data
            
        except Exception as e:
            logger.error(f"数据解密失败: {e}")
            raise RuntimeError(f"解密失败: {str(e)}")
    
    def generate_secure_key(self, length: int = 32) -> str:
        """生成安全的随机密钥
        
        Args:
            length: 密钥长度（字符数）
            
        Returns:
            str: 生成的随机密钥
        """
        import secrets
        import string
        
        # 使用secrets模块生成加密安全的随机字符串
        alphabet = string.ascii_letters + string.digits + string.punctuation
        secure_key = ''.join(secrets.choice(alphabet) for _ in range(length))
        
        return secure_key

# 创建全局加密服务实例
_encryption_service = None


def get_encryption_service() -> EncryptionService:
    """获取全局加密服务实例
    
    Returns:
        EncryptionService: 加密服务实例
    """
    global _encryption_service
    
    if _encryption_service is None:
        _encryption_service = EncryptionService()
    
    return _encryption_service


def encrypt_request(data: Dict[str, Any]) -> str:
    """便捷函数：加密请求数据
    
    Args:
        data: 要加密的数据
        
    Returns:
        str: 加密后的数据
    """
    return get_encryption_service().encrypt(data)


def decrypt_request(encrypted_data: str) -> Dict[str, Any]:
    """便捷函数：解密请求数据
    
    Args:
        encrypted_data: 加密的数据
        
    Returns:
        Dict[str, Any]: 解密后的数据
    """
    return get_encryption_service().decrypt(encrypted_data)


def is_encryption_enabled() -> bool:
    """检查加密是否启用
    
    Returns:
        bool: 加密是否启用
    """
    return get_encryption_service().is_enabled()


def update_encryption_config(**kwargs) -> None:
    """更新加密配置
    
    Args:
        **kwargs: 要更新的配置项
    """
    service = get_encryption_service()
    service.update_config(**kwargs)


def generate_key(length: int = 32) -> str:
    """生成安全密钥
    
    Args:
        length: 密钥长度
        
    Returns:
        str: 生成的密钥
    """
    return get_encryption_service().generate_secure_key(length)