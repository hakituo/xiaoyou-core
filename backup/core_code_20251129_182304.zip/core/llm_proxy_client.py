import os
import json
import asyncio
from typing import Dict, Optional, Any, List
import websockets
from core.utils.logger import get_logger
from core.env.env_communication_manager import get_communication_manager
logger = get_logger("LLM_PROXY_CLIENT")
class LLMProxyClient:
    """LLM代理客户端，用于与LLM服务进行通信"""
    def __init__(self):
        self._websocket = None
        self._connected = False
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = 5
        self._reconnect_delay = 2  # 秒
        self._communication_manager = get_communication_manager()
        # 从环境变量或配置中获取服务器地址
        self._server_url = os.environ.get(
            "LLM_SERVER_URL", 
            "ws://localhost:8765/llm"
        )
        # 心跳任务
        self._heartbeat_task = None
        self._shutdown_event = asyncio.Event()
    async def connect(self) -> bool:
        """
        连接到LLM服务器
        Returns:
            连接是否成功
        """
        try:
            logger.info(f"尝试连接到LLM服务器: {self._server_url}")
            self._websocket = await websockets.connect(
                self._server_url,
                ping_interval=30,
                ping_timeout=60,
                max_size=10 * 1024 * 1024  # 10MB
            )
            self._connected = True
            self._reconnect_attempts = 0
            # 启动心跳任务
            self._start_heartbeat()
            logger.info("LLM服务器连接成功")
            return True
        except Exception as e:
            logger.error(f"LLM服务器连接失败: {e}")
            self._connected = False
            return False
    async def disconnect(self):
        """断开与LLM服务器的连接"""
        if self._heartbeat_task:
            self._shutdown_event.set()
            try:
                await self._heartbeat_task
            except Exception:
                pass
            self._heartbeat_task = None
            self._shutdown_event.clear()
        if self._websocket:
            try:
                await self._websocket.close()
            except Exception:
                pass
            self._websocket = None
        self._connected = False
        logger.info("LLM服务器连接已断开")
    def _start_heartbeat(self):
        """启动心跳任务"""
        if self._heartbeat_task is None:
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
    async def _heartbeat_loop(self):
        """心跳循环任务"""
        while not self._shutdown_event.is_set():
            try:
                if self._connected and self._websocket:
                    await self._websocket.send(json.dumps({"type": "ping"}))
                    response = await asyncio.wait_for(
                        self._websocket.recv(), 
                        timeout=5
                    )
                    response_data = json.loads(response)
                    if response_data.get("type") != "pong":
                        logger.warning("心跳响应类型错误")
            except asyncio.TimeoutError:
                logger.warning("LLM服务器心跳超时")
                await self._reconnect()
            except Exception as e:
                logger.warning(f"LLM服务器心跳失败: {e}")
                await self._reconnect()
            # 等待下一次心跳
            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(), 
                    timeout=30
                )
            except asyncio.TimeoutError:
                pass
    async def _reconnect(self):
        """重新连接到LLM服务器"""
        if self._reconnect_attempts >= self._max_reconnect_attempts:
            logger.error("达到最大重连次数，放弃重连")
            return
        self._reconnect_attempts += 1
        logger.info(
            f"正在尝试第 {self._reconnect_attempts} 次重连，" 
            f"延迟 {self._reconnect_delay} 秒"
        )
        await asyncio.sleep(self._reconnect_delay)
        await self.disconnect()
        await self.connect()
        # 指数退避策略
        self._reconnect_delay = min(self._reconnect_delay * 2, 60)
    async def _ensure_connected(self):
        """确保连接已建立"""
        if not self._connected or not self._websocket:
            if not await self.connect():
                raise ConnectionError("无法连接到LLM服务器")
    async def send_request(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        发送请求到LLM服务器
        Args:
            request_data: 请求数据
        Returns:
            响应数据
        """
        await self._ensure_connected()
        try:
            # 发送请求
            await self._websocket.send(json.dumps(request_data))
            # 接收响应
            response = await self._websocket.recv()
            response_data = json.loads(response)
            if response_data.get("error"):
                raise Exception(response_data["error"])
            return response_data
        except websockets.exceptions.ConnectionClosed:
            logger.error("连接已关闭")
            self._connected = False
            # 尝试重连并重试
            await self._reconnect()
            return await self.send_request(request_data)
        except Exception as e:
            logger.error(f"请求失败: {e}")
            raise
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> Dict[str, Any]:
        """
        调用聊天接口
        Args:
            messages: 消息列表
            **kwargs: 其他参数
        Returns:
            响应数据
        """
        request_data = {
            "type": "chat",
            "messages": messages,
            **kwargs
        }
        return await self.send_request(request_data)
    async def generate_text(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        生成文本
        Args:
            prompt: 提示文本
            **kwargs: 其他参数
        Returns:
            响应数据
        """
        request_data = {
            "type": "generate",
            "prompt": prompt,
            **kwargs
        }
        return await self.send_request(request_data)
    async def get_status(self) -> Dict[str, Any]:
        """
        获取服务器状态
        Returns:
            服务器状态信息
        """
        request_data = {"type": "status"}
        try:
            return await self.send_request(request_data)
        except Exception as e:
            logger.error(f"获取服务器状态失败: {e}")
            return {
                "status": "error",
                "error": str(e),
                "connected": self._connected
            }
    async def shutdown(self):
        """关闭客户端"""
        await self.disconnect()
        logger.info("LLM代理客户端已关闭")
# 全局LLM代理客户端实例
_llm_proxy_client_instance = None
def get_global_llm_proxy_client() -> LLMProxyClient:
    """获取全局LLM代理客户端实例"""
    global _llm_proxy_client_instance
    if _llm_proxy_client_instance is None:
        _llm_proxy_client_instance = LLMProxyClient()
    return _llm_proxy_client_instance
async def shutdown_global_llm_proxy_client():
    """关闭全局LLM代理客户端实例"""
    global _llm_proxy_client_instance
    if _llm_proxy_client_instance:
        await _llm_proxy_client_instance.shutdown()
        _llm_proxy_client_instance = None
# 便捷函数
async def llm_chat(messages: List[Dict[str, str]], **kwargs) -> Dict[str, Any]:
    """便捷的聊天函数"""
    client = get_global_llm_proxy_client()
    return await client.chat(messages, **kwargs)
async def llm_generate(prompt: str, **kwargs) -> Dict[str, Any]:
    """便捷的文本生成函数"""
    client = get_global_llm_proxy_client()
    return await client.generate_text(prompt, **kwargs)
async def llm_status() -> Dict[str, Any]:
    """获取LLM服务状态"""
    client = get_global_llm_proxy_client()
    return await client.get_status()