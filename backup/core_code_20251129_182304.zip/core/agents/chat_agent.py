import asyncio
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime
from core.llm import get_llm_module, LLMConfig, create_instance
from core.utils.logger import get_logger
from memory.memory_manager import MemoryManager
from core.character import get_Aveline_manager
logger = get_logger("ChatAgent")
@dataclass
class AgentConfig:
    """
    Agent配置类
    """
    agent_name: str = "default_chat_agent"
    system_prompt: str = "你是一个助手，请用中文回答用户问题。"
    max_history_length: int = 10
    temperature: float = 0.7
class ChatAgent:
    """
    聊天Agent类，负责处理用户消息并生成响应
    """
    def __init__(self, config: Optional[AgentConfig] = None):
        """
        初始化ChatAgent
        Args:
            config: Agent配置
        """
        self.config = config or AgentConfig()
        self.memory_manager = None
        self.llm_module = None
        self.is_initialized = False
        self._lock = asyncio.Lock()
    async def initialize(self):
        """
        初始化Agent，加载必要的组件
        """
        async with self._lock:
            if self.is_initialized:
                return
            logger.info(f"初始化ChatAgent: {self.config.agent_name}")
            # 初始化内存管理器
            self.memory_manager = MemoryManager()
            await self.memory_manager.initialize()
            # 初始化LLM模块
            self.llm_module = get_llm_module()
            await self.llm_module.initialize()
            # 从Aveline角色管理器获取角色配置，更新系统提示词
            try:
                character_manager = get_Aveline_manager()
                character_context = character_manager.get_context()
                if character_context:
                    self.config.system_prompt = character_context
                    logger.info("已使用Aveline角色配置更新系统提示词")
            except Exception as e:
                logger.warning(f"获取Aveline角色配置失败: {str(e)}")
            # 检查并创建默认LLM实例
            llm_status = self.llm_module.get_status()
            if llm_status.get("llm_status", {}).get("instances_count", 0) == 0:
                logger.info("未找到LLM实例，创建默认LLM实例...")
                config = LLMConfig(
                    model_name="default",
                    device="auto",
                    max_context_length=2048,
                    temperature=self.config.temperature
                )
                await create_instance("default_llm", config)
            self.is_initialized = True
            logger.info(f"ChatAgent初始化完成: {self.config.agent_name}")
    async def handle_message(self, user_id, message, message_id):
        """
        处理用户消息
        Args:
            user_id: 用户ID
            message: 用户消息
            message_id: 消息ID
        Returns:
            响应字典
        """
        if not self.is_initialized:
            await self.initialize()
        try:
            # 生成消息ID
            if not message_id:
                message_id = f"msg_{user_id}_{datetime.now().timestamp()}"
            logger.info(f"处理用户 {user_id} 的消息，ID: {message_id}")
            # 构建对话历史
            messages = await self._build_conversation_history(user_id, message)
            # 调用LLM生成响应
            response_content = await self.llm_module.chat(messages, temperature=self.config.temperature)
            # 保存对话到历史记录
            await self._save_conversation_history(user_id, message, response_content, message_id)
            logger.info(f"为用户 {user_id} 生成响应，消息ID: {message_id}")
            return {
                "success": True,
                "content": response_content,
                "message_id": message_id,
                "user_id": user_id,
                "timestamp": datetime.now().timestamp()
            }
        except Exception as e:
            logger.error(f"处理消息时出错: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "message_id": message_id,
                "user_id": user_id
            }
    async def _build_conversation_history(self, user_id: str, current_message: str) -> List[Dict[str, str]]:
        """
        构建对话历史
        Args:
            user_id: 用户ID
            current_message: 当前消息
        Returns:
            格式化的对话历史
        """
        # 添加系统提示
        messages = [
            {"role": "system", "content": self.config.system_prompt}
        ]
        # 从内存管理器获取历史记录
        try:
            history = await self.memory_manager.get_conversation_history(user_id, limit=self.config.max_history_length)
            # 添加历史对话
            for item in history:
                # 确保history中的每个item都是字典格式
                if isinstance(item, dict):
                    if item.get("role") in ["user", "assistant"]:
                        messages.append({
                            "role": item["role"],
                            "content": item.get("content", "")
                        })
        except Exception as e:
            logger.warning(f"获取对话历史失败: {str(e)}")
            # 继续执行，不影响当前消息处理
        # 添加当前消息
        messages.append({
            "role": "user",
            "content": current_message
        })
        return messages
    async def _save_conversation_history(self, user_id: str, user_message: str, assistant_response: str, message_id: str):
        """
        保存对话历史
        Args:
            user_id: 用户ID
            user_message: 用户消息
            assistant_response: 助手响应
            message_id: 消息ID
        """
        try:
            # 保存用户消息
            await self.memory_manager.add_message(
                user_id=user_id,
                role="user",
                content=user_message,
                message_id=message_id,
                timestamp=datetime.now().timestamp()
            )
            # 保存助手响应
            await self.memory_manager.add_message(
                user_id=user_id,
                role="assistant",
                content=assistant_response,
                message_id=f"{message_id}_response",
                timestamp=datetime.now().timestamp()
            )
        except Exception as e:
            logger.warning(f"保存对话历史失败: {str(e)}")
            # 继续执行，不影响当前消息处理
    async def clear_history(self, user_id):
        """
        清除用户对话历史
        Args:
            user_id: 用户ID
        """
        if not self.is_initialized:
            await self.initialize()
        try:
            await self.memory_manager.clear_conversation_history(user_id)
            logger.info(f"清除用户 {user_id} 的对话历史")
        except Exception as e:
            logger.error(f"清除对话历史失败: {str(e)}")
# 全局默认聊天Agent实例
def get_default_chat_agent() -> ChatAgent:
    """
    获取全局默认聊天Agent实例
    Returns:
        聊天Agent实例
    """
    if not hasattr(get_default_chat_agent, "_instance"):
        get_default_chat_agent._instance = ChatAgent()
    return get_default_chat_agent._instance