# Import local model adapter
from core.model_adapter import ModelAdapter
import logging
from PIL import Image
import os
# 配置日志
logger = logging.getLogger(__name__)