#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
LLM模型接口和实现模块
提供统一的大语言模型接口抽象
"""

import logging
from dataclasses import dataclass
from typing import Dict, Any, Optional, List, Callable, Protocol

logger = logging.getLogger(__name__)


@dataclass
class LLMConfig:
    """LLM模型配置数据类"""
    model_name: str
    temperature: float = 0.7
    max_tokens: int = 1024
    top_p: float = 0.9
    model_path: Optional[str] = None
    device: str = "cpu"
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "model_name": self.model_name,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "top_p": self.top_p,
            "model_path": self.model_path,
            "device": self.device
        }


class LLMInterface(Protocol):
    """LLM模型接口定义"""
    
    async def generate(self, prompt: str, config: Optional[LLMConfig] = None) -> str:
        """生成文本回复
        
        Args:
            prompt: 输入提示文本
            config: 可选的模型配置
            
        Returns:
            生成的文本响应
        """
        ...
    
    async def chat(self, messages: List[Dict[str, str]], config: Optional[LLMConfig] = None) -> str:
        """进行多轮对话
        
        Args:
            messages: 消息列表，每个消息包含role和content
            config: 可选的模型配置
            
        Returns:
            生成的文本响应
        """
        ...
    
    async def embed(self, texts: List[str]) -> List[List[float]]:
        """生成文本嵌入向量
        
        Args:
            texts: 文本列表
            
        Returns:
            嵌入向量列表
        """
        ...
    
    async def shutdown(self):
        """关闭模型，释放资源"""
        ...


class BaseLLM:
    """LLM模型基类"""
    
    def __init__(self, config: LLMConfig):
        """初始化模型
        
        Args:
            config: 模型配置
        """
        self.config = config
        logger.info(f"初始化模型: {config.model_name}")
    
    async def generate(self, prompt: str, config: Optional[LLMConfig] = None) -> str:
        """生成文本回复（基础实现）"""
        raise NotImplementedError("子类必须实现generate方法")
    
    async def chat(self, messages: List[Dict[str, str]], config: Optional[LLMConfig] = None) -> str:
        """进行多轮对话（基础实现）"""
        raise NotImplementedError("子类必须实现chat方法")
    
    async def embed(self, texts: List[str]) -> List[List[float]]:
        """生成文本嵌入向量（基础实现）"""
        raise NotImplementedError("子类必须实现embed方法")
    
    async def shutdown(self):
        """关闭模型，释放资源"""
        logger.info(f"关闭模型: {self.config.model_name}")


# 模型注册表和工厂函数
_model_registry: Dict[str, Callable[[LLMConfig], BaseLLM]] = {}
_model_instances: Dict[str, BaseLLM] = {}


def register_model(model_name: str, factory_func: Callable[[LLMConfig], BaseLLM]):
    """注册LLM模型
    
    Args:
        model_name: 模型名称
        factory_func: 模型工厂函数
    """
    global _model_registry
    _model_registry[model_name] = factory_func
    logger.info(f"模型已注册: {model_name}")


def get_model_instance(model_name: str, config: Optional[LLMConfig] = None) -> Optional[BaseLLM]:
    """获取模型实例（单例模式）
    
    Args:
        model_name: 模型名称
        config: 模型配置，如果为None则使用默认配置
        
    Returns:
        模型实例，如果找不到则返回None
    """
    global _model_instances
    
    # 检查实例是否已存在
    if model_name in _model_instances:
        return _model_instances[model_name]
    
    # 检查模型是否已注册
    if model_name not in _model_registry:
        logger.error(f"模型未注册: {model_name}")
        return None
    
    # 创建配置
    if config is None:
        config = LLMConfig(model_name=model_name)
    elif config.model_name != model_name:
        config.model_name = model_name
    
    # 创建并缓存实例
    try:
        model = _model_registry[model_name](config)
        _model_instances[model_name] = model
        logger.info(f"成功获取模型实例: {model_name}")
        return model
    except Exception as e:
        logger.error(f"创建模型实例失败: {e}")
        return None

def list_available_models() -> List[str]:
    """列出所有可用的模型
    
    Returns:
        模型名称列表
    """
    return list(_model_registry.keys())


# 注册一些基础模型作为示例
async def _create_dummy_model(config: LLMConfig) -> BaseLLM:
    """创建虚拟模型（用于开发和测试）"""
    class DummyLLM(BaseLLM):
        async def generate(self, prompt: str, config: Optional[LLMConfig] = None) -> str:
            return f"[Dummy Response] This is a response to: {prompt[:50]}..."
        
        async def chat(self, messages: List[Dict[str, str]], config: Optional[LLMConfig] = None) -> str:
            return f"[Dummy Chat] I received {len(messages)} messages."
        
        async def embed(self, texts: List[str]) -> List[List[float]]:
            # 返回简单的嵌入向量
            return [[0.1] * 10 for _ in texts]
    
    return DummyLLM(config)


# 注册默认的虚拟模型
register_model("dummy", lambda config: DummyLLM(config))


class DummyLLM(BaseLLM):
    """用于开发和测试的虚拟LLM模型"""
    
    async def generate(self, prompt: str, config: Optional[LLMConfig] = None) -> str:
        return f"[Dummy Response] This is a response to: {prompt[:50]}..."
    
    async def chat(self, messages: List[Dict[str, str]], config: Optional[LLMConfig] = None) -> str:
        return f"[Dummy Chat] I received {len(messages)} messages."
    
    async def embed(self, texts: List[str]) -> List[List[float]]:
        # 返回简单的嵌入向量
        return [[0.1] * 10 for _ in texts]