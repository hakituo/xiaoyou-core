import asyncio
import torch
import concurrent.futures
from typing import Any, Callable, Optional
from core.utils.logger import get_logger

logger = get_logger("AsyncScheduler")

# CPU线程池 - 使用配置中的CPU线程数
cpu_executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)


class AsyncScheduler:
    """
    异步调度器，管理CPU和GPU任务的并行执行
    核心功能：
    1. CPU任务在线程池中执行
    2. GPU任务在主线程中执行或使用专用线程
    3. 支持任务优先级和资源管理
    """

    def __init__(self):
        self._cpu_executor = cpu_executor
        self._main_loop: Optional[asyncio.AbstractEventLoop] = None
        self._gpu_lock = asyncio.Lock()
        self._is_running = True
        logger.info("异步调度器已初始化")

    @property
    def loop(self):
        """获取事件循环"""
        if self._main_loop is None:
            self._main_loop = asyncio.get_event_loop()
        return self._main_loop

    async def run_cpu(self, fn: Callable, *args, **kwargs) -> Any:
        """
        在CPU线程池中执行任务
        适合：STT预处理、文本处理、文件IO等
        """
        logger.debug(
            f"提交CPU任务: {fn.__name__ if hasattr(fn, '__name__') else str(fn)}"
        )
        return await self.loop.run_in_executor(
            self._cpu_executor, lambda: fn(*args, **kwargs)
        )

    async def run_gpu(self, fn: Callable, *args, **kwargs) -> Any:
        """
        在GPU上执行任务
        适合：TTS合成、LLM推理、图像处理等
        使用锁确保GPU任务顺序执行，避免显存竞争
        """
        logger.debug(
            f"提交GPU任务: {fn.__name__ if hasattr(fn, '__name__') else str(fn)}"
        )
        # 使用锁确保GPU任务顺序执行
        async with self._gpu_lock:
            try:
                # 保证在主线程调用torch.cuda操作
                # 这样计算会被正确地排到当前CUDA流中
                result = await self.loop.run_in_executor(
                    None, lambda: fn(*args, **kwargs)  # 使用默认执行器（主线程）
                )
                return result
            except Exception as e:
                logger.error(f"GPU任务执行失败: {e}")
                raise

    async def submit_task(self, fn: Callable, *args, priority=None, **kwargs) -> Any:
        """
        提交任务到调度器
        Args:
            fn: 要执行的函数
            *args: 函数参数
            priority: 任务优先级（保留用于将来扩展）
            **kwargs: 函数关键字参数
        Returns:
            任务执行结果
        """
        # 简单实现，直接执行任务
        # 在实际应用中，可以根据任务类型决定在CPU还是GPU上执行
        try:
            logger.debug(
                f"提交任务: {fn.__name__ if hasattr(fn, '__name__') else str(fn)}"
            )
            # 如果是异步函数，直接await
            if asyncio.iscoroutinefunction(fn):
                return await fn(*args, **kwargs)
            else:
                # 否则在线程池中执行
                return await self.loop.run_in_executor(
                    None, lambda: fn(*args, **kwargs)
                )
        except Exception as e:
            logger.error(f"任务执行失败: {e}")
            raise

    # 简化接口，不再需要优先级参数

    async def wait_for_all_tasks(self):
        """
        等待所有任务完成
        """
        # 获取所有正在运行的任务
        tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        logger.info("所有任务已完成")
        
    async def get_resource_stats(self) -> dict:
        """
        获取资源统计信息
        """
        stats = {
            "cpu": {
                "active_workers": sum(
                    1 for w in self._cpu_executor._threads if w.is_alive()
                ),
                "max_workers": self._cpu_executor._max_workers,
            }
        }

        # 添加GPU信息（如果可用）
        if torch.cuda.is_available():
            device = torch.device("cuda")
            stats["gpu"] = {
                "available": True,
                "device_count": torch.cuda.device_count(),
                "current_device": torch.cuda.current_device(),
                "memory_allocated": torch.cuda.memory_allocated(device) / 1024**3,  # GB
                "memory_reserved": torch.cuda.memory_reserved(device) / 1024**3,  # GB
            }
        else:
            stats["gpu"] = {"available": False}

        return stats


# 创建全局异步调度器实例
global_async_scheduler = AsyncScheduler()


def get_global_scheduler() -> AsyncScheduler:
    """
    获取全局异步调度器实例
    """
    return global_async_scheduler


def get_global_async_scheduler() -> AsyncScheduler:
    """
    获取全局异步调度器实例（向后兼容）
    """
    return global_async_scheduler


# 简单的并行任务执行示例
async def run_parallel_tasks(cpu_func, gpu_func):
    """
    并行执行CPU和GPU任务
    """
    cpu_task = get_global_async_scheduler().run_cpu(cpu_func)
    gpu_task = get_global_async_scheduler().run_gpu(gpu_func)
    return await asyncio.gather(cpu_task, gpu_task)


# 直接通过global_async_scheduler实例访问方法，不单独导出