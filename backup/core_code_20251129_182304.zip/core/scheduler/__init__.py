"""调度器模块 - 统一管理CPU和GPU资源"""

from typing import Dict, Any, Optional, Callable, Union

# 从异步调度器模块导入
from .async_scheduler import (
    AsyncScheduler,
    get_global_async_scheduler
)


# 定义任务优先级常量（兼容现有代码）
# 全局调度器实例 - 直接使用AsyncScheduler

# 定义TaskPriority类（兼容现有代码）
class TaskPriority:
    LOW = 0
    MEDIUM = 1
    HIGH = 2

# 提供get_global_scheduler作为get_global_async_scheduler的别名
def get_global_scheduler():
    """获取全局调度器实例"""
    from .async_scheduler import get_global_async_scheduler
    return get_global_async_scheduler()

# 导出主要组件
__all__ = [
    "AsyncScheduler",
    "get_global_scheduler",
    "get_global_async_scheduler",
    "TaskPriority"
]
