#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
内存管理主模块
提供内存监控、管理和垃圾回收功能
"""

import gc
import logging
import threading
import time
import psutil
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class MemoryMonitor:
    """内存监控器，用于监控系统和进程内存使用情况"""
    
    def __init__(self, interval: float = 5.0):
        """初始化内存监控器
        
        Args:
            interval: 监控间隔（秒）
        """
        self.interval = interval
        self.process = psutil.Process()
        self.running = False
        self.monitor_thread = None
        logger.info("内存监控器已初始化")
    
    def start(self):
        """启动内存监控"""
        if self.running:
            logger.warning("内存监控已在运行中")
            return
        
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        logger.info("内存监控已启动")
    
    def stop(self):
        """停止内存监控"""
        if not self.running:
            logger.warning("内存监控未在运行中")
            return
        
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=1.0)
        logger.info("内存监控已停止")
    
    def _monitor_loop(self):
        """监控循环，定期检查内存使用情况"""
        while self.running:
            try:
                memory_info = self.get_memory_info()
                logger.debug(f"内存使用情况: {memory_info}")
                # 可以在这里添加内存使用阈值检查和告警逻辑
            except Exception as e:
                logger.error(f"内存监控出错: {e}")
            time.sleep(self.interval)
    
    def get_memory_info(self) -> Dict[str, Any]:
        """获取当前内存使用信息
        
        Returns:
            包含内存使用信息的字典
        """
        process_memory = self.process.memory_info()
        system_memory = psutil.virtual_memory()
        
        return {
            "process_rss_mb": process_memory.rss / (1024 * 1024),  # 进程物理内存使用（MB）
            "process_vms_mb": process_memory.vms / (1024 * 1024),  # 进程虚拟内存使用（MB）
            "system_total_mb": system_memory.total / (1024 * 1024),  # 系统总内存（MB）
            "system_available_mb": system_memory.available / (1024 * 1024),  # 系统可用内存（MB）
            "system_used_percent": system_memory.percent,  # 系统内存使用百分比
        }
    
    def get_memory_usage(self) -> Dict[str, float]:
        """获取内存使用情况
        
        Returns:
            包含进程和系统内存使用情况的字典
        """
        memory_info = self.get_memory_info()
        return {
            "process_usage_mb": memory_info["process_rss_mb"],
            "system_usage_percent": memory_info["system_used_percent"]
        }


class MemoryManager:
    """内存管理器，负责管理和优化应用程序的内存使用"""
    
    def __init__(self):
        """初始化内存管理器"""
        self.monitor = MemoryMonitor()
        self.gc = GarbageCollector()
        self.resource_tracker = {}
        self.lock = threading.RLock()
        logger.info("内存管理器已初始化")
    
    def start(self):
        """启动内存管理服务"""
        self.monitor.start()
        self.gc.start()
        logger.info("内存管理服务已启动")
    
    def stop(self):
        """停止内存管理服务"""
        self.gc.stop()
        self.monitor.stop()
        logger.info("内存管理服务已停止")
    
    def track_resource(self, resource_id: str, resource: Any, size_estimate: Optional[int] = None):
        """跟踪资源使用情况
        
        Args:
            resource_id: 资源标识符
            resource: 要跟踪的资源对象
            size_estimate: 资源大小估计（字节）
        """
        with self.lock:
            self.resource_tracker[resource_id] = {
                "resource": resource,
                "size_estimate": size_estimate,
                "timestamp": time.time()
            }
            logger.debug(f"资源已跟踪: {resource_id}")
    
    def untrack_resource(self, resource_id: str):
        """取消跟踪资源
        
        Args:
            resource_id: 资源标识符
        """
        with self.lock:
            if resource_id in self.resource_tracker:
                del self.resource_tracker[resource_id]
                logger.debug(f"资源跟踪已取消: {resource_id}")
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """获取内存统计信息
        
        Returns:
            内存统计信息字典
        """
        with self.lock:
            return {
                "monitor_info": self.monitor.get_memory_info(),
                "tracked_resources": len(self.resource_tracker),
                "gc_stats": self.gc.get_stats()
            }
    
    def optimize_memory(self):
        """执行内存优化操作"""
        logger.info("执行内存优化")
        # 执行垃圾回收
        self.gc.collect()
        # 可以在这里添加其他内存优化逻辑


class GarbageCollector:
    """自定义垃圾回收器，增强Python的默认垃圾回收功能"""
    
    def __init__(self, auto_collect_interval: float = 60.0, threshold: float = 0.8):
        """初始化垃圾回收器
        
        Args:
            auto_collect_interval: 自动回收间隔（秒）
            threshold: 触发回收的内存使用阈值（0.0-1.0）
        """
        self.auto_collect_interval = auto_collect_interval
        self.threshold = threshold
        self.running = False
        self.gc_thread = None
        self.stats = {
            "collect_count": 0,
            "last_collect_time": 0,
            "objects_collected": 0
        }
        logger.info("垃圾回收器已初始化")
    
    def start(self):
        """启动自动垃圾回收"""
        if self.running:
            logger.warning("垃圾回收器已在运行中")
            return
        
        self.running = True
        self.gc_thread = threading.Thread(target=self._gc_loop, daemon=True)
        self.gc_thread.start()
        logger.info("自动垃圾回收已启动")
    
    def stop(self):
        """停止自动垃圾回收"""
        if not self.running:
            logger.warning("垃圾回收器未在运行中")
            return
        
        self.running = False
        if self.gc_thread:
            self.gc_thread.join(timeout=1.0)
        logger.info("自动垃圾回收已停止")
    
    def collect(self):
        """立即执行垃圾回收
        
        Returns:
            回收的对象数量
        """
        logger.info("执行垃圾回收")
        before_count = len(gc.get_objects())
        
        # 执行完整的垃圾回收
        count0 = gc.collect(0)
        count1 = gc.collect(1)
        count2 = gc.collect(2)
        
        after_count = len(gc.get_objects())
        objects_collected = before_count - after_count
        
        self.stats["collect_count"] += 1
        self.stats["last_collect_time"] = time.time()
        self.stats["objects_collected"] += objects_collected
        
        logger.info(f"垃圾回收完成: 第0代({count0}), 第1代({count1}), 第2代({count2}), 总计回收({objects_collected})对象")
        return objects_collected
    
    def _gc_loop(self):
        """垃圾回收循环"""
        while self.running:
            try:
                # 检查内存使用情况，超过阈值则执行回收
                memory_percent = psutil.virtual_memory().percent / 100
                if memory_percent > self.threshold:
                    logger.warning(f"内存使用超过阈值({memory_percent:.2%})，触发垃圾回收")
                    self.collect()
            except Exception as e:
                logger.error(f"垃圾回收循环出错: {e}")
            time.sleep(self.auto_collect_interval)
    
    def get_stats(self) -> Dict[str, Any]:
        """获取垃圾回收器统计信息
        
        Returns:
            统计信息字典
        """
        return dict(self.stats)


# 全局内存管理器实例
_memory_manager_instance: Optional[MemoryManager] = None


def initialize_memory_manager() -> MemoryManager:
    """初始化全局内存管理器
    
    Returns:
        内存管理器实例
    """
    global _memory_manager_instance
    
    if _memory_manager_instance is None:
        _memory_manager_instance = MemoryManager()
        _memory_manager_instance.start()
        logger.info("全局内存管理器已初始化")
    
    return _memory_manager_instance


def get_memory_manager() -> Optional[MemoryManager]:
    """获取全局内存管理器实例
    
    Returns:
        内存管理器实例，如果未初始化则返回None
    """
    global _memory_manager_instance
    
    if _memory_manager_instance is None:
        logger.warning("内存管理器未初始化")
        return initialize_memory_manager()
    
    return _memory_manager_instance