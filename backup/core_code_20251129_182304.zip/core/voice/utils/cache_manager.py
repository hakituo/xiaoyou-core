# -*- coding: utf-8 -*-
"""
缓存管理器，用于管理TTS引擎的缓存资源
"""

import os
import hashlib
import pickle
import logging
import threading
from typing import Dict, Any, Optional, Union

logger = logging.getLogger(__name__)


class LRUCache:
    """
    简单的LRU缓存实现
    """
    
    def __init__(self, capacity: int):
        """
        初始化LRU缓存
        
        Args:
            capacity: 缓存容量
        """
        self.capacity = capacity
        self.cache: Dict[str, tuple] = {}  # (value, size)
        self.order = []  # 用于跟踪访问顺序
        self.total_size = 0  # 当前缓存总大小（字节）
    
    def get(self, key: str) -> Optional[Any]:
        """
        获取缓存项
        
        Args:
            key: 缓存键
            
        Returns:
            缓存值或None
        """
        if key in self.cache:
            # 将访问的项移到列表末尾（最近使用）
            self.order.remove(key)
            self.order.append(key)
            return self.cache[key][0]
        return None
    
    def put(self, key: str, value: Any, size: int):
        """
        添加缓存项
        
        Args:
            key: 缓存键
            value: 缓存值
            size: 缓存项大小（字节）
        """
        # 如果键已存在，先移除旧项
        if key in self.cache:
            self.total_size -= self.cache[key][1]
            self.order.remove(key)
        
        # 检查是否需要淘汰旧项
        while self.total_size + size > self.capacity and self.order:
            old_key = self.order.pop(0)
            self.total_size -= self.cache[old_key][1]
            del self.cache[old_key]
        
        # 添加新项
        self.cache[key] = (value, size)
        self.order.append(key)
        self.total_size += size
    
    def clear(self):
        """
        清空缓存
        """
        self.cache.clear()
        self.order.clear()
        self.total_size = 0


class CacheManager:
    """
    TTS缓存管理器，管理合成结果和资源缓存
    """
    
    def __init__(self, cache_dir: str = None, max_memory_cache_size_mb: int = 100):
        """
        初始化缓存管理器
        
        Args:
            cache_dir: 磁盘缓存目录
            max_memory_cache_size_mb: 内存缓存最大大小（MB）
        """
        self.cache_dir = cache_dir
        self.max_memory_cache_size = max_memory_cache_size_mb * 1024 * 1024  # 转换为字节
        self.memory_cache = LRUCache(self.max_memory_cache_size)
        self._lock = threading.RLock()
        
        # 初始化磁盘缓存目录
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)
    
    def get_cache_key(self, text: str, **kwargs) -> str:
        """
        生成缓存键
        
        Args:
            text: 要缓存的文本
            **kwargs: 其他参数，用于生成键
            
        Returns:
            缓存键
        """
        # 将参数排序以确保生成一致的键
        sorted_kwargs = sorted(kwargs.items())
        data = f"{text}:{sorted_kwargs}"
        
        # 使用MD5生成缓存键
        return hashlib.md5(data.encode('utf-8')).hexdigest()
    
    def get(self, key: str) -> Optional[Any]:
        """
        从缓存获取数据
        
        Args:
            key: 缓存键
            
        Returns:
            缓存数据或None
        """
        with self._lock:
            # 首先从内存缓存获取
            value = self.memory_cache.get(key)
            if value is not None:
                logger.debug(f"从内存缓存获取: {key}")
                return value
            
            # 如果内存缓存没有，则从磁盘缓存获取
            if self.cache_dir:
                cache_file = os.path.join(self.cache_dir, f"{key}.cache")
                if os.path.exists(cache_file):
                    try:
                        with open(cache_file, 'rb') as f:
                            value = pickle.load(f)
                        
                        # 将从磁盘加载的数据放入内存缓存
                        value_size = len(pickle.dumps(value))
                        self.memory_cache.put(key, value, value_size)
                        
                        logger.debug(f"从磁盘缓存获取: {key}")
                        return value
                    except Exception as e:
                        logger.warning(f"加载磁盘缓存失败: {str(e)}")
            
            return None
    
    def put(self, key: str, value: Any, size: Optional[int] = None):
        """
        将数据放入缓存
        
        Args:
            key: 缓存键
            value: 要缓存的数据
            size: 数据大小（字节），如果为None则自动计算
        """
        with self._lock:
            # 计算大小
            if size is None:
                size = len(pickle.dumps(value))
            
            # 放入内存缓存
            self.memory_cache.put(key, value, size)
            logger.debug(f"放入内存缓存: {key}")
            
            # 如果设置了缓存目录，也放入磁盘缓存
            if self.cache_dir:
                cache_file = os.path.join(self.cache_dir, f"{key}.cache")
                try:
                    with open(cache_file, 'wb') as f:
                        pickle.dump(value, f)
                    logger.debug(f"放入磁盘缓存: {key}")
                except Exception as e:
                    logger.warning(f"保存到磁盘缓存失败: {str(e)}")
    
    def clear(self):
        """
        清空所有缓存
        """
        with self._lock:
            # 清空内存缓存
            self.memory_cache.clear()
            
            # 清空磁盘缓存
            if self.cache_dir:
                try:
                    for filename in os.listdir(self.cache_dir):
                        if filename.endswith('.cache'):
                            os.remove(os.path.join(self.cache_dir, filename))
                    logger.info(f"已清空磁盘缓存目录: {self.cache_dir}")
                except Exception as e:
                    logger.warning(f"清空磁盘缓存失败: {str(e)}")
            
            logger.info("缓存已清空")
    
    def remove(self, key: str):
        """
        移除特定缓存项
        
        Args:
            key: 要移除的缓存键
        """
        with self._lock:
            # 从内存缓存移除
            if key in self.memory_cache.cache:
                del self.memory_cache.cache[key]
                if key in self.memory_cache.order:
                    self.memory_cache.order.remove(key)
                logger.debug(f"从内存缓存移除: {key}")
            
            # 从磁盘缓存移除
            if self.cache_dir:
                cache_file = os.path.join(self.cache_dir, f"{key}.cache")
                if os.path.exists(cache_file):
                    try:
                        os.remove(cache_file)
                        logger.debug(f"从磁盘缓存移除: {key}")
                    except Exception as e:
                        logger.warning(f"从磁盘缓存移除失败: {str(e)}")