import os
import torch
import numpy as np
import logging
from typing import Dict, List, Optional, Union
from dataclasses import dataclass
import time
import gc
import json
import librosa

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("GPTSoVITS-SpeakerEncoder")

@dataclass
class SpeakerEncoderConfig:
    """说话人编码器配置类"""
    model_path: str = ""
    config_path: str = ""
    device: str = "auto"
    precision: str = "auto"  # auto, fp16, fp32
    sample_rate: int = 16000
    embedding_dim: int = 256
    speakers_dir: str = "./speakers"
    use_half: bool = True

@dataclass
class StyleParams:
    """风格参数类"""
    pitch: float = 1.0  # 音高调整因子
    speed: float = 1.0  # 语速调整因子
    emotion: str = "neutral"  # 情感类型
    energy: float = 1.0  # 能量调整因子
    tone: str = "normal"  # 语调类型

class SpeakerEncoder:
    """
    说话人编码器类
    负责从音频中提取说话人嵌入特征
    """
    
    def __init__(self, config: SpeakerEncoderConfig):
        """
        初始化说话人编码器
        
        Args:
            config: 编码器配置
        """
        self.config = config
        self.model = None
        self.device = self._setup_device()
        self.use_half = self._setup_precision()
        self.model_path = config.model_path
        self.speakers_dir = config.speakers_dir
        self.is_loaded = False
        self.load_time = 0
        
        # 创建说话人目录
        os.makedirs(self.speakers_dir, exist_ok=True)
        
        # 内置情感类型
        self.emotion_types = ["neutral", "happy", "sad", "angry", "surprised", "fearful"]
        
    def _setup_device(self) -> str:
        """
        设置运行设备，支持自动检测GPU/CPU
        
        Returns:
            设备名称 (cuda/cpu)
        """
        if self.config.device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
            logger.info(f"自动检测设备: {device}")
            return device
        return self.config.device
    
    def _setup_precision(self) -> bool:
        """
        设置精度模式
        
        Returns:
            是否使用半精度
        """
        if self.config.precision == "auto":
            # 在CPU上不使用半精度，GPU上默认使用半精度
            use_half = self.device == "cuda" and torch.cuda.is_available()
            logger.info(f"自动设置精度: {'半精度(fp16)' if use_half else '单精度(fp32)'}")
            return use_half
        elif self.config.precision == "fp16":
            if self.device == "cpu":
                logger.warning("CPU不支持半精度，将使用单精度")
                return False
            return True
        return False
    
    def load_model(self) -> bool:
        """
        加载说话人编码器模型
        
        Returns:
            是否加载成功
        """
        try:
            start_time = time.time()
            
            # 验证模型路径
            if not os.path.exists(self.model_path):
                logger.error(f"模型文件不存在: {self.model_path}")
                return False
            
            # 尝试加载模型（这里是示例，实际加载逻辑需要根据具体模型结构调整）
            logger.info(f"开始加载说话人编码器模型: {self.model_path}")
            
            # 这里模拟模型加载，实际项目中需要根据具体模型格式调整
            # 例如：
            # checkpoint = torch.load(self.model_path, map_location=self.device)
            # self.model = YourSpeakerEncoderModel()
            # self.model.load_state_dict(checkpoint['model'])
            
            # 模拟模型创建
            self.model = torch.nn.Sequential(
                torch.nn.Linear(80, 512),
                torch.nn.ReLU(),
                torch.nn.Linear(512, self.config.embedding_dim)
            )  # 占位模型
            
            # 移动到指定设备
            self.model.to(self.device)
            
            # 设置精度
            if self.use_half:
                self.model.half()
            
            # 设置为评估模式
            self.model.eval()
            
            self.load_time = time.time() - start_time
            self.is_loaded = True
            logger.info(f"说话人编码器模型加载完成，耗时: {self.load_time:.2f}秒")
            return True
            
        except Exception as e:
            logger.error(f"加载说话人编码器模型失败: {str(e)}")
            self.is_loaded = False
            return False
    
    def extract_embedding(self, audio_path: Optional[str] = None, 
                         audio_data: Optional[np.ndarray] = None, 
                         sr: Optional[int] = None) -> np.ndarray:
        """
        从音频中提取说话人嵌入
        
        Args:
            audio_path: 音频文件路径
            audio_data: 音频数据（numpy数组）
            sr: 采样率，与audio_data配合使用
            
        Returns:
            说话人嵌入向量
        """
        if not self.is_loaded:
            raise RuntimeError("说话人编码器模型未加载")
        
        # 验证输入
        if audio_path is None and audio_data is None:
            raise ValueError("必须提供audio_path或audio_data")
        
        try:
            # 加载或使用音频数据
            if audio_data is None:
                audio_data, sr = librosa.load(audio_path, sr=self.config.sample_rate)
            elif sr is not None and sr != self.config.sample_rate:
                audio_data = librosa.resample(audio_data, orig_sr=sr, target_sr=self.config.sample_rate)
            
            # 预处理音频
            # 这里是示例，实际预处理逻辑需要根据具体模型要求调整
            preprocessed_audio = self._preprocess_audio(audio_data)
            
            # 提取嵌入（这里是示例，实际推理逻辑需要根据具体模型调整）
            with torch.no_grad():
                # 模拟特征提取，实际应该是：
                # mel_spectrogram = self._extract_mel_spectrogram(preprocessed_audio)
                # embedding = self.model(mel_spectrogram)
                
                # 占位代码，生成随机嵌入
                embedding = np.random.randn(self.config.embedding_dim).astype(np.float32)
                # 归一化嵌入向量
                embedding = embedding / np.linalg.norm(embedding)
            
            return embedding
            
        except Exception as e:
            logger.error(f"提取说话人嵌入失败: {str(e)}")
            # 清理CUDA缓存
            self._clean_cache()
            raise
    
    def _preprocess_audio(self, audio: np.ndarray) -> np.ndarray:
        """
        预处理音频数据
        
        Args:
            audio: 原始音频数据
            
        Returns:
            预处理后的音频数据
        """
        # 音频预处理步骤示例
        # 1. 去除静音
        audio, _ = librosa.effects.trim(audio, top_db=20)
        
        # 2. 归一化
        audio = audio / np.max(np.abs(audio))
        
        return audio
    
    def _extract_mel_spectrogram(self, audio: np.ndarray) -> torch.Tensor:
        """
        提取梅尔频谱图
        
        Args:
            audio: 音频数据
            
        Returns:
            梅尔频谱图
        """
        # 计算梅尔频谱图（示例参数，实际需要根据模型要求调整）
        mel_spectrogram = librosa.feature.melspectrogram(
            y=audio,
            sr=self.config.sample_rate,
            n_fft=1024,
            hop_length=256,
            n_mels=80,
            fmin=0,
            fmax=8000
        )
        
        # 转换为对数梅尔频谱
        log_mel = librosa.power_to_db(mel_spectrogram, ref=np.max)
        
        # 转换为torch张量并调整维度
        log_mel_tensor = torch.tensor(log_mel, dtype=torch.float32, device=self.device)
        log_mel_tensor = log_mel_tensor.unsqueeze(0).unsqueeze(0)  # 添加批次和通道维度
        
        if self.use_half:
            log_mel_tensor = log_mel_tensor.half()
        
        return log_mel_tensor
    
    def save_speaker_embedding(self, name: str, embedding: np.ndarray) -> bool:
        """
        保存说话人嵌入
        
        Args:
            name: 说话人名称
            embedding: 说话人嵌入
            
        Returns:
            是否保存成功
        """
        try:
            # 保存嵌入向量
            embedding_path = os.path.join(self.speakers_dir, f"{name}.npy")
            np.save(embedding_path, embedding)
            
            # 更新说话人索引
            self._update_speaker_index(name)
            
            logger.info(f"说话人 '{name}' 嵌入已保存")
            return True
            
        except Exception as e:
            logger.error(f"保存说话人嵌入失败: {str(e)}")
            return False
    
    def load_speaker_embedding(self, name: str) -> Optional[np.ndarray]:
        """
        加载说话人嵌入
        
        Args:
            name: 说话人名称
            
        Returns:
            说话人嵌入向量或None
        """
        try:
            embedding_path = os.path.join(self.speakers_dir, f"{name}.npy")
            if not os.path.exists(embedding_path):
                logger.warning(f"说话人 '{name}' 的嵌入文件不存在")
                return None
            
            embedding = np.load(embedding_path)
            return embedding
            
        except Exception as e:
            logger.error(f"加载说话人嵌入失败: {str(e)}")
            return None
    
    def _update_speaker_index(self, name: str):
        """
        更新说话人索引
        
        Args:
            name: 新添加的说话人名称
        """
        try:
            index_path = os.path.join(self.speakers_dir, "speakers_index.json")
            
            # 读取现有索引
            if os.path.exists(index_path):
                with open(index_path, 'r', encoding='utf-8') as f:
                    speakers_index = json.load(f)
            else:
                speakers_index = {}
            
            # 添加新说话人
            speakers_index[name] = {
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "embedding_dim": self.config.embedding_dim
            }
            
            # 保存索引
            with open(index_path, 'w', encoding='utf-8') as f:
                json.dump(speakers_index, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"更新说话人索引失败: {str(e)}")
    
    def list_speakers(self) -> List[str]:
        """
        列出所有已保存的说话人
        
        Returns:
            说话人名称列表
        """
        try:
            # 通过索引文件获取说话人列表
            index_path = os.path.join(self.speakers_dir, "speakers_index.json")
            if os.path.exists(index_path):
                with open(index_path, 'r', encoding='utf-8') as f:
                    speakers_index = json.load(f)
                return list(speakers_index.keys())
            
            # 如果没有索引文件，直接扫描目录
            speakers = []
            for filename in os.listdir(self.speakers_dir):
                if filename.endswith('.npy'):
                    speakers.append(os.path.splitext(filename)[0])
            return sorted(speakers)
            
        except Exception as e:
            logger.error(f"列出说话人失败: {str(e)}")
            return []
    
    def delete_speaker(self, name: str) -> bool:
        """
        删除说话人
        
        Args:
            name: 说话人名称
            
        Returns:
            是否删除成功
        """
        try:
            # 删除嵌入文件
            embedding_path = os.path.join(self.speakers_dir, f"{name}.npy")
            if os.path.exists(embedding_path):
                os.remove(embedding_path)
            else:
                logger.warning(f"说话人 '{name}' 的嵌入文件不存在")
            
            # 更新索引
            index_path = os.path.join(self.speakers_dir, "speakers_index.json")
            if os.path.exists(index_path):
                with open(index_path, 'r', encoding='utf-8') as f:
                    speakers_index = json.load(f)
                
                if name in speakers_index:
                    del speakers_index[name]
                    with open(index_path, 'w', encoding='utf-8') as f:
                        json.dump(speakers_index, f, ensure_ascii=False, indent=2)
            
            logger.info(f"说话人 '{name}' 已删除")
            return True
            
        except Exception as e:
            logger.error(f"删除说话人失败: {str(e)}")
            return False
    
    def validate_emotion(self, emotion: str) -> bool:
        """
        验证情感类型是否有效
        
        Args:
            emotion: 情感类型
            
        Returns:
            是否有效
        """
        return emotion in self.emotion_types
    
    def update_device(self, device: str) -> bool:
        """
        更新运行设备
        
        Args:
            device: 新设备名称
            
        Returns:
            是否更新成功
        """
        try:
            if device not in ["cuda", "cpu"]:
                raise ValueError(f"不支持的设备: {device}")
            
            if device == "cuda" and not torch.cuda.is_available():
                raise RuntimeError("CUDA不可用")
            
            if self.device == device:
                logger.info(f"设备已为 {device}，无需更新")
                return True
            
            # 清理旧设备资源
            self._clean_cache()
            
            # 更新设备
            self.device = device
            if self.model:
                self.model.to(self.device)
            
            # 更新精度设置
            self.use_half = self._setup_precision()
            if self.model and self.use_half:
                self.model.half()
            elif self.model and not self.use_half:
                self.model.float()
            
            logger.info(f"设备已更新为: {device}")
            return True
            
        except Exception as e:
            logger.error(f"更新设备失败: {str(e)}")
            return False
    
    def _clean_cache(self):
        """
        清理模型缓存和CUDA内存
        """
        try:
            if self.device == "cuda":
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
            # 清理Python垃圾回收
            gc.collect()
        except Exception as e:
            logger.error(f"清理缓存失败: {str(e)}")
    
    def release(self):
        """
        释放模型资源
        """
        try:
            if self.model:
                # 移至CPU并清空
                self.model.cpu()
                del self.model
                self.model = None
            
            # 清理缓存
            self._clean_cache()
            
            self.is_loaded = False
            logger.info("说话人编码器资源已释放")
        except Exception as e:
            logger.error(f"释放模型资源失败: {str(e)}")

class SpeakerManager:
    """
    说话人管理器
    用于管理说话人编码器和说话人嵌入
    """
    
    def __init__(self):
        """初始化说话人管理器"""
        self.encoder: Optional[SpeakerEncoder] = None
        self.style_params_cache: Dict[str, StyleParams] = {}
        logger.info("说话人管理器已初始化")
    
    def initialize_encoder(self, config: SpeakerEncoderConfig) -> bool:
        """
        初始化说话人编码器
        
        Args:
            config: 编码器配置
            
        Returns:
            是否初始化成功
        """
        try:
            # 如果已有编码器，先释放
            if self.encoder:
                self.release_encoder()
            
            # 创建并加载编码器
            self.encoder = SpeakerEncoder(config)
            success = self.encoder.load_model()
            
            if success:
                logger.info("说话人编码器初始化成功")
            else:
                self.encoder = None
            
            return success
            
        except Exception as e:
            logger.error(f"初始化说话人编码器失败: {str(e)}")
            self.encoder = None
            return False
    
    def add_speaker(self, name: str, wav_path: str, 
                    style_params: Optional[StyleParams] = None) -> bool:
        """
        添加新说话人
        
        Args:
            name: 说话人名称
            wav_path: 参考音频路径
            style_params: 风格参数
            
        Returns:
            是否添加成功
        """
        if not self.encoder:
            logger.error("说话人编码器未初始化")
            return False
        
        try:
            # 提取说话人嵌入
            embedding = self.encoder.extract_embedding(audio_path=wav_path)
            
            # 保存嵌入
            if self.encoder.save_speaker_embedding(name, embedding):
                # 保存风格参数
                if style_params:
                    self.style_params_cache[name] = style_params
                    self._save_style_params()
                logger.info(f"说话人 '{name}' 添加成功")
                return True
            return False
            
        except Exception as e:
            logger.error(f"添加说话人 '{name}' 失败: {str(e)}")
            return False
    
    def delete_speaker(self, name: str) -> bool:
        """
        删除说话人
        
        Args:
            name: 说话人名称
            
        Returns:
            是否删除成功
        """
        if not self.encoder:
            logger.error("说话人编码器未初始化")
            return False
        
        # 删除说话人嵌入
        success = self.encoder.delete_speaker(name)
        
        # 删除风格参数缓存
        if name in self.style_params_cache:
            del self.style_params_cache[name]
            self._save_style_params()
        
        return success
    
    def list_speakers(self) -> List[Dict[str, Union[str, StyleParams]]]:
        """
        列出所有说话人
        
        Returns:
            说话人信息列表
        """
        if not self.encoder:
            logger.error("说话人编码器未初始化")
            return []
        
        speakers = []
        speaker_names = self.encoder.list_speakers()
        
        for name in speaker_names:
            speaker_info = {
                "name": name,
                "style_params": self.style_params_cache.get(name, StyleParams())
            }
            speakers.append(speaker_info)
        
        return speakers
    
    def get_speaker_embedding(self, name: str) -> Optional[np.ndarray]:
        """
        获取说话人嵌入
        
        Args:
            name: 说话人名称
            
        Returns:
            说话人嵌入或None
        """
        if not self.encoder:
            logger.error("说话人编码器未初始化")
            return None
        
        return self.encoder.load_speaker_embedding(name)
    
    def update_speaker_style(self, name: str, style_params: StyleParams) -> bool:
        """
        更新说话人风格参数
        
        Args:
            name: 说话人名称
            style_params: 新的风格参数
            
        Returns:
            是否更新成功
        """
        # 验证说话人是否存在
        if not self.encoder:
            logger.error("说话人编码器未初始化")
            return False
        
        if name not in self.encoder.list_speakers():
            logger.warning(f"说话人 '{name}' 不存在")
            return False
        
        # 验证情感类型
        if not self.encoder.validate_emotion(style_params.emotion):
            logger.warning(f"无效的情感类型: {style_params.emotion}")
            return False
        
        # 更新风格参数
        self.style_params_cache[name] = style_params
        self._save_style_params()
        logger.info(f"说话人 '{name}' 的风格参数已更新")
        return True
    
    def get_speaker_style(self, name: str) -> StyleParams:
        """
        获取说话人风格参数
        
        Args:
            name: 说话人名称
            
        Returns:
            风格参数
        """
        # 如果没有缓存的风格参数，返回默认参数
        return self.style_params_cache.get(name, StyleParams())
    
    def _save_style_params(self):
        """
        保存风格参数到文件
        """
        if not self.encoder:
            return
        
        try:
            style_path = os.path.join(self.encoder.speakers_dir, "style_params.json")
            # 转换StyleParams对象为字典
            style_dict = {}
            for name, params in self.style_params_cache.items():
                style_dict[name] = {
                    "pitch": params.pitch,
                    "speed": params.speed,
                    "emotion": params.emotion,
                    "energy": params.energy,
                    "tone": params.tone
                }
            
            with open(style_path, 'w', encoding='utf-8') as f:
                json.dump(style_dict, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"保存风格参数失败: {str(e)}")
    
    def _load_style_params(self):
        """
        从文件加载风格参数
        """
        if not self.encoder:
            return
        
        try:
            style_path = os.path.join(self.encoder.speakers_dir, "style_params.json")
            if os.path.exists(style_path):
                with open(style_path, 'r', encoding='utf-8') as f:
                    style_dict = json.load(f)
                
                # 转换字典为StyleParams对象
                for name, params_dict in style_dict.items():
                    self.style_params_cache[name] = StyleParams(**params_dict)
                
                logger.info(f"已加载 {len(self.style_params_cache)} 个说话人的风格参数")
                
        except Exception as e:
            logger.error(f"加载风格参数失败: {str(e)}")
    
    def update_device(self, device: str) -> bool:
        """
        更新编码器设备
        
        Args:
            device: 新设备名称
            
        Returns:
            是否更新成功
        """
        if not self.encoder:
            logger.error("说话人编码器未初始化")
            return False
        
        return self.encoder.update_device(device)
    
    def release_encoder(self):
        """
        释放编码器资源
        """
        if self.encoder:
            self.encoder.release()
            self.encoder = None
            logger.info("说话人编码器资源已释放")
    
    def is_initialized(self) -> bool:
        """
        检查编码器是否已初始化
        
        Returns:
            是否已初始化
        """
        return self.encoder is not None and self.encoder.is_loaded

# 全局说话人管理器实例
_speaker_manager = None

def get_speaker_manager() -> SpeakerManager:
    """
    获取全局说话人管理器实例
    
    Returns:
        说话人管理器实例
    """
    global _speaker_manager
    if _speaker_manager is None:
        _speaker_manager = SpeakerManager()
    return _speaker_manager