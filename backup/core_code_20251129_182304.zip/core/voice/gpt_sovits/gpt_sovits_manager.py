# -*- coding: utf-8 -*-
"""
GPT-SoVITS 2Pro TTS管理器实现
"""

import os
import asyncio
import logging
import torch
from .path_config import PRETRAINED_MODELS_DIR, GPT_SOVITS_ROOT
from typing import Dict, Optional, Any

from ..base.tts_manager_base import TTSManagerBase
from ..base.config_base import TTSConfigBase
from ..base.engine_base import TTSEngineBase
from .gpt_sovits_config import GPTSoVITSConfig
from .optimized_engine import OptimizedGPTSoVITSEngine
from .gpt_sovits_speaker_manager import GPTSoVITSSpeakerManager

logger = logging.getLogger(__name__)


class GPTSoVITSManager(TTSManagerBase):
    """
    GPT-SoVITS 2Pro TTS管理器，整合引擎和说话人管理功能
    """
    
    def __init__(self):
        """
        初始化GPT-SoVITS管理器
        """
        super().__init__()
    
    async def initialize(self, config: Dict[str, Any] = None):
        """
        初始化TTS管理器
        
        Args:
            config: 配置字典或对象，包含TTS配置参数
            
        Raises:
            RuntimeError: 初始化失败
        """
        async with self._lock:
            # 设置默认配置并合并传入的配置
            default_config = {
                "device": "cuda" if torch.cuda.is_available() else "cpu",
                "model_dir": os.path.join(os.path.dirname(__file__), "models"),
                "cache_enabled": True,
                "cache_size_limit": 1024,
                "cache_time_limit": 3600,
                "sample_rate": 44100
            }
            
            # 处理不同类型的配置输入
            if config:
                if isinstance(config, TTSConfigBase):
                    # 是TTSConfigBase子类，使用to_dict转换
                    config_dict = config.to_dict()
                    self._config = {**default_config, **config_dict}
                elif hasattr(config, "__dict__"):
                    # 有__dict__属性的对象
                    config_dict = config.__dict__
                    self._config = {**default_config, **config_dict}
                else:
                    # 字典类型
                    self._config = {**default_config, **config}
            else:
                self._config = default_config
            
            # 从配置中提取参数
            device = self._config.get("device", "cuda" if torch.cuda.is_available() else "cpu")
            sample_rate = self._config.get("sample_rate", 44100)
            
            # 初始化并注册GPT-SoVITS引擎
            engine_config = {
                'device': device,
                'precision': self._config.get('precision', 'fp32'),
                'sample_rate': sample_rate,
                'model_dir': self._config.get("model_dir"),
                'cache_enabled': self._config.get("cache_enabled", True),
                'cache_size_limit': self._config.get("cache_size_limit", 1024),
                'cache_time_limit': self._config.get("cache_time_limit", 3600),
                'force_max_sec': 30,
                'force_use_vocoder': True,
                'vocoder_version': 'v4'
            }
            try:
                def _find_dir(names):
                    for base in [PRETRAINED_MODELS_DIR, GPT_SOVITS_ROOT]:
                        if not base or not os.path.isdir(base):
                            continue
                        for name in names:
                            p = os.path.join(base, name)
                            if os.path.isdir(p):
                                return p
                    for root, dirs, _ in os.walk(GPT_SOVITS_ROOT):
                        for name in names:
                            if name in dirs:
                                return os.path.join(root, name)
                    return None

                def _find_file(paths):
                    for p in paths:
                        if p and os.path.isfile(p):
                            return p
                    for root, _, files in os.walk(GPT_SOVITS_ROOT):
                        for name in [os.path.basename(x) for x in paths if x]:
                            if name in files:
                                return os.path.join(root, name)
                    return None

                bert_dir = _find_dir(['chinese-roberta-wwm-ext-large'])
                hubert_dir = _find_dir(['chinese-hubert-base'])

                v2pro_dir = _find_dir(['v2Pro'])

                proj_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                models_dir = os.path.join(proj_root, 'models')
                def _first_ckpt(dirp):
                    try:
                        for n in os.listdir(dirp):
                            p = os.path.join(dirp, n)
                            if os.path.isfile(p) and n.lower().endswith('.ckpt'):
                                return p
                    except Exception:
                        return None
                    return None
                local_ckpt = _first_ckpt(models_dir)
                gpt_candidates = [
                    local_ckpt,
                    os.path.join(GPT_SOVITS_ROOT, 'GPT_SoVITS', 'pretrained_models', 's1v3.ckpt'),
                ]
                gpt_env = os.environ.get('gpt_path')
                gpt_path = gpt_env if (gpt_env and os.path.isfile(gpt_env)) else _find_file([p for p in gpt_candidates if p])

                sovits_candidates = [
                    os.path.join(GPT_SOVITS_ROOT, 'GPT_SoVITS', 'pretrained_models', 'v2Pro', 's2Gv2ProPlus.pth'),
                    os.path.join(v2pro_dir or '', 's2Gv2ProPlus.pth'),
                    os.path.join(GPT_SOVITS_ROOT, 'GPT_SoVITS', 'pretrained_models', 'v2Pro', 's2Gv2Pro.pth'),
                    os.path.join(v2pro_dir or '', 's2Gv2Pro.pth'),
                ]
                sovits_env = os.environ.get('sovits_path')
                sovits_path = sovits_env if (sovits_env and os.path.isfile(sovits_env)) else _find_file(sovits_candidates)

                engine_config.update({
                    'bert_path': bert_dir or os.path.join(PRETRAINED_MODELS_DIR, 'chinese-roberta-wwm-ext-large'),
                    'cnhubert_base_path': hubert_dir or os.path.join(PRETRAINED_MODELS_DIR, 'chinese-hubert-base'),
                    'gpt_path': gpt_path,
                    'sovits_path': sovits_path,
                    'version': 'v2Pro'
                })
            except Exception:
                pass
            try:
                bp = engine_config.get('bert_path')
                hp = engine_config.get('cnhubert_base_path')
                gp = engine_config.get('gpt_path')
                sp = engine_config.get('sovits_path')
                missing = []
                if not (bp and os.path.isdir(bp)):
                    missing.append('bert_path=' + str(bp))
                if not (hp and os.path.isdir(hp)):
                    missing.append('cnhubert_base_path=' + str(hp))
                if not (gp and os.path.isfile(gp)):
                    missing.append('gpt_path=' + str(gp))
                if not (sp and os.path.isfile(sp)):
                    missing.append('sovits_path=' + str(sp))
                if missing:
                    logger.error('缺少GPT-SoVITS权重或资源: ' + '; '.join(missing))
            except Exception:
                logger.error('预检失败')
            engine = OptimizedGPTSoVITSEngine(config=engine_config)
            
            await engine.initialize()
            
            await self.register_engine("gpt_sovits", engine, set_active=True)
            
            # 初始化并注册说话人管理器
            speaker_manager = GPTSoVITSSpeakerManager()
            
            await speaker_manager.initialize()
            
            await self.register_speaker_manager("gpt_sovits", speaker_manager)
            
            logger.info("GPT-SoVITS管理器初始化完成")

            try:
                proj_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                ref_dir = os.path.join(proj_root, 'ref_audio', 'female')
                candidates = [os.path.join(ref_dir, f) for f in os.listdir(ref_dir) if f.lower().endswith('.wav') and f.lower().startswith('ref')]
                neutral = [p for p in candidates if 'neutral' in os.path.basename(p).lower() or '平静' in os.path.basename(p)]
                ref = (neutral[0] if neutral else (candidates[0] if candidates else None))
                if ref:
                    try:
                        _ = await engine.synthesize("你好", ref_wav_path=ref, text_language='中文', prompt_language='中文', how_to_cut='不切', parallel_infer=False, split_bucket=False)
                    except Exception:
                        pass
            except Exception:
                pass
    
    async def register_engine(self, engine_id: str, engine: TTSEngineBase, set_active: bool = False):
        """
        注册TTS引擎
        
        Args:
            engine_id: 引擎ID
            engine: GPT-SoVITS引擎实例
            set_active: 是否设为当前活动引擎
            
        Raises:
            ValueError: 引擎ID已存在
        """
        if engine_id in self._engines:
            raise ValueError(f"引擎ID '{engine_id}' 已存在")
        
        self._engines[engine_id] = engine
        
        if set_active:
            self._active_engine_id = engine_id
            logger.info(f"引擎 '{engine_id}' 已注册并设为活动引擎")
        else:
            logger.info(f"引擎 '{engine_id}' 已注册")
    
    async def register_speaker_manager(self, manager_id: str, manager: GPTSoVITSSpeakerManager):
        """
        注册说话人管理器
        
        Args:
            manager_id: 管理器ID
            manager: 说话人管理器实例
            
        Raises:
            ValueError: 管理器ID已存在
        """
        if manager_id in self._speaker_managers:
            raise ValueError(f"说话人管理器ID '{manager_id}' 已存在")
        
        self._speaker_managers[manager_id] = manager
        logger.info(f"说话人管理器 '{manager_id}' 已注册")
    
    async def set_active_engine(self, engine_id: str):
        """
        设置当前活动引擎
        
        Args:
            engine_id: 引擎ID
            
        Raises:
            ValueError: 引擎不存在
        """
        if engine_id not in self._engines:
            raise ValueError(f"引擎ID '{engine_id}' 不存在")
        
        self._active_engine_id = engine_id
        logger.info(f"活动引擎已切换为: {engine_id}")
    
    async def synthesize(self, text: str, **kwargs) -> Any:
        """
        使用当前活动引擎合成语音
        
        Args:
            text: 要合成的文本
            **kwargs: 合成参数
                - speaker_id: 说话人ID
                - reference_audio: 参考音频路径（用于语音克隆）
                - speaker_wav: 参考音频路径（用于语音克隆，别名）
                - ref_wav_path: 参考音频路径（用于语音克隆，内部引擎参数名）
                - speed: 语速调整系数
                - pitch: 音高调整系数
                - style: 语音风格
            
        Returns:
            音频数据
            
        Raises:
            RuntimeError: 无活动引擎或合成失败
        """
        if not self._active_engine_id or self._active_engine_id not in self._engines:
            raise RuntimeError("无活动的TTS引擎")
        
        active_engine = self._engines[self._active_engine_id]
        
        # 确保引擎已初始化
        if not hasattr(active_engine, '_is_initialized') or not active_engine._is_initialized:
            await active_engine.initialize()
        
        # 调试日志
        logger.info(f"调试: gpt_sovits_manager.synthesize收到的kwargs: {kwargs.keys()}")
        
        # 处理参数映射 - 支持多种参数名
        engine_kwargs = kwargs.copy()
        
        # 检查并映射参考音频参数名，优先保留ref_wav_path
        reference_audio = None
        
        # 优先检查ref_wav_path，因为这是引擎直接需要的
        if 'ref_wav_path' in engine_kwargs:
            reference_audio = engine_kwargs['ref_wav_path']
            logger.info(f"调试: 直接使用ref_wav_path参数: {reference_audio}")
        else:
            # 然后检查其他可能的参数名
            for param_name in ['reference_audio', 'speaker_wav']:
                if param_name in engine_kwargs:
                    reference_audio = engine_kwargs[param_name]
                    engine_kwargs['ref_wav_path'] = reference_audio
                    logger.info(f"调试: 从{param_name}映射到ref_wav_path: {reference_audio}")
                    break
        
        if reference_audio:
            logger.info(f"调试: 参考音频值: {reference_audio}")
            logger.info(f"调试: 参考音频类型: {type(reference_audio)}")
            
            # 确保ref_wav_path存在于参数中
            if 'ref_wav_path' not in engine_kwargs:
                engine_kwargs['ref_wav_path'] = reference_audio
                logger.info(f"调试: 确保ref_wav_path存在: {reference_audio}")
            
            if os.path.exists(reference_audio):
                logger.info(f"调试: 参考音频文件存在，大小: {os.path.getsize(reference_audio)} 字节")
                logger.info(f"使用参考音频进行语音克隆: {reference_audio}")
            else:
                logger.warning(f"调试: 参考音频文件不存在: {reference_audio}")
        else:
            logger.info("调试: 未提供参考音频")
            logger.info("使用内置TTS模型进行语音合成")
        
        # 调试：打印传递给引擎的最终参数
        logger.info(f"调试: 传递给引擎的最终参数: {engine_kwargs.keys()}")
        
        # 调试：确保active_engine和参数正确
        logger.info(f"调试: active_engine类型: {type(active_engine)}")
        logger.info(f"调试: 传递给active_engine.synthesize的ref_wav_path: {engine_kwargs.get('ref_wav_path')}")
        
        # 调用引擎的synthesize方法，参数中已经包含ref_wav_path
        try:
            result = await active_engine.synthesize(text, **engine_kwargs)
            return result
        except Exception as e:
            logger.error(f"调试: 引擎synthesize调用异常: {str(e)}")
            # 检查是否是ref_wav_path参数问题
            if 'ref_wav_path' in str(e):
                logger.error("调试: 引擎参数处理存在问题")
            raise
    
    async def clone_voice(self, text: str, reference_audio: str, **kwargs) -> Any:
        """
        语音克隆专用方法
        
        Args:
            text: 要合成的文本
            reference_audio: 参考音频路径
            **kwargs: 其他合成参数
            
        Returns:
            克隆后的音频数据
            
        Raises:
            ValueError: 参数错误
            RuntimeError: 克隆失败
        """
        if not reference_audio:
            raise ValueError("语音克隆需要提供参考音频")
        
        # 确保引擎已初始化
        # 直接使用synthesize方法，它内部会处理引擎初始化
        
        # 直接设置引擎需要的ref_wav_path参数
        kwargs_copy = kwargs.copy()
        kwargs_copy['ref_wav_path'] = reference_audio
        
        logger.info(f"调试: clone_voice直接使用ref_wav_path: {reference_audio}")
        
        # 调用合成方法，但避免参数丢失
        return await self.synthesize(text, **kwargs_copy)
