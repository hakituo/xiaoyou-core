import os
import time
import logging
import threading
import queue
import gc
from typing import Dict, Optional, Union, List, Tuple
from dataclasses import dataclass

import torch

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("device_manager")

# 任务优先级
task_priority = {
    "normal": 0,
    "high": 1,
    "critical": 2
}

# 任务状态
@dataclass
class Task:
    id: str
    priority: int
    func: callable
    args: tuple
    kwargs: dict
    created_at: float
    result: Optional[any] = None
    exception: Optional[Exception] = None
    completed: bool = False

# 设备信息
@dataclass
class DeviceInfo:
    device: torch.device
    is_available: bool
    total_memory: Optional[int] = None  # 字节
    used_memory: Optional[int] = None   # 字节
    utilization: Optional[float] = None  # 百分比
    model_count: int = 0
    task_count: int = 0

# 设备管理器类
class DeviceManager:
    def __init__(self):
        """初始化设备管理器"""
        # 设备列表
        self.devices: Dict[str, DeviceInfo] = {}
        # 任务队列（优先级队列）
        self.task_queue = queue.PriorityQueue()
        # 工作线程
        self.worker_threads: List[threading.Thread] = []
        # 停止标志
        self.stop_event = threading.Event()
        # 锁
        self.lock = threading.Lock()
        # 配置参数
        self.config = {
            "max_gpu_memory_usage": 0.9,  # 最大GPU内存使用率
            "min_gpu_memory_free": 500 * 1024 * 1024,  # 最小可用GPU内存（500MB）
            "max_tasks_per_device": 5,  # 每个设备最大任务数
            "auto_clean_cache": True,  # 自动清理缓存
            "clean_cache_interval": 30,  # 清理缓存间隔（秒）
            "cpu_fallback": True,  # 当GPU不可用时回退到CPU
        }
        
        # 初始化设备
        self._initialize_devices()
        
        # 启动监控线程
        self.monitor_thread = threading.Thread(target=self._monitor_devices, daemon=True)
        self.monitor_thread.start()
        
        # 启动缓存清理线程
        self.cache_cleaner_thread = threading.Thread(target=self._cache_cleaner, daemon=True)
        self.cache_cleaner_thread.start()
        
        logger.info("Device manager initialized")
    
    def _initialize_devices(self):
        """初始化可用设备"""
        # 添加CPU
        cpu_device = torch.device("cpu")
        self.devices["cpu"] = DeviceInfo(
            device=cpu_device,
            is_available=True
        )
        logger.info(f"CPU device available")
        
        # 检查并添加GPU
        if torch.cuda.is_available():
            num_gpus = torch.cuda.device_count()
            logger.info(f"Found {num_gpus} GPU(s)")
            
            for i in range(num_gpus):
                try:
                    gpu_device = torch.device(f"cuda:{i}")
                    # 测试GPU是否正常工作
                    torch.tensor([1.0], device=gpu_device)
                    
                    # 获取GPU内存信息
                    prop = torch.cuda.get_device_properties(gpu_device)
                    total_memory = prop.total_memory
                    
                    self.devices[f"cuda:{i}"] = DeviceInfo(
                        device=gpu_device,
                        is_available=True,
                        total_memory=total_memory,
                        used_memory=torch.cuda.memory_allocated(gpu_device)
                    )
                    logger.info(f"GPU {i} ({prop.name}) available with {total_memory / 1024**3:.2f}GB memory")
                    
                except Exception as e:
                    logger.warning(f"GPU {i} initialization failed: {e}")
        else:
            logger.warning("CUDA is not available, using CPU only")
    
    def _monitor_devices(self):
        """监控设备状态"""
        while not self.stop_event.is_set():
            self.update_device_info()
            time.sleep(5)  # 每5秒更新一次
    
    def _cache_cleaner(self):
        """定期清理缓存"""
        while not self.stop_event.is_set():
            if self.config["auto_clean_cache"]:
                self.clean_cache()
            time.sleep(self.config["clean_cache_interval"])
    
    def update_device_info(self):
        """更新设备信息"""
        with self.lock:
            for device_name, device_info in self.devices.items():
                if device_name.startswith("cuda"):
                    try:
                        # 更新GPU内存使用情况
                        device_info.used_memory = torch.cuda.memory_allocated(device_info.device)
                        # 更新GPU利用率（如果支持）
                        if hasattr(torch.cuda, 'utilization'):
                            device_info.utilization = torch.cuda.utilization(device_info.device)
                    except Exception as e:
                        logger.error(f"Failed to update device info for {device_name}: {e}")
                        device_info.is_available = False
    
    def get_device(self, preferred_device: Union[str, torch.device] = "auto") -> Optional[torch.device]:
        """
        获取最合适的设备
        
        Args:
            preferred_device: 首选设备，可以是"auto", "cuda", "cpu"或具体的设备
            
        Returns:
            可用的设备对象，如果没有可用设备则返回None
        """
        with self.lock:
            # 如果指定了具体设备
            if isinstance(preferred_device, torch.device):
                device_name = str(preferred_device)
                if device_name in self.devices and self.devices[device_name].is_available:
                    # 检查GPU内存是否足够
                    if device_name.startswith("cuda"):
                        if self._check_gpu_memory(device_name):
                            return preferred_device
                    else:
                        return preferred_device
            elif preferred_device != "auto":
                # 处理字符串形式的设备
                if preferred_device == "cuda":
                    # 选择第一个可用的GPU
                    for device_name in self.devices:
                        if device_name.startswith("cuda") and self.devices[device_name].is_available:
                            if self._check_gpu_memory(device_name):
                                return self.devices[device_name].device
                elif preferred_device == "cpu":
                    if "cpu" in self.devices and self.devices["cpu"].is_available:
                        return self.devices["cpu"].device
            
            # 自动选择模式
            if preferred_device == "auto":
                # 首先尝试所有GPU
                for device_name in sorted(self.devices.keys()):
                    if device_name.startswith("cuda") and self.devices[device_name].is_available:
                        if self._check_gpu_memory(device_name):
                            return self.devices[device_name].device
                
                # 如果没有可用GPU或GPU内存不足，回退到CPU
                if self.config["cpu_fallback"] and "cpu" in self.devices and self.devices["cpu"].is_available:
                    logger.info("No suitable GPU found, falling back to CPU")
                    return self.devices["cpu"].device
            
            logger.error(f"No suitable device found for {preferred_device}")
            return None
    
    def _check_gpu_memory(self, device_name: str) -> bool:
        """检查GPU内存是否足够"""
        device_info = self.devices.get(device_name)
        if not device_info or not device_info.is_available:
            return False
        
        if device_info.total_memory is None or device_info.used_memory is None:
            return False
        
        # 计算可用内存
        available_memory = device_info.total_memory - device_info.used_memory
        
        # 检查内存使用百分比
        memory_usage_percent = device_info.used_memory / device_info.total_memory
        
        # 检查是否满足内存要求
        if (memory_usage_percent < self.config["max_gpu_memory_usage"] and 
            available_memory > self.config["min_gpu_memory_free"]):
            return True
        else:
            logger.warning(f"GPU memory insufficient: {memory_usage_percent:.2%} used, {available_memory / 1024**3:.2f}GB free")
            return False
    
    def clean_cache(self, device: Optional[torch.device] = None):
        """清理缓存"""
        try:
            # 清理指定设备的缓存
            if device is not None:
                if device.type == "cuda":
                    torch.cuda.empty_cache()
                    torch.cuda.ipc_collect()
                    logger.debug(f"Cache cleaned for {device}")
            else:
                # 清理所有GPU缓存
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    torch.cuda.ipc_collect()
                    logger.debug("Cache cleaned for all CUDA devices")
            
            # 执行Python垃圾回收
            gc.collect()
            
        except Exception as e:
            logger.error(f"Failed to clean cache: {e}")
    
    def execute_task(self, task: Task) -> any:
        """执行任务"""
        device = self.get_device()
        if not device:
            raise RuntimeError("No available device to execute task")
        
        # 更新设备任务计数
        device_name = str(device)
        if device_name in self.devices:
            self.devices[device_name].task_count += 1
        
        try:
            # 执行任务
            result = task.func(*task.args, device=device, **task.kwargs)
            task.result = result
            task.completed = True
            return result
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
            task.exception = e
            
            # 尝试清理缓存并重试
            if device.type == "cuda":
                logger.info("Attempting to clean cache and retry")
                self.clean_cache(device)
                try:
                    result = task.func(*task.args, device=device, **task.kwargs)
                    task.result = result
                    task.completed = True
                    return result
                except Exception as e2:
                    logger.error(f"Retry failed: {e2}")
                    raise
            
            raise
        finally:
            # 更新设备任务计数
            if device_name in self.devices:
                self.devices[device_name].task_count -= 1
            
            # 清理缓存
            if device.type == "cuda":
                self.clean_cache(device)
    
    def submit_task(self, func: callable, *args, priority: str = "normal", **kwargs) -> str:
        """
        提交任务到队列
        
        Args:
            func: 要执行的函数
            priority: 任务优先级 ("normal", "high", "critical")
            *args, **kwargs: 函数参数
            
        Returns:
            任务ID
        """
        task_id = f"task_{int(time.time() * 1000)}_{threading.get_ident()}"
        task = Task(
            id=task_id,
            priority=task_priority.get(priority, 0),
            func=func,
            args=args,
            kwargs=kwargs,
            created_at=time.time()
        )
        
        # 将任务添加到队列（使用负优先级，因为PriorityQueue是小顶堆）
        self.task_queue.put((-task.priority, task_id, task))
        logger.debug(f"Task {task_id} submitted with priority {priority}")
        
        return task_id
    
    def run_worker(self):
        """运行工作线程"""
        while not self.stop_event.is_set():
            try:
                # 从队列获取任务
                _, task_id, task = self.task_queue.get(timeout=1)
                
                try:
                    # 执行任务
                    self.execute_task(task)
                except Exception as e:
                    logger.error(f"Worker failed to execute task {task_id}: {e}")
                finally:
                    # 标记任务完成
                    self.task_queue.task_done()
                    
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Worker error: {e}")
    
    def start_workers(self, num_workers: int = 1):
        """
        启动工作线程
        
        Args:
            num_workers: 工作线程数量
        """
        for i in range(num_workers):
            thread = threading.Thread(target=self.run_worker, daemon=True)
            thread.start()
            self.worker_threads.append(thread)
            logger.info(f"Worker thread {i} started")
    
    def set_model_on_device(self, model_name: str, device: torch.device):
        """在设备上注册模型"""
        with self.lock:
            device_name = str(device)
            if device_name in self.devices:
                self.devices[device_name].model_count += 1
                logger.debug(f"Model {model_name} registered on {device_name}")
    
    def remove_model_from_device(self, model_name: str, device: torch.device):
        """从设备上注销模型"""
        with self.lock:
            device_name = str(device)
            if device_name in self.devices and self.devices[device_name].model_count > 0:
                self.devices[device_name].model_count -= 1
                logger.debug(f"Model {model_name} removed from {device_name}")
    
    def get_device_stats(self) -> Dict[str, Dict]:
        """获取设备统计信息"""
        stats = {}
        with self.lock:
            for device_name, device_info in self.devices.items():
                stats[device_name] = {
                    "available": device_info.is_available,
                    "model_count": device_info.model_count,
                    "task_count": device_info.task_count
                }
                
                if device_info.total_memory is not None:
                    stats[device_name]["total_memory"] = device_info.total_memory
                    stats[device_name]["memory_gb"] = device_info.total_memory / 1024**3
                
                if device_info.used_memory is not None:
                    stats[device_name]["used_memory"] = device_info.used_memory
                    stats[device_name]["used_memory_gb"] = device_info.used_memory / 1024**3
                    if device_info.total_memory is not None:
                        stats[device_name]["memory_usage_percent"] = (device_info.used_memory / device_info.total_memory) * 100
                
                if device_info.utilization is not None:
                    stats[device_name]["utilization"] = device_info.utilization
        
        return stats
    
    def release_resources(self):
        """释放所有资源"""
        # 停止事件
        self.stop_event.set()
        
        # 等待线程结束
        if hasattr(self, 'monitor_thread') and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=2)
        
        if hasattr(self, 'cache_cleaner_thread') and self.cache_cleaner_thread.is_alive():
            self.cache_cleaner_thread.join(timeout=2)
        
        for thread in self.worker_threads:
            if thread.is_alive():
                thread.join(timeout=2)
        
        # 清理所有缓存
        self.clean_cache()
        
        logger.info("Device manager resources released")

# 全局设备管理器实例
_global_device_manager = None

def get_device_manager() -> DeviceManager:
    """
    获取全局设备管理器实例
    
    Returns:
        DeviceManager实例
    """
    global _global_device_manager
    if _global_device_manager is None:
        _global_device_manager = DeviceManager()
    return _global_device_manager

# 上下文管理器，用于安全地使用设备
class DeviceContext:
    def __init__(self, preferred_device: Union[str, torch.device] = "auto"):
        self.preferred_device = preferred_device
        self.device = None
        self.device_manager = get_device_manager()
    
    def __enter__(self) -> torch.device:
        """进入上下文时获取设备"""
        self.device = self.device_manager.get_device(self.preferred_device)
        if not self.device:
            raise RuntimeError(f"Failed to get device for {self.preferred_device}")
        return self.device
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文时清理资源"""
        if self.device and self.device.type == "cuda":
            self.device_manager.clean_cache(self.device)
        
        # 如果有异常，尝试清理更多资源
        if exc_type is not None:
            self.device_manager.clean_cache()
            gc.collect()
        
        return False  # 不抑制异常

# 装饰器，用于在适当的设备上执行函数
def with_device(preferred_device: Union[str, torch.device] = "auto"):
    """
    装饰器，确保函数在适当的设备上执行
    
    Args:
        preferred_device: 首选设备
        
    Returns:
        装饰后的函数
    """
    def decorator(func):
        def wrapper(*args, device=None, **kwargs):
            # 如果已经提供了device参数，直接使用
            if device is not None:
                return func(*args, device=device, **kwargs)
            
            # 否则获取设备
            device_manager = get_device_manager()
            device = device_manager.get_device(preferred_device)
            
            if not device:
                raise RuntimeError(f"No available device for {preferred_device}")
            
            try:
                return func(*args, device=device, **kwargs)
            finally:
                # 执行完毕后清理缓存
                if device.type == "cuda":
                    device_manager.clean_cache(device)
        
        return wrapper
    
    return decorator

# 工具函数：将模型移至适当的设备
def move_model_to_device(model, preferred_device: Union[str, torch.device] = "auto") -> torch.nn.Module:
    """
    将模型移动到适当的设备
    
    Args:
        model: PyTorch模型
        preferred_device: 首选设备
        
    Returns:
        移动后的模型
    """
    device_manager = get_device_manager()
    device = device_manager.get_device(preferred_device)
    
    if not device:
        raise RuntimeError(f"Failed to get device for model: {preferred_device}")
    
    # 移动模型
    model = model.to(device)
    
    # 在设备管理器中注册模型
    model_name = getattr(model, "__name__", str(type(model)))
    device_manager.set_model_on_device(model_name, device)
    
    # 为模型添加释放方法
    original_del = getattr(model, "__del__", None)
    
    def new_del(self):
        if original_del:
            original_del(self)
        try:
            model_name = getattr(self, "__name__", str(type(self)))
            device_manager = get_device_manager()
            device_manager.remove_model_from_device(model_name, device)
            device_manager.clean_cache(device)
        except:
            pass  # 避免在__del__中抛出异常
    
    model.__del__ = new_del.__get__(model)
    
    logger.debug(f"Model {model_name} moved to {device}")
    return model

# 工具函数：安全地执行推理
def safe_inference(func):
    """
    安全推理装饰器，处理异常和资源释放
    
    Args:
        func: 推理函数
        
    Returns:
        装饰后的函数
    """
    def wrapper(*args, **kwargs):
        device_manager = get_device_manager()
        
        try:
            return func(*args, **kwargs)
        except RuntimeError as e:
            # 处理CUDA相关错误
            if "CUDA out of memory" in str(e) or "cuda runtime error" in str(e).lower():
                logger.error(f"CUDA error during inference: {e}")
                # 清理缓存
                device_manager.clean_cache()
                gc.collect()
                
                # 尝试在CPU上重新执行
                if "device" in kwargs and kwargs["device"].type == "cuda":
                    logger.info("Retrying inference on CPU")
                    kwargs["device"] = torch.device("cpu")
                    return func(*args, **kwargs)
            
            raise  # 重新抛出其他错误
        except Exception as e:
            logger.error(f"Error during inference: {e}")
            # 清理资源
            device_manager.clean_cache()
            gc.collect()
            raise
        finally:
            # 确保清理资源
            if "device" in kwargs:
                device_manager.clean_cache(kwargs["device"])
            
    return wrapper

# 导出API
__all__ = [
    "DeviceManager",
    "get_device_manager",
    "DeviceContext",
    "with_device",
    "move_model_to_device",
    "safe_inference"
]