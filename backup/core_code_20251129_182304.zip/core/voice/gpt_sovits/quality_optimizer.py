# -*- coding: utf-8 -*-
"""
GPT-SoVITS 2Pro 语音质量优化器
提供音频后处理、参数优化和质量评估功能
"""

import os
import torch
import numpy as np
import logging
import asyncio
from typing import Dict, List, Optional, Union, Tuple, Callable
import time
import re

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("GPTSoVITS-QualityOptimizer")

# 尝试导入必要的音频处理库
try:
    import scipy.signal as signal
    import librosa
    import soundfile as sf
    HAS_ADVANCED_LIBS = True
except ImportError:
    logger.warning("无法导入高级音频处理库，将使用基础功能")
    HAS_ADVANCED_LIBS = False

class AudioPostProcessor:
    """
    音频后处理器
    提供各种音频质量提升技术
    """
    
    @staticmethod
    def normalize_audio(audio: np.ndarray, target_level: float = 0.9) -> np.ndarray:
        """
        音频归一化
        
        Args:
            audio: 音频数据
            target_level: 目标归一化级别 (0.0-1.0)
            
        Returns:
            归一化后的音频
        """
        max_val = np.max(np.abs(audio))
        if max_val > 0:
            audio = audio * (target_level / max_val)
        return audio
    
    @staticmethod
    def remove_clipping(audio: np.ndarray, threshold: float = 0.95) -> np.ndarray:
        """
        移除音频削波失真
        
        Args:
            audio: 音频数据
            threshold: 削波阈值
            
        Returns:
            处理后的音频
        """
        # 检测削波区域
        clipped_indices = np.abs(audio) >= threshold
        
        if np.any(clipped_indices):
            # 查找连续的削波区域
            clipped_regions = []
            start = None
            for i, is_clipped in enumerate(clipped_indices):
                if is_clipped and start is None:
                    start = i
                elif not is_clipped and start is not None:
                    clipped_regions.append((start, i - 1))
                    start = None
            
            # 处理最后一个区域
            if start is not None:
                clipped_regions.append((start, len(audio) - 1))
            
            # 对每个削波区域进行修复
            for start_idx, end_idx in clipped_regions:
                # 只处理短时间的削波
                if end_idx - start_idx < 100:  # 小于100个采样点
                    # 找到附近的未削波区域作为参考
                    left_start = max(0, start_idx - 50)
                    right_end = min(len(audio) - 1, end_idx + 50)
                    
                    # 使用线性插值修复
                    left_val = audio[left_start]
                    right_val = audio[right_end]
                    
                    # 计算插值
                    if right_end - left_start > 0:
                        x = np.linspace(0, 1, end_idx - start_idx + 1)
                        # 使用平滑的曲线过渡
                        audio[start_idx:end_idx+1] = left_val * (1 - x) + right_val * x
                    
        return audio
    
    @staticmethod
    def apply_gain(audio: np.ndarray, gain_db: float) -> np.ndarray:
        """
        应用增益
        
        Args:
            audio: 音频数据
            gain_db: 增益值（分贝）
            
        Returns:
            处理后的音频
        """
        gain_factor = 10 ** (gain_db / 20)
        return audio * gain_factor
    
    @staticmethod
    def apply_smoothing(audio: np.ndarray, sample_rate: int, smoothing_ms: float = 10.0) -> np.ndarray:
        """
        应用平滑处理，减少突变噪声
        
        Args:
            audio: 音频数据
            sample_rate: 采样率
            smoothing_ms: 平滑窗口大小（毫秒）
            
        Returns:
            处理后的音频
        """
        # 计算窗口大小
        window_size = int(sample_rate * smoothing_ms / 1000)
        if window_size % 2 == 0:
            window_size += 1  # 确保窗口大小为奇数
        
        # 应用移动平均滤波
        window = np.ones(window_size) / window_size
        smoothed = np.convolve(audio, window, mode='same')
        
        # 保留原始音频的首尾部分
        smoothed[:window_size//2] = audio[:window_size//2]
        smoothed[-window_size//2:] = audio[-window_size//2:]
        
        return smoothed
    
    @staticmethod
    def apply_dynamic_range_compression(audio: np.ndarray, threshold: float = 0.1, ratio: float = 2.0) -> np.ndarray:
        """
        应用动态范围压缩
        
        Args:
            audio: 音频数据
            threshold: 压缩阈值
            ratio: 压缩比率
            
        Returns:
            处理后的音频
        """
        # 对音频进行动态范围压缩
        compressed = np.copy(audio)
        
        # 找到超过阈值的部分
        above_threshold = np.abs(audio) > threshold
        
        if np.any(above_threshold):
            # 计算压缩后的幅度
            compressed[above_threshold] = np.sign(audio[above_threshold]) * (
                threshold + (np.abs(audio[above_threshold]) - threshold) / ratio
            )
        
        return compressed
    
    @staticmethod
    def apply_basic_noise_reduction(audio: np.ndarray, reduction_strength: float = 0.1) -> np.ndarray:
        """
        基本噪声消除
        
        Args:
            audio: 音频数据
            reduction_strength: 降噪强度 (0.0-1.0)
            
        Returns:
            处理后的音频
        """
        # 简单的噪声减少策略
        # 1. 计算音频的能量包络
        window_size = 512
        hop_size = 256
        
        # 计算每帧的能量
        energy = []
        for i in range(0, len(audio) - window_size, hop_size):
            frame_energy = np.sum(audio[i:i+window_size] ** 2)
            energy.append(frame_energy)
        
        if not energy:
            return audio
        
        # 计算噪声阈值（基于能量的百分位数）
        noise_threshold = np.percentile(energy, 10)  # 取能量较低的10%作为噪声参考
        
        # 对低能量区域进行抑制
        processed = np.copy(audio)
        
        for i in range(0, len(audio) - window_size, hop_size):
            frame_energy = np.sum(processed[i:i+window_size] ** 2)
            
            if frame_energy < noise_threshold:
                # 降低噪声区域的增益
                gain = max(0, 1 - (noise_threshold - frame_energy) / noise_threshold * reduction_strength)
                processed[i:i+window_size] *= gain
        
        return processed

class ParameterOptimizer:
    """
    参数优化器
    提供基于文本内容和质量评估的参数优化策略
    """
    
    @staticmethod
    def optimize_parameters_based_on_text(text: str, base_params: Dict[str, any]) -> Dict[str, any]:
        """
        根据文本内容优化参数
        
        Args:
            text: 输入文本
            base_params: 基础参数
            
        Returns:
            优化后的参数
        """
        optimized = base_params.copy()
        
        # 分析文本特征
        text_length = len(text)
        
        # 检测标点符号密度
        punctuation_count = sum(1 for c in text if c in "。！？.!?;;:，,）")
        punctuation_density = punctuation_count / max(1, text_length) * 100
        
        # 检测情绪词汇
        emotional_words = [
            "开心", "高兴", "快乐", "兴奋", "激动",
            "伤心", "难过", "悲伤", "痛苦", "绝望",
            "生气", "愤怒", "恼火", "烦躁", "不满",
            "惊讶", "震惊", "意外", "惊喜",
            "感谢", "感激", "感恩", "感动",
            "害怕", "恐惧", "担忧", "担心"
        ]
        
        has_emotional_content = any(word in text for word in emotional_words)
        
        # 根据文本特征调整参数
        if text_length > 1000:
            # 长文本适当降低语速以提高清晰度
            optimized["speed"] = min(optimized["speed"], 0.95)
            logger.debug("检测到长文本，已优化语速")
        
        if punctuation_density > 20:  # 标点密度高，短句多
            # 短句较多时适当提高语速
            optimized["speed"] = min(optimized["speed"] + 0.05, 1.2)
            logger.debug("检测到短句较多，已优化语速")
        
        if has_emotional_content:
            # 情感内容适当提高情绪强度
            optimized["emotion"] = min(optimized["emotion"] + 0.1, 1.0)
            logger.debug("检测到情感词汇，已优化情绪强度")
        
        # 检测特殊内容类型
        if ParameterOptimizer._is_formal_content(text):
            # 正式内容使用冷静风格
            optimized["style"] = 2
            logger.debug("检测到正式内容，已优化风格")
        
        elif ParameterOptimizer._is_cheerful_content(text):
            # 愉快内容使用活泼风格
            optimized["style"] = 4
            logger.debug("检测到愉快内容，已优化风格")
        
        return optimized
    
    @staticmethod
    def _is_formal_content(text: str) -> bool:
        """
        检测是否为正式内容
        """
        formal_patterns = [
            r"尊敬的", r"此致", r"敬礼", r"报告",
            r"通知", r"公告", r"声明", r"制度",
            r"规定", r"条款", r"协议", r"合同",
            r"特此", r"为盼", r"为荷", r"此致"
        ]
        
        return any(re.search(pattern, text) for pattern in formal_patterns)
    
    @staticmethod
    def _is_cheerful_content(text: str) -> bool:
        """
        检测是否为愉快内容
        """
        cheerful_patterns = [
            r"^祝贺", r"恭喜", r"生日快乐", r"节日快乐",
            r"太棒了", r"太好了", r"开心", r"快乐",
            r"惊喜", r"派对", r"庆祝", r"胜利"
        ]
        
        return any(re.search(pattern, text) for pattern in cheerful_patterns)
    
    @staticmethod
    def get_quality_improvement_suggestions(original_params: Dict[str, any]) -> List[Dict[str, any]]:
        """
        根据用户提供的质量提升指南生成参数优化建议
        
        Args:
            original_params: 原始参数
            
        Returns:
            优化建议列表（按优先级排序）
        """
        suggestions = []
        
        # 建议1: 提高情绪强度
        suggested_1 = original_params.copy()
        suggested_1["emotion"] = min(original_params["emotion"] + 0.2, 1.0)
        suggestions.append({
            "params": suggested_1,
            "description": "提高情绪强度",
            "priority": 1
        })
        
        # 建议2: 降低语速
        suggested_2 = original_params.copy()
        suggested_2["speed"] = 0.95
        suggestions.append({
            "params": suggested_2,
            "description": "降低语速到0.95",
            "priority": 2
        })
        
        # 建议3: 改变风格
        if original_params["style"] != 3:
            suggested_3 = original_params.copy()
            suggested_3["style"] = 3  # 使用主风格
            suggestions.append({
                "params": suggested_3,
                "description": "切换到主风格(3)",
                "priority": 3
            })
        
        # 建议4: 同时调整情绪和语速
        suggested_4 = original_params.copy()
        suggested_4["emotion"] = min(original_params["emotion"] + 0.1, 1.0)
        suggested_4["speed"] = 0.95
        suggestions.append({
            "params": suggested_4,
            "description": "同时提高情绪强度和降低语速",
            "priority": 4
        })
        
        return suggestions

class AudioQualityEvaluator:
    """
    音频质量评估器
    提供音频质量的客观评估
    """
    
    @staticmethod
    def calculate_snr(audio: np.ndarray, sample_rate: int = 44100) -> float:
        """
        计算信号噪声比
        
        Args:
            audio: 音频数据
            sample_rate: 采样率
            
        Returns:
            SNR值（分贝）
        """
        # 简单的SNR估计
        # 假设信号是能量较高的部分，噪声是能量较低的部分
        window_size = int(sample_rate * 0.05)  # 50ms窗口
        
        # 计算每帧能量
        energy = []
        for i in range(0, len(audio) - window_size, window_size):
            frame_energy = np.sum(audio[i:i+window_size] ** 2)
            energy.append(frame_energy)
        
        if not energy:
            return 0.0
        
        # 排序能量
        energy_sorted = sorted(energy)
        
        # 取前10%作为噪声能量估计
        noise_frames = int(len(energy_sorted) * 0.1)
        noise_energy = sum(energy_sorted[:noise_frames]) / max(1, noise_frames)
        
        # 取后50%作为信号能量估计
        signal_frames = int(len(energy_sorted) * 0.5)
        signal_energy = sum(energy_sorted[-signal_frames:]) / max(1, signal_frames)
        
        if noise_energy > 0 and signal_energy > 0:
            snr_db = 10 * np.log10(signal_energy / noise_energy)
            return snr_db
        else:
            return 0.0
    
    @staticmethod
    def detect_clipping(audio: np.ndarray, threshold: float = 0.95) -> Dict[str, any]:
        """
        检测削波失真
        
        Args:
            audio: 音频数据
            threshold: 削波阈值
            
        Returns:
            削波检测结果
        """
        clipped_samples = np.abs(audio) >= threshold
        clipped_percentage = np.mean(clipped_samples) * 100
        
        return {
            "has_clipping": clipped_percentage > 0,
            "clipped_percentage": clipped_percentage,
            "severity": "high" if clipped_percentage > 5 else 
                        "medium" if clipped_percentage > 1 else "low"
        }
    
    @staticmethod
    def evaluate_audio_quality(audio: np.ndarray, sample_rate: int = 44100) -> Dict[str, any]:
        """
        全面评估音频质量
        
        Args:
            audio: 音频数据
            sample_rate: 采样率
            
        Returns:
            质量评估结果
        """
        # 基本统计信息
        rms_energy = np.sqrt(np.mean(audio ** 2))
        peak_amplitude = np.max(np.abs(audio))
        
        # 动态范围
        min_amplitude = np.min(np.abs(audio))
        if min_amplitude > 0:
            dynamic_range = 20 * np.log10(peak_amplitude / min_amplitude)
        else:
            dynamic_range = 0
        
        # 计算SNR
        snr = AudioQualityEvaluator.calculate_snr(audio, sample_rate)
        
        # 检测削波
        clipping = AudioQualityEvaluator.detect_clipping(audio)
        
        # 计算质量分数（0-100）
        quality_score = 100
        
        # 根据各项指标扣分
        if rms_energy < 0.1:
            quality_score -= 20  # 音量太低
        elif rms_energy > 0.9:
            quality_score -= 10  # 音量过高
        
        if snr < 10:
            quality_score -= 25  # 信噪比太低
        elif snr < 20:
            quality_score -= 10  # 信噪比一般
        
        if clipping["severity"] == "high":
            quality_score -= 30  # 严重削波
        elif clipping["severity"] == "medium":
            quality_score -= 15  # 中等削波
        elif clipping["severity"] == "low":
            quality_score -= 5  # 轻微削波
        
        # 限制分数范围
        quality_score = max(0, min(100, quality_score))
        
        return {
            "quality_score": quality_score,
            "rms_energy": rms_energy,
            "peak_amplitude": peak_amplitude,
            "dynamic_range": dynamic_range,
            "snr": snr,
            "clipping": clipping,
            "quality_level": AudioQualityEvaluator._get_quality_level(quality_score)
        }
    
    @staticmethod
    def _get_quality_level(score: float) -> str:
        """
        根据分数获取质量等级
        """
        if score >= 90:
            return "excellent"
        elif score >= 80:
            return "good"
        elif score >= 70:
            return "fair"
        elif score >= 60:
            return "poor"
        else:
            return "bad"

class TextOptimizer:
    """
    文本优化器
    提供文本预处理和分段优化
    """
    
    @staticmethod
    def optimize_text_for_tts(text: str) -> Dict[str, any]:
        """
        优化文本以提高TTS质量
        
        Args:
            text: 原始文本
            
        Returns:
            优化结果
        """
        # 规范化标点符号
        optimized = TextOptimizer._normalize_punctuation(text)
        
        # 处理特殊符号
        optimized = TextOptimizer._handle_special_characters(optimized)
        
        # 确保句子完整性
        optimized = TextOptimizer._ensure_sentence_completeness(optimized)
        
        return {
            "optimized_text": optimized,
            "original_length": len(text),
            "optimized_length": len(optimized)
        }
    
    @staticmethod
    def _normalize_punctuation(text: str) -> str:
        """
        规范化标点符号
        """
        # 替换多个连续的标点符号
        text = re.sub(r'(\.\s*){3,}', '...', text)
        text = re.sub(r'(！\s*){2,}', '！', text)
        text = re.sub(r'(？\s*){2,}', '？', text)
        
        # 确保标点符号后有空格或换行
        # 中文标点
        text = re.sub(r'([。！？；：，、])', r'\1 ', text)
        # 英文标点
        text = re.sub(r'([.!?;:])', r'\1 ', text)
        
        # 移除多余的空格
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    @staticmethod
    def _handle_special_characters(text: str) -> str:
        """
        处理特殊符号
        """
        # 替换HTML实体
        html_entities = {
            '&lt;': '<',
            '&gt;': '>',
            '&amp;': '&',
            '&quot;': '"',
            '&#39;': "'"
        }
        
        for entity, char in html_entities.items():
            text = text.replace(entity, char)
        
        # 处理省略号
        text = text.replace('...', '…')
        
        # 移除控制字符
        text = re.sub(r'[\x00-\x1F\x7F]', '', text)
        
        return text
    
    @staticmethod
    def _ensure_sentence_completeness(text: str) -> str:
        """
        确保句子完整性
        """
        # 如果文本不以结束标点结尾，添加句号
        if text and text[-1] not in "。！？.!?":
            text += "。"
        
        return text
    
    @staticmethod
    def smart_split_text(text: str, max_chunk_size: int = 500) -> List[str]:
        """
        智能分段文本
        
        Args:
            text: 原始文本
            max_chunk_size: 最大块大小
            
        Returns:
            文本块列表
        """
        # 首先优化文本
        optimized_result = TextOptimizer.optimize_text_for_tts(text)
        optimized_text = optimized_result["optimized_text"]
        
        # 如果文本较短，直接返回
        if len(optimized_text) <= max_chunk_size:
            return [optimized_text]
        
        chunks = []
        current_chunk = ""
        
        # 查找合适的分割点
        # 优先在段落分隔符处分割
        paragraphs = optimized_text.split('\n')
        
        if len(paragraphs) > 1:
            # 段落分割
            for paragraph in paragraphs:
                if paragraph.strip():
                    if len(current_chunk) + len(paragraph) + 1 <= max_chunk_size:
                        if current_chunk:
                            current_chunk += '\n'
                        current_chunk += paragraph
                    else:
                        if current_chunk:
                            chunks.append(current_chunk)
                        current_chunk = paragraph
        else:
            # 按句子分割
            # 匹配中文和英文句子
            sentence_pattern = r'[^。！？.!?]*[。！？.!?]'
            sentences = re.findall(sentence_pattern, optimized_text)
            
            for sentence in sentences:
                if len(current_chunk) + len(sentence) <= max_chunk_size:
                    current_chunk += sentence
                else:
                    if current_chunk:
                        chunks.append(current_chunk)
                    current_chunk = sentence
        
        # 添加最后一块
        if current_chunk.strip():
            chunks.append(current_chunk)
        
        return chunks

class QualityOptimizationManager:
    """
    质量优化管理器
    协调整个优化流程
    """
    
    def __init__(self):
        """
        初始化质量优化管理器
        """
        self.post_processor = AudioPostProcessor()
        self.param_optimizer = ParameterOptimizer()
        self.evaluator = AudioQualityEvaluator()
        self.text_optimizer = TextOptimizer()
    
    async def optimize_audio_quality(self, audio: np.ndarray, sample_rate: int, 
                                    params: Dict[str, any] = None) -> Tuple[np.ndarray, Dict[str, any]]:
        """
        优化音频质量
        
        Args:
            audio: 音频数据
            sample_rate: 采样率
            params: 优化参数
            
        Returns:
            (优化后的音频, 优化结果信息)
        """
        if params is None:
            params = {}
        
        # 记录优化前的质量
        before_quality = self.evaluator.evaluate_audio_quality(audio, sample_rate)
        
        # 应用基础优化
        optimized_audio = np.copy(audio)
        
        # 1. 移除削波
        optimized_audio = self.post_processor.remove_clipping(optimized_audio)
        
        # 2. 基本噪声消除
        if params.get("enable_noise_reduction", True):
            strength = params.get("noise_reduction_strength", 0.1)
            optimized_audio = self.post_processor.apply_basic_noise_reduction(optimized_audio, strength)
        
        # 3. 应用动态范围压缩
        if params.get("enable_compression", True):
            threshold = params.get("compression_threshold", 0.1)
            ratio = params.get("compression_ratio", 2.0)
            optimized_audio = self.post_processor.apply_dynamic_range_compression(
                optimized_audio, threshold, ratio
            )
        
        # 4. 应用平滑处理
        if params.get("enable_smoothing", True):
            smoothing_ms = params.get("smoothing_ms", 10.0)
            optimized_audio = self.post_processor.apply_smoothing(optimized_audio, sample_rate, smoothing_ms)
        
        # 5. 归一化
        if params.get("enable_normalization", True):
            target_level = params.get("target_level", 0.9)
            optimized_audio = self.post_processor.normalize_audio(optimized_audio, target_level)
        
        # 计算优化后的质量
        after_quality = self.evaluator.evaluate_audio_quality(optimized_audio, sample_rate)
        
        improvement = {
            "quality_score_improvement": after_quality["quality_score"] - before_quality["quality_score"],
            "clipping_reduced": after_quality["clipping"]["clipped_percentage"] < before_quality["clipping"]["clipped_percentage"],
            "snr_improvement": after_quality["snr"] - before_quality["snr"]
        }
        
        return optimized_audio, {
            "before_quality": before_quality,
            "after_quality": after_quality,
            "improvement": improvement,
            "applied_processes": [
                "remove_clipping",
                "noise_reduction" if params.get("enable_noise_reduction", True) else None,
                "dynamic_compression" if params.get("enable_compression", True) else None,
                "smoothing" if params.get("enable_smoothing", True) else None,
                "normalization" if params.get("enable_normalization", True) else None
            ]
        }
    
    async def auto_optimize_tts_params(self, text: str, base_params: Dict[str, any]) -> Dict[str, any]:
        """
        自动优化TTS参数
        
        Args:
            text: 输入文本
            base_params: 基础参数
            
        Returns:
            优化后的参数
        """
        # 根据文本内容优化参数
        optimized_params = self.param_optimizer.optimize_parameters_based_on_text(text, base_params)
        
        # 优化文本
        text_optimization_result = self.text_optimizer.optimize_text_for_tts(text)
        
        # 智能分段建议
        chunks = self.text_optimizer.smart_split_text(text_optimization_result["optimized_text"])
        
        return {
            "optimized_params": optimized_params,
            "optimized_text": text_optimization_result["optimized_text"],
            "recommended_chunks": chunks if len(chunks) > 1 else None,
            "optimization_info": {
                "params_changed": {k: v for k, v in optimized_params.items() if v != base_params.get(k)}
            }
        }
    
    async def get_quality_enhancement_plan(self, text: str, current_params: Dict[str, any]) -> List[Dict[str, any]]:
        """
        获取质量提升计划
        
        Args:
            text: 输入文本
            current_params: 当前参数
            
        Returns:
            质量提升建议列表
        """
        # 基于文本的优化建议
        text_based_optimization = await self.auto_optimize_tts_params(text, current_params)
        
        # 基于参数的优化建议
        param_based_suggestions = self.param_optimizer.get_quality_improvement_suggestions(current_params)
        
        # 结合所有建议
        enhancement_plan = []
        
        # 1. 文本优化建议
        if text_based_optimization["optimization_info"]["params_changed"]:
            enhancement_plan.append({
                "type": "text_based_optimization",
                "params": text_based_optimization["optimized_params"],
                "description": "根据文本内容自动优化参数",
                "priority": 1
            })
        
        # 2. 参数优化建议
        for suggestion in param_based_suggestions:
            enhancement_plan.append({
                "type": "parameter_adjustment",
                "params": suggestion["params"],
                "description": suggestion["description"],
                "priority": suggestion["priority"] + 1
            })
        
        # 3. 文本分段建议
        if text_based_optimization["recommended_chunks"]:
            enhancement_plan.append({
                "type": "text_chunking",
                "chunks": text_based_optimization["recommended_chunks"],
                "description": f"将文本分成 {len(text_based_optimization['recommended_chunks'])} 段以提高质量",
                "priority": 10
            })
        
        return enhancement_plan

# 全局质量优化管理器实例
default_quality_manager = QualityOptimizationManager()

def get_quality_optimizer() -> QualityOptimizationManager:
    """
    获取质量优化管理器实例
    """
    return default_quality_manager

async def optimize_audio(audio: np.ndarray, sample_rate: int, params: Dict[str, any] = None) -> Tuple[np.ndarray, Dict[str, any]]:
    """
    便捷的音频优化函数
    """
    manager = get_quality_optimizer()
    return await manager.optimize_audio_quality(audio, sample_rate, params)

async def optimize_tts_params(text: str, base_params: Dict[str, any]) -> Dict[str, any]:
    """
    便捷的TTS参数优化函数
    """
    manager = get_quality_optimizer()
    return await manager.auto_optimize_tts_params(text, base_params)