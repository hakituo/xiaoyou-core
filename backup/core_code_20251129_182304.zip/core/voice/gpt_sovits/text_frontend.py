# -*- coding: utf-8 -*-
"""
GPT-SoVITS 2 Pro 文本前端处理模块
负责文本规范化、语言检测、分词、音素化等预处理任务
"""

import re
import logging
import jieba
from typing import List, Dict, Tuple, Optional, Union, Any
import numpy as np

logger = logging.getLogger(__name__)


class TextFrontend:
    """
    文本前端处理器
    提供完整的文本预处理功能，包括规范化、分词、音素化等
    """
    
    # 中文字符匹配正则表达式
    CHINESE_CHAR_PATTERN = re.compile(r'[\u4e00-\u9fa5]')
    # 英文字符匹配正则表达式
    ENGLISH_CHAR_PATTERN = re.compile(r'[a-zA-Z]')
    # 数字匹配正则表达式
    NUMBER_PATTERN = re.compile(r'\d+')
    
    # 标点符号优先级（用于停顿预测）
    PUNCTUATION_STOP_DURATION = {
        ',': 0.15,      # 逗号停顿0.15秒
        '，': 0.15,
        '.': 0.35,      # 句号停顿0.35秒
        '。': 0.35,
        '!': 0.35,
        '！': 0.35,
        '?': 0.35,
        '？': 0.35,
        ';': 0.25,
        '；': 0.25,
        ':': 0.20,
        '：': 0.20,
        '\n': 0.50,     # 换行停顿0.5秒
    }
    
    # 中英文混合文本分割模式
    MIXED_TEXT_PATTERN = re.compile(r'([\u4e00-\u9fa5]+|[a-zA-Z0-9\s.,!?;:]+)')
    
    def __init__(self):
        """
        初始化文本前端处理器
        """
        # 初始化jieba分词
        self._init_jieba()
        
        # 数字转中文映射
        self._digits_to_chinese = {
            '0': '零', '1': '一', '2': '二', '3': '三', '4': '四',
            '5': '五', '6': '六', '7': '七', '8': '八', '9': '九'
        }
        
        # 英文音素映射（简化版本，实际应用需要更完整的映射表）
        self._english_phonemes = {
            'a': ['ə'], 'b': ['b'], 'c': ['k', 's'], 'd': ['d'], 'e': ['ɛ'],
            'f': ['f'], 'g': ['ɡ'], 'h': ['h'], 'i': ['ɪ'], 'j': ['dʒ'],
            'k': ['k'], 'l': ['l'], 'm': ['m'], 'n': ['n'], 'o': ['o'],
            'p': ['p'], 'q': ['k', 'ju'], 'r': ['r'], 's': ['s'], 't': ['t'],
            'u': ['ju'], 'v': ['v'], 'w': ['w'], 'x': ['ks'], 'y': ['j'], 'z': ['z']
        }
    
    def _init_jieba(self):
        """
        初始化jieba分词器
        """
        try:
            # 可以在这里添加自定义词典
            # jieba.load_userdict('custom_dict.txt')
            pass
        except Exception as e:
            logger.error(f"初始化jieba分词器失败: {str(e)}")
    
    def normalize_text(self, text: str) -> str:
        """
        规范化文本，处理特殊字符和格式
        
        Args:
            text: 原始文本
            
        Returns:
            规范化后的文本
        """
        # 去除多余空格
        text = re.sub(r'\s+', ' ', text)
        
        # 去除首尾空格
        text = text.strip()
        
        # 替换全角空格为半角空格
        text = text.replace('　', ' ')
        
        # 处理全角标点转半角
        text = self._convert_fullwidth_to_halfwidth(text)
        
        return text
    
    def _convert_fullwidth_to_halfwidth(self, text: str) -> str:
        """
        全角转半角
        
        Args:
            text: 包含全角字符的文本
            
        Returns:
            转换后的半角文本
        """
        result = []
        for char in text:
            code = ord(char)
            if code >= 0xFF01 and code <= 0xFF5E:
                # 全角字符转半角
                code -= 0xFEE0
            result.append(chr(code))
        return ''.join(result)
    
    def detect_language(self, text: str) -> str:
        """
        检测文本语言
        
        Args:
            text: 要检测的文本
            
        Returns:
            语言代码，如'zh'（中文）、'en'（英文）、'mix'（混合）
        """
        has_chinese = bool(self.CHINESE_CHAR_PATTERN.search(text))
        has_english = bool(self.ENGLISH_CHAR_PATTERN.search(text))
        
        if has_chinese and not has_english:
            return 'zh'
        elif has_english and not has_chinese:
            return 'en'
        else:
            return 'mix'
    
    def split_text_by_language(self, text: str) -> List[Tuple[str, str]]:
        """
        按语言分割文本
        
        Args:
            text: 混合语言文本
            
        Returns:
            分割后的文本段列表，每个元素为(文本段, 语言代码)
        """
        segments = []
        matches = self.MIXED_TEXT_PATTERN.findall(text)
        
        for match in matches:
            if match.strip():
                lang = self.detect_language(match)
                segments.append((match, lang))
        
        return segments
    
    def split_text_by_length(self, text: str, max_length: int = 50) -> List[str]:
        """
        按长度分割文本
        
        Args:
            text: 要分割的文本
            max_length: 最大段落长度
            
        Returns:
            分割后的文本段列表
        """
        if len(text) <= max_length:
            return [text]
        
        segments = []
        start = 0
        
        while start < len(text):
            end = min(start + max_length, len(text))
            
            # 如果不是文本末尾，尝试在合适的标点符号处分割
            if end < len(text):
                # 从max_length位置向前查找合适的标点符号
                for i in range(end, start, -1):
                    if text[i-1] in self.PUNCTUATION_STOP_DURATION:
                        end = i
                        break
            
            segments.append(text[start:end])
            start = end
        
        return segments
    
    def chinese_to_phonemes(self, text: str) -> List[str]:
        """
        中文文本转音素
        注意：这是一个简化版本，实际应用需要更复杂的映射
        
        Args:
            text: 中文文本
            
        Returns:
            音素列表
        """
        # 分词
        words = list(jieba.cut(text))
        
        # 这里使用字符作为基本单位（简化版）
        # 实际应用中应该使用拼音到音素的映射
        phonemes = []
        for word in words:
            for char in word:
                if self.CHINESE_CHAR_PATTERN.match(char):
                    phonemes.append(char)  # 简化处理，实际应该转换为对应的音素
                elif char in self.PUNCTUATION_STOP_DURATION:
                    phonemes.append(char)
        
        return phonemes
    
    def english_to_phonemes(self, text: str) -> List[str]:
        """
        英文文本转音素
        
        Args:
            text: 英文文本
            
        Returns:
            音素列表
        """
        phonemes = []
        
        # 转换为小写
        text = text.lower()
        
        # 处理每个字符
        for char in text:
            if char.isalpha():
                if char in self._english_phonemes:
                    phonemes.extend(self._english_phonemes[char])
            elif char in self.PUNCTUATION_STOP_DURATION:
                phonemes.append(char)
        
        return phonemes
    
    def text_to_phonemes(self, text: str, language: Optional[str] = None) -> List[str]:
        """
        文本转音素
        
        Args:
            text: 输入文本
            language: 语言代码，如果不指定则自动检测
            
        Returns:
            音素列表
        """
        # 规范化文本
        normalized_text = self.normalize_text(text)
        
        # 检测语言
        if language is None:
            language = self.detect_language(normalized_text)
        
        phonemes = []
        
        if language == 'zh':
            # 中文处理
            phonemes = self.chinese_to_phonemes(normalized_text)
        elif language == 'en':
            # 英文处理
            phonemes = self.english_to_phonemes(normalized_text)
        else:
            # 混合语言处理
            segments = self.split_text_by_language(normalized_text)
            for segment, seg_lang in segments:
                if seg_lang == 'zh':
                    phonemes.extend(self.chinese_to_phonemes(segment))
                elif seg_lang == 'en':
                    phonemes.extend(self.english_to_phonemes(segment))
        
        return phonemes
    
    def predict_pauses(self, text: str) -> List[Tuple[str, float]]:
        """
        预测文本中的停顿位置和时长
        
        Args:
            text: 输入文本
            
        Returns:
            标记列表，每个元素为(文本片段, 停顿时长)
        """
        result = []
        current_text = ""
        
        for char in text:
            if char in self.PUNCTUATION_STOP_DURATION:
                if current_text:
                    result.append((current_text, 0.0))
                    current_text = ""
                # 停顿标记
                result.append((char, self.PUNCTUATION_STOP_DURATION[char]))
            else:
                current_text += char
        
        # 处理最后一段文本
        if current_text:
            result.append((current_text, 0.0))
        
        return result
    
    def number_to_chinese(self, text: str) -> str:
        """
        将文本中的数字转换为中文数字
        
        Args:
            text: 包含数字的文本
            
        Returns:
            转换后的文本
        """
        def replace_digit(match):
            number_str = match.group(0)
            result = ""
            for digit in number_str:
                result += self._digits_to_chinese.get(digit, digit)
            return result
        
        # 替换文本中的所有数字
        return re.sub(self.NUMBER_PATTERN, replace_digit, text)
    
    def preprocess(self, text: str, language: Optional[str] = None, convert_numbers: bool = False) -> Dict[str, Any]:
        """
        完整的文本预处理流程
        
        Args:
            text: 原始文本
            language: 语言代码，如果不指定则自动检测
            convert_numbers: 是否将数字转换为中文数字
            
        Returns:
            预处理结果字典，包含规范化文本、音素、停顿信息等
        """
        # 规范化文本
        normalized_text = self.normalize_text(text)
        
        # 检测语言
        if language is None:
            language = self.detect_language(normalized_text)
        
        # 数字转换
        if convert_numbers and language == 'zh':
            normalized_text = self.number_to_chinese(normalized_text)
        
        # 文本分段
        segments = self.split_text_by_length(normalized_text)
        
        # 音素转换
        phonemes = []
        for segment in segments:
            segment_phonemes = self.text_to_phonemes(segment, language)
            phonemes.extend(segment_phonemes)
        
        # 停顿预测
        pauses = self.predict_pauses(normalized_text)
        
        return {
            'original_text': text,
            'normalized_text': normalized_text,
            'language': language,
            'segments': segments,
            'phonemes': phonemes,
            'pauses': pauses
        }


# 创建全局实例
_text_frontend_instance = None

def get_text_frontend() -> TextFrontend:
    """
    获取文本前端处理器的全局实例
    
    Returns:
        TextFrontend实例
    """
    global _text_frontend_instance
    if _text_frontend_instance is None:
        _text_frontend_instance = TextFrontend()
    return _text_frontend_instance


def preprocess_text(text: str, **kwargs) -> Dict[str, Any]:
    """
    预处理文本的便捷函数
    
    Args:
        text: 输入文本
        **kwargs: 传递给preprocess方法的参数
        
    Returns:
        预处理结果
    """
    frontend = get_text_frontend()
    return frontend.preprocess(text, **kwargs)