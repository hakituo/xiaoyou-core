import os
import torch
import numpy as np
import logging
from typing import Dict, List, Optional, Union
from dataclasses import dataclass
import time
import gc

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("GPTSoVITS-SoVITSVocoder")

@dataclass
class VocoderConfig:
    """SoVITS声码器配置类"""
    model_path: str = ""
    config_path: str = ""
    device: str = "auto"
    precision: str = "auto"  # auto, fp16, fp32
    sample_rate: int = 44100
    hop_length: int = 512
    block_size: int = 512
    max_batch_size: int = 4
    use_half: bool = True

class SoVITSVocoder:
    """
    SoVITS声码器封装类
    负责将潜在表示(latent)转换为音频波形
    """
    
    def __init__(self, config: VocoderConfig):
        """
        初始化SoVITS声码器
        
        Args:
            config: 声码器配置
        """
        self.config = config
        self.model = None
        self.device = self._setup_device()
        self.use_half = self._setup_precision()
        self.model_path = config.model_path
        self.is_loaded = False
        self.load_time = 0
        self.inference_times = []
        
    def _setup_device(self) -> str:
        """
        设置运行设备，支持自动检测GPU/CPU
        
        Returns:
            设备名称 (cuda/cpu)
        """
        if self.config.device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
            logger.info(f"自动检测设备: {device}")
            return device
        return self.config.device
    
    def _setup_precision(self) -> bool:
        """
        设置精度模式
        
        Returns:
            是否使用半精度
        """
        if self.config.precision == "auto":
            # 在CPU上不使用半精度，GPU上默认使用半精度
            use_half = self.device == "cuda" and torch.cuda.is_available()
            logger.info(f"自动设置精度: {'半精度(fp16)' if use_half else '单精度(fp32)'}")
            return use_half
        elif self.config.precision == "fp16":
            if self.device == "cpu":
                logger.warning("CPU不支持半精度，将使用单精度")
                return False
            return True
        return False
    
    def load_model(self) -> bool:
        """
        加载SoVITS声码器模型
        
        Returns:
            是否加载成功
        """
        try:
            start_time = time.time()
            
            # 验证模型路径
            if not os.path.exists(self.model_path):
                logger.error(f"模型文件不存在: {self.model_path}")
                return False
            
            # 尝试加载模型（这里是示例，实际加载逻辑需要根据具体模型结构调整）
            logger.info(f"开始加载SoVITS声码器模型: {self.model_path}")
            
            # 这里模拟模型加载，实际项目中需要根据具体模型格式调整
            # 例如：
            # checkpoint = torch.load(self.model_path, map_location=self.device)
            # self.model = YourSoVITSModel()
            # self.model.load_state_dict(checkpoint['model'])
            
            # 模拟模型创建
            self.model = torch.nn.Linear(256, 1024)  # 占位模型
            
            # 移动到指定设备
            self.model.to(self.device)
            
            # 设置精度
            if self.use_half:
                self.model.half()
            
            # 设置为评估模式
            self.model.eval()
            
            self.load_time = time.time() - start_time
            self.is_loaded = True
            logger.info(f"SoVITS声码器模型加载完成，耗时: {self.load_time:.2f}秒")
            return True
            
        except Exception as e:
            logger.error(f"加载SoVITS声码器模型失败: {str(e)}")
            self.is_loaded = False
            return False
    
    def infer(self, latent: torch.Tensor, speaker_embedding: Optional[torch.Tensor] = None, 
              speed: float = 1.0, pitch: float = 1.0) -> np.ndarray:
        """
        单段音频推理
        
        Args:
            latent: 潜在表示，形状为 [T, D]
            speaker_embedding: 说话人嵌入，可选
            speed: 语速调整因子
            pitch: 音高调整因子
            
        Returns:
            生成的音频波形，形状为 [T_wav]
        """
        if not self.is_loaded:
            raise RuntimeError("SoVITS声码器模型未加载")
        
        start_time = time.time()
        
        try:
            # 准备输入数据
            if not isinstance(latent, torch.Tensor):
                latent = torch.tensor(latent, dtype=torch.float32, device=self.device)
            
            # 如果是单精度模型但输入是半精度，转换为单精度
            if not self.use_half and latent.dtype == torch.float16:
                latent = latent.float()
            # 如果是半精度模型但输入是单精度，转换为半精度
            elif self.use_half and latent.dtype == torch.float32:
                latent = latent.half()
            
            # 处理说话人嵌入
            if speaker_embedding is not None:
                if not isinstance(speaker_embedding, torch.Tensor):
                    speaker_embedding = torch.tensor(speaker_embedding, dtype=torch.float32, device=self.device)
                if self.use_half:
                    speaker_embedding = speaker_embedding.half()
            
            # 执行推理（这里是示例，实际推理逻辑需要根据具体模型调整）
            with torch.no_grad():
                # 模拟推理，实际应该是：
                # audio = self.model.infer(latent, speaker_embedding)
                
                # 占位代码，生成随机音频
                seq_len = latent.shape[0] * self.config.hop_length
                audio = np.random.randn(seq_len).astype(np.float32)
            sr = int(self.config.sample_rate)
            try:
                if pitch and abs(pitch - 1.0) > 1e-3:
                    try:
                        import scipy.signal as signal
                        up = max(1, int(round(pitch * 100)))
                        down = 100
                        pitched = signal.resample_poly(audio, up, down)
                    except Exception:
                        x_old = np.arange(audio.shape[0], dtype=np.float32)
                        x_new = np.linspace(0, audio.shape[0] - 1, max(1, int(audio.shape[0] / max(pitch, 1e-6))), dtype=np.float32)
                        pitched = np.interp(x_new, x_old, audio).astype(np.float32)
                    x_old = np.arange(pitched.shape[0], dtype=np.float32)
                    x_new = np.linspace(0, pitched.shape[0] - 1, audio.shape[0], dtype=np.float32)
                    audio = np.interp(x_new, x_old, pitched).astype(np.float32)
                if speed and abs(speed - 1.0) > 1e-3:
                    try:
                        import scipy.signal as signal
                        target_len = max(1, int(audio.shape[0] / max(speed, 1e-6)))
                        audio = signal.resample(audio, target_len).astype(np.float32)
                    except Exception:
                        x_old = np.arange(audio.shape[0], dtype=np.float32)
                        target_len = max(1, int(audio.shape[0] / max(speed, 1e-6)))
                        x_new = np.linspace(0, audio.shape[0] - 1, target_len, dtype=np.float32)
                        audio = np.interp(x_new, x_old, audio).astype(np.float32)
            except Exception:
                pass
            
            # 记录推理时间
            infer_time = time.time() - start_time
            self.inference_times.append(infer_time)
            
            # 保留最近100次推理时间
            if len(self.inference_times) > 100:
                self.inference_times.pop(0)
            
            return audio
            
        except Exception as e:
            logger.error(f"SoVITS声码器推理失败: {str(e)}")
            # 清理CUDA缓存
            self._clean_cache()
            raise
    
    def batch_infer(self, latents: List[torch.Tensor], 
                    speaker_embeddings: Optional[List[torch.Tensor]] = None,
                    speeds: Optional[List[float]] = None,
                    pitches: Optional[List[float]] = None) -> List[np.ndarray]:
        """
        批量音频推理
        
        Args:
            latents: 潜在表示列表
            speaker_embeddings: 说话人嵌入列表
            speeds: 语速调整因子列表
            pitches: 音高调整因子列表
            
        Returns:
            生成的音频波形列表
        """
        if not self.is_loaded:
            raise RuntimeError("SoVITS声码器模型未加载")
        
        # 参数验证和默认值设置
        batch_size = len(latents)
        if speaker_embeddings is None:
            speaker_embeddings = [None] * batch_size
        if speeds is None:
            speeds = [1.0] * batch_size
        if pitches is None:
            pitches = [1.0] * batch_size
        
        # 检查参数长度一致性
        assert len(speaker_embeddings) == batch_size
        assert len(speeds) == batch_size
        assert len(pitches) == batch_size
        
        # 控制批处理大小
        if batch_size > self.config.max_batch_size:
            logger.warning(f"批处理大小 {batch_size} 超过最大限制 {self.config.max_batch_size}，将分批次处理")
            results = []
            for i in range(0, batch_size, self.config.max_batch_size):
                batch_slice = slice(i, min(i + self.config.max_batch_size, batch_size))
                batch_results = self.batch_infer(
                    latents[batch_slice],
                    speaker_embeddings[batch_slice] if speaker_embeddings else None,
                    speeds[batch_slice] if speeds else None,
                    pitches[batch_slice] if pitches else None
                )
                results.extend(batch_results)
            return results
        
        # 这里是简化的批量处理实现，实际项目中应该使用真正的批量推理逻辑
        results = []
        for i in range(batch_size):
            audio = self.infer(latents[i], speaker_embeddings[i], speeds[i], pitches[i])
            results.append(audio)
        
        return results
    
    def streaming_infer(self, latent_stream: List[torch.Tensor], 
                        speaker_embedding: Optional[torch.Tensor] = None,
                        speed: float = 1.0,
                        pitch: float = 1.0) -> List[np.ndarray]:
        """
        流式音频推理
        
        Args:
            latent_stream: 潜在表示流（分块的潜在表示）
            speaker_embedding: 说话人嵌入
            speed: 语速调整因子
            pitch: 音高调整因子
            
        Returns:
            生成的音频波形块列表
        """
        if not self.is_loaded:
            raise RuntimeError("SoVITS声码器模型未加载")
        
        results = []
        
        # 处理每个潜在表示块
        for latent_chunk in latent_stream:
            audio_chunk = self.infer(latent_chunk, speaker_embedding, speed, pitch)
            results.append(audio_chunk)
            
            # 释放当前块的内存
            torch.cuda.empty_cache() if self.device == "cuda" else gc.collect()
        
        return results
    
    def get_performance_stats(self) -> Dict[str, float]:
        """
        获取性能统计信息
        
        Returns:
            包含加载时间、平均推理时间等性能指标的字典
        """
        stats = {
            "load_time": self.load_time,
            "device": self.device,
            "precision": "fp16" if self.use_half else "fp32",
        }
        
        if self.inference_times:
            stats["avg_infer_time"] = sum(self.inference_times) / len(self.inference_times)
            stats["max_infer_time"] = max(self.inference_times)
            stats["min_infer_time"] = min(self.inference_times)
        
        return stats
    
    def update_device(self, device: str) -> bool:
        """
        更新运行设备
        
        Args:
            device: 新设备名称
            
        Returns:
            是否更新成功
        """
        try:
            if device not in ["cuda", "cpu"]:
                raise ValueError(f"不支持的设备: {device}")
            
            if device == "cuda" and not torch.cuda.is_available():
                raise RuntimeError("CUDA不可用")
            
            if self.device == device:
                logger.info(f"设备已为 {device}，无需更新")
                return True
            
            # 清理旧设备资源
            self._clean_cache()
            
            # 更新设备
            self.device = device
            if self.model:
                self.model.to(self.device)
            
            # 更新精度设置
            self.use_half = self._setup_precision()
            if self.model and self.use_half:
                self.model.half()
            elif self.model and not self.use_half:
                self.model.float()
            
            logger.info(f"设备已更新为: {device}")
            return True
            
        except Exception as e:
            logger.error(f"更新设备失败: {str(e)}")
            return False
    
    def _clean_cache(self):
        """
        清理模型缓存和CUDA内存
        """
        try:
            if self.device == "cuda":
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
            # 清理Python垃圾回收
            gc.collect()
        except Exception as e:
            logger.error(f"清理缓存失败: {str(e)}")
    
    def release(self):
        """
        释放模型资源
        """
        try:
            if self.model:
                # 移至CPU并清空
                self.model.cpu()
                del self.model
                self.model = None
            
            # 清理缓存
            self._clean_cache()
            
            self.is_loaded = False
            logger.info("SoVITS声码器资源已释放")
        except Exception as e:
            logger.error(f"释放模型资源失败: {str(e)}")

class SoVITSVocoderManager:
    """
    SoVITS声码器管理器
    用于管理多个声码器实例，支持模型热切换
    """
    
    def __init__(self):
        """初始化声码器管理器"""
        self.vocoders: Dict[str, SoVITSVocoder] = {}
        self.default_vocoder: Optional[str] = None
        logger.info("SoVITS声码器管理器已初始化")
    
    def register_vocoder(self, name: str, config: VocoderConfig) -> bool:
        """
        注册新的声码器实例
        
        Args:
            name: 声码器名称
            config: 声码器配置
            
        Returns:
            是否注册成功
        """
        try:
            # 如果已存在同名声码器，先释放
            if name in self.vocoders:
                self.unregister_vocoder(name)
            
            # 创建并加载声码器
            vocoder = SoVITSVocoder(config)
            if vocoder.load_model():
                self.vocoders[name] = vocoder
                
                # 如果是第一个注册的声码器，设为默认
                if self.default_vocoder is None:
                    self.default_vocoder = name
                    logger.info(f"已将声码器 '{name}' 设为默认")
                
                logger.info(f"声码器 '{name}' 注册成功")
                return True
            else:
                return False
                
        except Exception as e:
            logger.error(f"注册声码器 '{name}' 失败: {str(e)}")
            return False
    
    def unregister_vocoder(self, name: str) -> bool:
        """
        注销声码器实例
        
        Args:
            name: 声码器名称
            
        Returns:
            是否注销成功
        """
        try:
            if name in self.vocoders:
                # 释放资源
                self.vocoders[name].release()
                del self.vocoders[name]
                
                # 如果注销的是默认声码器，设置新的默认声码器
                if name == self.default_vocoder:
                    self.default_vocoder = next(iter(self.vocoders.keys()), None)
                    if self.default_vocoder:
                        logger.info(f"已将声码器 '{self.default_vocoder}' 设为默认")
                
                logger.info(f"声码器 '{name}' 注销成功")
                return True
            else:
                logger.warning(f"声码器 '{name}' 不存在")
                return False
                
        except Exception as e:
            logger.error(f"注销声码器 '{name}' 失败: {str(e)}")
            return False
    
    def get_vocoder(self, name: Optional[str] = None) -> Optional[SoVITSVocoder]:
        """
        获取声码器实例
        
        Args:
            name: 声码器名称，None表示获取默认声码器
            
        Returns:
            声码器实例或None
        """
        target_name = name or self.default_vocoder
        
        if target_name is None:
            logger.warning("没有可用的声码器")
            return None
        
        if target_name not in self.vocoders:
            logger.warning(f"声码器 '{target_name}' 不存在")
            return None
        
        return self.vocoders[target_name]
    
    def list_vocoders(self) -> List[Dict[str, str]]:
        """
        列出所有注册的声码器
        
        Returns:
            声码器信息列表
        """
        result = []
        for name, vocoder in self.vocoders.items():
            info = {
                "name": name,
                "device": vocoder.device,
                "precision": "fp16" if vocoder.use_half else "fp32",
                "is_default": name == self.default_vocoder,
                "is_loaded": vocoder.is_loaded
            }
            result.append(info)
        return result
    
    def set_default_vocoder(self, name: str) -> bool:
        """
        设置默认声码器
        
        Args:
            name: 声码器名称
            
        Returns:
            是否设置成功
        """
        if name not in self.vocoders:
            logger.warning(f"声码器 '{name}' 不存在")
            return False
        
        self.default_vocoder = name
        logger.info(f"默认声码器已设置为: {name}")
        return True
    
    def update_vocoder_device(self, name: Optional[str], device: str) -> bool:
        """
        更新声码器设备
        
        Args:
            name: 声码器名称，None表示更新默认声码器
            device: 新设备名称
            
        Returns:
            是否更新成功
        """
        vocoder = self.get_vocoder(name)
        if vocoder:
            return vocoder.update_device(device)
        return False
    
    def release_all(self):
        """
        释放所有声码器资源
        """
        for name in list(self.vocoders.keys()):
            self.unregister_vocoder(name)
        self.default_vocoder = None
        logger.info("所有声码器资源已释放")

# 全局声码器管理器实例
_vocoder_manager = None

def get_vocoder_manager() -> SoVITSVocoderManager:
    """
    获取全局声码器管理器实例
    
    Returns:
        声码器管理器实例
    """
    global _vocoder_manager
    if _vocoder_manager is None:
        _vocoder_manager = SoVITSVocoderManager()
    return _vocoder_manager
