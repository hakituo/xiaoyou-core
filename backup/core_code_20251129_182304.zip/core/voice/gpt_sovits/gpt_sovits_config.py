# -*- coding: utf-8 -*-
"""
GPT-SoVITS 2Pro 配置类
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional

from ..base.config_base import TTSConfigBase


@dataclass
class GPTSoVITSConfig(TTSConfigBase):
    """
    GPT-SoVITS 2Pro 特定配置类
    """
    # GPT-SoVITS模型配置
    gpt_model_path: Optional[str] = None  # GPT模型路径
    sovits_model_path: Optional[str] = None  # SoVITS模型路径
    speaker_encoder_path: Optional[str] = None  # 说话人编码器路径
    
    # 模型参数
    text_language: str = "auto"  # 文本语言
    speaker_id: Optional[str] = None  # 默认说话人ID
    
    # 推理参数
    temperature: float = 0.3  # 采样温度
    top_p: float = 0.7  # Top-p采样参数
    top_k: int = 50  # Top-k采样参数
    
    # 微调参数
    prompt_text: Optional[str] = None  # 提示文本
    prompt_audio_path: Optional[str] = None  # 提示音频路径
    
    # 语音克隆参数
    cloning_reference_path: Optional[str] = None  # 克隆参考音频路径
    cloning_embedding_path: Optional[str] = None  # 预计算的嵌入路径
    
    # 风格参数
    style_weight: float = 1.0  # 风格权重
    
    # 缓存配置
    use_audio_cache: bool = True  # 是否使用音频缓存
    cache_dir: Optional[str] = None  # 缓存目录
    
    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典
        
        Returns:
            配置字典
        """
        base_dict = super().to_dict()
        base_dict.update({
            "gpt_model_path": self.gpt_model_path,
            "sovits_model_path": self.sovits_model_path,
            "speaker_encoder_path": self.speaker_encoder_path,
            "text_language": self.text_language,
            "speaker_id": self.speaker_id,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "top_k": self.top_k,
            "prompt_text": self.prompt_text,
            "prompt_audio_path": self.prompt_audio_path,
            "cloning_reference_path": self.cloning_reference_path,
            "cloning_embedding_path": self.cloning_embedding_path,
            "style_weight": self.style_weight,
            "use_audio_cache": self.use_audio_cache,
            "cache_dir": self.cache_dir,
        })
        return base_dict
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "GPTSoVITSConfig":
        """
        从字典创建配置对象
        
        Args:
            config_dict: 配置字典
            
        Returns:
            配置对象
        """
        base_config_dict = {k: v for k, v in config_dict.items() 
                          if k in TTSConfigBase.__dataclass_fields__.keys()}
        return cls(**base_config_dict, **config_dict)