# GPT-SoVITS 性能优化指南

本文档详细介绍了GPT-SoVITS引擎的性能优化功能、配置参数及使用方法，帮助开发者充分利用优化特性提高TTS系统性能。

## 1. 性能优化功能概述

### 1.1 主要优化特性

- **批处理推理**：通过并行处理文本段提高吞吐量
- **混合精度计算**：降低内存占用并加速推理
- **智能缓存机制**：多级缓存策略减少重复计算
- **长文本分块处理**：自动分割和处理长文本，保证稳定性
- **内存优化管理**：实时内存监控和自动优化，防止OOM错误
- **多线程执行器**：异步处理提高并发性能
- **性能统计功能**：完整的性能指标收集和分析
- **设备自适应优化**：根据不同设备类型自动调整优化策略

## 2. 性能配置参数

### 2.1 初始化参数

```python
engine = GPTSoVITSEngine(
    config_path='path/to/config',
    model_path='path/to/model',
    device='cuda' if torch.cuda.is_available() else 'cpu',
    # 性能优化相关参数
    performance_level='high',  # 性能级别: 'low', 'medium', 'high'
    mixed_precision=True,      # 是否启用混合精度计算
    batch_size=4,              # 批处理大小
    max_workers=4              # 最大工作线程数
)
```

### 2.2 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| performance_level | str | 'medium' | 性能优化级别，影响批处理大小和内存使用策略 |
| mixed_precision | bool | True | 是否启用混合精度计算，可显著降低显存占用 |
| batch_size | int | 4 | 批处理大小，控制一次处理的文本段数量 |
| max_workers | int | 4 | 最大工作线程数，影响并发处理能力 |

## 3. 性能级别的影响

### 3.1 性能级别对照表

| 级别 | 适用场景 | 内存占用 | 计算速度 | 批处理大小 |
|------|----------|----------|----------|------------|
| low | 资源受限设备，如低显存GPU或CPU | 低 | 较慢 | 1-2 |
| medium | 普通桌面GPU，平衡性能和资源 | 中等 | 中等 | 4-8 |
| high | 高性能GPU，追求最大吞吐量 | 高 | 最快 | 8-16 |

### 3.2 自动优化

引擎会根据`performance_level`和检测到的设备类型自动进行以下优化：

- 启用/禁用CUDA Benchmark以提高GPU性能
- 调整批处理大小和线程池配置
- 优化内存分配和释放策略
- 启用/禁用特定的优化技术

## 4. 批处理功能使用

### 4.1 自动批处理模式

引擎会自动处理文本的分段和批处理，用户无需手动操作：

```python
# 自动批处理模式 - 长文本会自动分段并批处理
audio, sr = await engine.synthesize(
    text="这是一个很长的文本，引擎会自动分段并使用批处理进行处理...",
    ref_wav_path="path/to/reference.wav"
)
```

### 4.2 手动控制批处理

通过调整初始化参数可以手动控制批处理行为：

```python
# 手动控制批处理大小
engine = GPTSoVITSEngine(
    # 其他参数...
    batch_size=8,  # 增加批处理大小以提高吞吐量
    performance_level='high'
)
```

## 5. 缓存机制详解

### 5.1 多级缓存策略

引擎实现了三级缓存：

1. **参考音频特征缓存**：缓存提取的参考音频特征
2. **文本特征缓存**：缓存文本处理结果
3. **完整结果缓存**：缓存最终的TTS生成结果

### 5.2 缓存控制

缓存会自动管理和定期清理，避免内存泄漏：

```python
# 查看当前缓存统计
stats = engine.get_performance_stats()
print(f"缓存命中率: {stats['cache_hit_rate']:.2f}%")
```

## 6. 长文本处理

### 6.1 自动分块处理

对于长文本，引擎会自动进行分块处理：

- 根据语言类型自动确定合适的分段大小
- 中文文本会根据标点符号智能分段
- 英文文本会根据单词边界分段
- 处理完成后自动拼接成完整音频

### 6.2 内存优化

处理长文本时，引擎会：

- 动态调整批处理大小，避免内存溢出
- 及时释放中间结果，减少内存占用
- 对超长文本进行分阶段处理

## 7. 性能统计和监控

### 7.1 获取性能统计

使用`get_performance_stats()`方法获取详细的性能指标：

```python
stats = engine.get_performance_stats()
print(f"平均请求处理时间: {stats['avg_processing_time']:.2f}秒")
print(f"缓存命中率: {stats['cache_hit_rate']:.2f}%")
print(f"总请求数: {stats['total_requests']}")
```

### 7.2 性能日志

引擎会记录详细的性能日志，包括：

- 请求处理时间
- 音频生成长度
- 批处理效率
- 内存使用情况

## 8. 兼容性和故障排除

### 8.1 兼容性检查

引擎内置了兼容性检查机制，可以识别潜在的兼容性问题：

```python
# 自动检测兼容性问题
compatibility_issues = engine._check_compatibility()
if compatibility_issues:
    print(f"发现兼容性问题: {compatibility_issues}")
```

### 8.2 常见问题及解决方案

1. **内存溢出 (OOM)**
   - 降低`batch_size`和`performance_level`
   - 确保启用`mixed_precision`
   - 对超长文本进行预分段

2. **批处理性能不佳**
   - 调整`batch_size`以匹配GPU显存
   - 增加`max_workers`以提高并发能力
   - 使用`performance_level='high'`

3. **缓存命中率低**
   - 确保处理相似的文本和参考音频
   - 检查缓存键生成逻辑

## 9. 最佳实践

### 9.1 CPU环境优化

在CPU环境下：

- 使用`performance_level='low'`
- 设置较小的`batch_size` (1-2)
- 增加`max_workers`以利用多核优势
- 禁用`mixed_precision`

### 9.2 GPU环境优化

在GPU环境下：

- 使用`performance_level='high'`或`'medium'`
- 根据GPU显存调整`batch_size`
- 启用`mixed_precision`以降低显存占用
- 合理设置`max_workers`避免线程过多

### 9.3 大规模部署建议

大规模部署时：

- 实现请求队列和负载均衡
- 定期监控性能指标和内存使用
- 为不同类型的请求设置不同的处理策略
- 考虑使用模型量化进一步降低资源占用

## 10. 总结

本指南介绍了GPT-SoVITS引擎的全面性能优化功能。通过合理配置这些参数，开发者可以显著提高TTS系统的性能和资源利用率，同时保持生成语音的质量。

对于具体应用场景，建议进行适当的性能测试和调优，以找到最佳的配置组合。