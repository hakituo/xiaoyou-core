# GPT-SoVITS 语音合成集成

本目录提供了 GPT-SoVITS 语音合成模型的集成方案，使您能够轻松地在项目中使用高质量的语音合成功能。

## 目录结构

```
core/voice/gpt_sovits/
├── integration.py   # 主要集成模块，提供简单易用的 API
├── test_integration.py  # 测试脚本，验证集成功能
├── README.md        # 本使用说明文档
├── infer.py         # 核心推理引擎（已存在）
├── api.py           # FastAPI 服务接口（已存在）
└── path_config.py   # 路径配置文件（自动生成）
```

## 安装与准备

### 1. 前提条件

- Python 3.8+
- PyTorch 2.0+
- CUDA 11.7+（推荐，用于 GPU 加速）
- 其他必要依赖

### 2. 安装依赖

```bash
# 安装基础依赖
pip install numpy soundfile torch torchaudio

# 安装其他必要依赖
pip install -r requirements.txt
```

### 3. 下载预训练模型

已通过 `download_gpt_sovits_model.py` 脚本下载了必要的预训练模型。模型文件位于：

```
models/tts/GPT-SoVITS-v2pro-20250604/GPT_SOVITS/pretrained_models/
```

包含以下文件：
- `s2Gv2Pro.pth` - GPT 模型
- `s2Dv2Pro.pth` - SoVITS 声码器模型
- `s2Gv2ProPlus.pth` - 增强版 GPT 模型
- `s2Dv2ProPlus.pth` - 增强版 SoVITS 模型
- `pretrained_eres2netv2w24s4ep4.ckpt` - 说话人编码器
- `G2PWModel.zip` - 中文分词模型（已解压）

### 4. 配置 Python 路径

运行以下命令配置 Python 路径：

```bash
python setup_gpt_sovits_path.py
```

这将：
- 自动查找 GPT-SoVITS 根目录
- 配置 Python 路径
- 验证模块导入
- 创建路径配置文件

路径配置文件 `path_config.py` 包含以下核心功能：

1. **智能路径检测**: 自动查找并验证所有必要的模型路径
2. **动态模块导入机制**: 实现了多种导入策略确保 GPT_SOVITS 模块可正确导入
3. **路径常量定义**: 提供各种模型和资源路径的常量引用
4. **子模块导入辅助函数**: 方便导入 text、utils 等子模块

### 5. 验证配置

配置完成后，可以运行测试脚本来验证功能是否正常：

```bash
python test_gpt_sovits_config.py
```

### 6. 查看演示

运行演示脚本了解如何在实际应用中使用：

```bash
python demo_gpt_sovits.py
```

## 快速开始

### 基本使用示例

```python
# 首先导入路径配置，确保模块能正确导入
from core.voice.gpt_sovits.path_config import *

# 导入集成模块
from core.voice.gpt_sovits.integration import GPTSoVITSIntegration

# 确保模块已正确导入（如果需要额外检查）
gpt_sovits = ensure_gpt_sovits_import()

# 创建集成实例
engine = GPTSoVITSIntegration()

# 执行语音合成
result = engine.tts(
    text="这是一个GPT-SoVITS语音合成的示例。",
    speaker="default",
    output_file="output.wav"
)

print(f"语音合成完成，音频长度: {len(result['audio'])} 样本")
print(f"推理时间: {result['infer_time']:.2f} 秒")

# 释放资源
engine.release()
```

### 批量处理示例

```python
from core.voice.gpt_sovits.integration import GPTSoVITSIntegration

engine = GPTSoVITSIntegration()

# 准备批量请求
batch_requests = [
    {
        "text": "这是第一个文本。",
        "speaker": "default",
        "speed": 1.0,
        "output_file": "batch_1.wav"
    },
    {
        "text": "这是第二个文本，语速较快。",
        "speaker": "default",
        "speed": 1.2,
        "output_file": "batch_2.wav"
    }
]

# 执行批量合成
results = engine.batch_tts(batch_requests)

# 处理结果
for i, result in enumerate(results):
    if result["success"]:
        print(f"请求 {i+1} 成功: 音频长度 {result['audio'].size}")
    else:
        print(f"请求 {i+1} 失败: {result['error']}")

engine.release()
```

## API 参考

### GPTSoVITSIntegration 类

#### 初始化

```python
def __init__(self, config: Optional[InferenceConfig] = None):
    """
    初始化 GPT-SoVITS 集成
    
    Args:
        config: 推理配置，如果不提供将使用默认配置
    """
```

#### 文本到语音转换

```python
def tts(self, 
        text: str, 
        speaker: str = "default",
        reference_audio: Optional[str] = None,
        text_language: str = "zh",
        speed: float = 1.0,
        emotion: str = "neutral",
        pitch: float = 1.0,
        energy: float = 1.0,
        tone: float = 1.0,
        output_file: Optional[str] = None
       ) -> Dict[str, Union[np.ndarray, float, str]]:
    """
    文本到语音转换
    
    Args:
        text: 要转换的文本
        speaker: 说话人名称
        reference_audio: 参考音频路径（可选，用于声音克隆）
        text_language: 文本语言，默认为中文(zh)
        speed: 语速，默认为1.0
        emotion: 情感，默认为neutral
        pitch: 音高，默认为1.0
        energy: 能量，默认为1.0
        tone: 语调，默认为1.0
        output_file: 输出音频文件路径（可选）
    
    Returns:
        包含音频数据和元数据的字典
    """
```

#### 批量文本到语音转换

```python
def batch_tts(self, 
             requests: List[Dict],
             max_concurrent: Optional[int] = None
            ) -> List[Dict[str, Union[np.ndarray, float, str, bool]]]:
    """
    批量文本到语音转换
    
    Args:
        requests: 请求列表，每个请求是包含tts参数的字典
        max_concurrent: 最大并发数
    
    Returns:
        结果列表
    """
```

#### 说话人管理

```python
def add_speaker(self, 
               name: str, 
               wav_path: str,
               style_params: Optional[Dict] = None
              ) -> bool:
    """
    添加新说话人
    
    Args:
        name: 说话人名称
        wav_path: 参考音频路径
        style_params: 风格参数字典
    
    Returns:
        是否添加成功
    """
```

```python
def list_speakers(self) -> List[Dict[str, Union[str, Dict]]]:
    """
    列出所有可用的说话人
    
    Returns:
        说话人信息列表
    """
```

#### 系统管理

```python
def get_status(self) -> Dict[str, any]:
    """
    获取系统状态
    
    Returns:
        状态信息字典
    """
```

```python
def update_device(self, device: str) -> bool:
    """
    更新运行设备
    
    Args:
        device: 设备名称 (cuda 或 cpu)
    
    Returns:
        是否更新成功
    """
```

```python
def release(self):
    """
    释放资源
    """
```

## 运行测试

运行以下命令测试集成功能：

```bash
python core/voice/gpt_sovits/test_integration.py
```

测试脚本将验证以下功能：
- 基本的 TTS 转换
- 批量 TTS 处理
- 说话人管理
- 系统状态查询

## 高级配置

### 自定义配置

您可以创建自定义的 `InferenceConfig` 对象来配置推理引擎：

```python
from core.voice.gpt_sovits.path_config import *
from core.voice.gpt_sovits.infer import InferenceConfig
from core.voice.gpt_sovits.integration import GPTSoVITSIntegration

# 使用路径配置文件中的常量
custom_config = InferenceConfig(
    gpt_model_path=f"{GPT_SOVITS_ROOT}/pretrained_models/s2Gv2Pro.pth",
    sovits_model_path=f"{GPT_SOVITS_ROOT}/pretrained_models/s2Dv2Pro.pth",
    speaker_encoder_path=SPEAKER_ENCODER_PATH,
    device="cuda",  # 或 "cpu"
    precision="fp16",  # 或 "fp32"
    sample_rate=44100,
    enable_cache=True,
    cache_max_size=2000,
    max_batch_size=32
)

# 使用自定义配置初始化
engine = GPTSoVITSIntegration(custom_config)
```

### 声音克隆

您可以使用参考音频进行声音克隆：

```python
result = engine.tts(
    text="这是使用参考音频进行声音克隆的示例。",
    reference_audio="path/to/reference.wav",  # 参考音频路径
    output_file="cloned_voice.wav"
)
```

## 常见问题

### 1. CUDA 内存不足

如果遇到 CUDA 内存不足的错误，可以尝试以下方法：
- 使用 `device="cpu"` 切换到 CPU 模式
- 减小 `max_batch_size` 参数
- 减小 `cache_max_size` 参数
- 分段处理长文本

### 2. 模型文件未找到

确保模型文件路径正确，默认情况下集成脚本会在以下位置查找模型：
```
models/tts/GPT-SoVITS-v2pro-20250604/GPT_SOVITS/pretrained_models/
```

如果模型文件位于其他位置，请使用自定义配置指定正确的路径。

### 3. 中文分词错误

确保 G2PWModel 已正确解压到以下位置：
```
models/tts/GPT-SoVITS-v2pro-20250604/GPT_SOVITS/text/
```

### 4. 性能优化

- 使用 GPU 可以显著提升性能
- 启用缓存（`enable_cache=True`）可以加快重复文本的处理速度
- 批量处理多个文本可以提高吞吐量

## 故障排除

### 检查系统状态

使用 `get_status()` 方法可以获取系统状态信息，帮助排查问题：

```python
status = engine.get_status()
print(status)
```

### 检查路径配置

确保 `path_config.py` 文件已正确生成，并且包含正确的路径信息：

```python
from core.voice.gpt_sovits.path_config import check_paths

missing_paths = check_paths()
if missing_paths:
    print(f"发现缺失的路径: {missing_paths}")
else:
    print("所有路径都有效")
```

### 模块导入问题排查

如果遇到模块导入问题，可以使用以下方法：

```python
from core.voice.gpt_sovits.path_config import ensure_gpt_sovits_import, import_gpt_sovits_module

# 检查基本模块导入
module = ensure_gpt_sovits_import()
print(f"模块导入: {'成功' if module else '失败'}")

# 检查特定子模块导入
text_module = import_gpt_sovits_module('text')
print(f"text模块: {'成功' if text_module else '失败'}")

utils_module = import_gpt_sovits_module('utils')
print(f"utils模块: {'成功' if utils_module else '失败'}")

### 查看日志

集成脚本会输出详细的日志信息，可以帮助排查问题：

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 注意事项

1. 首次初始化模型可能需要较长时间，请耐心等待
2. GPU 模式下，确保 CUDA 环境配置正确
3. 处理长文本时，考虑分段处理以避免内存问题
4. 参考音频质量会直接影响声音克隆效果
5. 请确保在使用完毕后调用 `release()` 方法释放资源

## 系统架构

GPT-SoVITS 2 Pro 采用模块化设计，主要包含以下核心组件：

```
文本 → 文本前端处理 → GPT模型 → SoVITS声码器 → 音频输出
          ↓
     说话人编码器
```

- **文本前端处理**：负责文本规范化、语言检测、分词、音素化和停顿预测
- **GPT模型**：生成声学隐表示
- **SoVITS声码器**：将隐表示转换为音频波形
- **说话人编码器**：管理说话人嵌入和风格参数
- **设备管理器**：处理GPU/CPU动态调度和资源管理
- **推理引擎**：整合各组件，提供完整的TTS功能
- **API服务**：提供HTTP和WebSocket接口

## 核心功能

✅ **高质量语音合成**：支持中英文混合文本，生成自然流畅的语音
✅ **多说话人管理**：支持添加、删除和切换不同说话人
✅ **批量推理**：支持并行处理多个文本，提高吞吐量
✅ **流式推理**：支持边生成边输出，减少等待时间
✅ **GPU/CPU动态调度**：自动检测并使用最佳可用设备
✅ **完善的API接口**：提供HTTP和WebSocket两种调用方式
✅ **性能监控**：支持实时监控系统资源使用情况
✅ **健壮的错误处理**：包含异常捕获、资源释放和自动重试机制

## 安装部署

### 1. 环境要求

- Python 3.8+
- CUDA 11.6+ (如果使用GPU)
- 至少8GB RAM (推荐16GB+)
- 至少4GB GPU显存 (如果使用GPU)

### 2. 安装依赖

```bash
# 安装基础依赖
pip install -r requirements.txt

# 对于CUDA用户，可能需要安装特定版本的PyTorch
# 例如，对于CUDA 11.8:
pip install torch==2.0.1+cu118 torchaudio==2.0.2+cu118 --index-url https://download.pytorch.org/whl/cu118
```

### 3. 准备模型文件

创建模型目录并放置相应的模型文件：

```
./models/
  ├── gpt/
  │   ├── config.json      # GPT模型配置
  │   └── model.pth        # GPT模型权重
  ├── sovits/
  │   ├── config.json      # SoVITS模型配置
  │   └── model.pth        # SoVITS模型权重
  └── speaker_encoder/
      └── model.pth        # 说话人编码器权重
```

### 4. 配置文件

您可以使用自动生成的 `path_config.py` 文件来获取所有路径配置：

```python
from core.voice.gpt_sovits.path_config import *

# 获取各种路径
print(f"GPT_SOVITS_ROOT: {GPT_SOVITS_ROOT}")
print(f"TEXT_MODEL_DIR: {TEXT_MODEL_DIR}")
print(f"PRETRAINED_MODELS_DIR: {PRETRAINED_MODELS_DIR}")
print(f"SPEAKER_ENCODER_PATH: {SPEAKER_ENCODER_PATH}")
```

或者创建自定义配置文件 `config.json`：

```json
{
  "models": {
    "gpt_model": {
      "config_path": "./models/gpt/config.json",
      "checkpoint_path": "./models/gpt/model.pth"
    },
    "sovits_model": {
      "config_path": "./models/sovits/config.json",
      "checkpoint_path": "./models/sovits/model.pth"
    },
    "speaker_encoder": {
      "checkpoint_path": "./models/speaker_encoder/model.pth"
    }
  },
  "device": {
    "preferred": "auto",
    "max_gpu_memory_usage": 0.9,
    "cpu_fallback": true
  },
  "inference": {
    "batch_size": 4,
    "stream_chunk_size": 16000,
    "max_text_length": 500
  }
}
```

## 使用方法

### 1. 运行演示

```bash
# 使用默认配置运行演示
python main.py --mode demo

# 使用自定义配置运行演示
python main.py --mode demo --config config.json
```

演示将展示单句TTS、批量TTS和流式TTS功能。

### 2. 启动服务器

```bash
# 默认配置启动服务器
python main.py --mode server

# 自定义配置和端口
python main.py --mode server --host 0.0.0.0 --port 8000 --config config.json
```

服务器启动后，可以访问：
- API文档：http://localhost:8000/docs
- 健康检查：http://localhost:8000/health

## API接口文档

### HTTP API

#### 健康检查
```
GET /health
```

#### 单句TTS
```
POST /tts

请求体：
{
  "text": "你好，这是测试文本",
  "speaker": "default",
  "speed": 1.0,
  "emotion": "neutral",
  "reference_audio": null  # 可选，音频文件的Base64编码
}

响应：
- 成功：音频文件 (wav格式)
- 失败：JSON错误信息
```

#### 批量TTS
```
POST /tts/batch

请求体：
{
  "texts": ["第一条文本", "第二条文本"],
  "speaker": "default",
  "speed": 1.0,
  "emotion": "neutral",
  "batch_size": 2
}

响应：
{
  "results": [
    {"audio": "base64编码的音频数据", "sample_rate": 24000},
    {"audio": "base64编码的音频数据", "sample_rate": 24000}
  ]
}
```

#### 说话人管理
```
# 添加说话人
POST /speaker/add

请求体 (multipart/form-data):
- name: 说话人名称
- audio: 参考音频文件 (wav格式)

# 删除说话人
POST /speaker/delete

请求体：
{"name": "说话人名称"}

# 列出说话人
GET /speaker/list

响应：
{"speakers": ["default", "speaker1", "speaker2"]}
```

### WebSocket API

#### 流式TTS
```
WebSocket: ws://localhost:8000/ws/tts/stream

发送：
{
  "text": "你好，这是流式合成测试",
  "speaker": "default",
  "speed": 1.0,
  "emotion": "neutral"
}

接收：
{"type": "chunk", "audio": "base64编码的音频块", "sample_rate": 24000}
{"type": "progress", "progress": 0.5, "text": "已处理文本..."}
{"type": "done"}
{"type": "error", "message": "错误信息"}
```

#### 批量流式TTS
```
WebSocket: ws://localhost:8000/ws/tts/batch-stream

发送：
{
  "texts": ["第一条文本", "第二条文本"],
  "speaker": "default",
  "speed": 1.0,
  "emotion": "neutral"
}

接收：
{"type": "chunk", "index": 0, "audio": "base64编码的音频块", "sample_rate": 24000}
{"type": "text_done", "index": 0}
{"type": "all_done"}
```

#### 系统监控
```
WebSocket: ws://localhost:8000/ws/monitor

接收：
{
  "type": "stats",
  "timestamp": "2024-01-01T12:00:00Z",
  "devices": {
    "cuda:0": {
      "available": true,
      "memory_gb": 16.0,
      "used_memory_gb": 4.5,
      "memory_usage_percent": 28.1,
      "model_count": 2,
      "task_count": 1
    },
    "cpu": {
      "available": true,
      "model_count": 0,
      "task_count": 0
    }
  },
  "active_connections": 5
}
```

## 性能测试

使用提供的性能测试脚本测试系统性能：

```bash
# 启动Locust Web UI
locust -f perf_test.py

# 命令行模式运行压力测试
locust -f perf_test.py --headless -u 50 -r 10 --run-time 5m --host http://localhost:8000
```

性能测试将生成QPS、延迟分布、资源使用等报告。

## 代码结构

```
core/voice/gpt_sovits/
├── integration.py          # 主要集成模块，提供简单易用的 API
├── infer.py                # 核心推理引擎
├── api.py                  # HTTP API接口
├── websocket.py            # WebSocket API接口
├── path_config.py          # 路径配置文件（自动生成）
├── setup_gpt_sovits_path.py # 配置脚本，生成path_config.py
├── test_gpt_sovits_config.py # 测试脚本，验证配置功能
├── demo_gpt_sovits.py      # 演示脚本
├── test_integration.py     # 集成测试脚本
├── text_frontend.py        # 文本前端处理模块
├── gpt_model.py            # GPT模型封装
├── sovits_vocoder.py       # SoVITS声码器封装
├── speaker_encoder.py      # 说话人编码器
├── device_manager.py       # 设备管理器
├── perf_test.py            # 性能测试脚本
├── main.py                 # 主程序和演示
├── requirements.txt        # 依赖清单
└── README.md               # 文档
```

## 动态模块导入机制

为了确保 GPT_SOVITS 模块可以在不同环境中正确导入，我们实现了多种导入策略：

1. **直接导入**: 尝试使用标准的 Python 导入机制
2. **动态加载**: 如果直接导入失败，使用 `importlib.util` 从文件路径动态加载
3. **特殊处理**: 对关键模块如 `text` 进行特殊处理，确保路径设置正确

这些功能都封装在 `path_config.py` 文件中，通过以下辅助函数提供：

- `ensure_gpt_sovits_import()`: 确保 GPT_SOVITS 基本模块已导入
- `import_gpt_sovits_module(module_name)`: 导入特定的子模块
- `check_paths()`: 验证所有必要的路径是否存在
- `get_path_config()`: 获取完整的路径配置信息

## 故障排除

### 常见问题

1. **CUDA内存不足**
   - 解决方案：减小批量大小，或设置`cpu_fallback: true`

2. **模型加载失败**
   - 检查模型文件路径是否正确
   - 确认模型文件格式是否兼容

3. **推理速度慢**
   - 确保使用了GPU（如果可用）
   - 调整批量大小以平衡延迟和吞吐量

4. **服务器启动失败**
   - 检查端口是否被占用
   - 确认依赖包是否正确安装

### 日志

系统日志位于控制台输出，可以通过调整日志级别来获取更详细的信息：

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 许可证

MIT License

## 联系方式

如有问题或建议，请联系项目维护者。