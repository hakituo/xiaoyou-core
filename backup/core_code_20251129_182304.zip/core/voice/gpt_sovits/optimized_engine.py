# -*- coding: utf-8 -*-
"""
GPT-SoVITS 2Pro 优化版引擎实现
遵循标准的语音生成流程，提供高性能、可靠的TTS功能
"""

import os
import torch
import numpy as np
import logging
import time
import gc
import asyncio
from typing import Dict, List, Optional, Union, Tuple
import traceback

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("GPTSoVITS-OptimizedEngine")

# 导入必要的配置和模块
from .path_config import (
    GPT_SOVITS_ROOT,
    PRETRAINED_MODELS_DIR,
    V2PRO_MODELS_DIR,
    SPEAKER_ENCODER_PATH,
    import_gpt_sovits_module
)
from ..base.engine_base import TTSEngineBase
from ..utils.text_processor import TextProcessor

# 动态导入GPT_SOVITS模块
def get_gpt_sovits_module():
    """
    动态导入GPT_SOVITS模块，确保正确加载
    """
    # 首先尝试导入必要的子模块
    inference_webui = import_gpt_sovits_module("inference_webui")
    text = import_gpt_sovits_module("text")
    
    if inference_webui is None:
        logger.error("无法导入GPT_SOVITS.inference_webui模块")
        return None
    
    return inference_webui

class OptimizedGPTSoVITSEngine(TTSEngineBase):
    """
    优化版GPT-SoVITS 2Pro引擎
    遵循标准的6步语音生成流程，提供高效、可靠的TTS功能
    """
    
    def __init__(self, config: Optional[Dict[str, any]] = None):
        """
        初始化优化版引擎
        
        Args:
            config: 引擎配置字典
        """
        # 默认配置
        self.config = {
            "device": "cuda" if torch.cuda.is_available() else "cpu",
            "precision": "fp16" if torch.cuda.is_available() else "fp32",
            "max_batch_size": 4,
            "enable_cache": True,
            "cache_max_size": 1024,
            "sample_rate": 44100,
            "chunk_size": 500,  # 文本分块大小
        }
        
        # 更新配置
        if config:
            self.config.update(config)
        
        super().__init__(device=self.config["device"], sample_rate=int(self.config["sample_rate"]))
        self.precision = self.config["precision"]
        
        # 模型组件
        self._inference_webui = None
        self._tts_model = None
        self._vq_model = None
        self._ssl_model = None
        self._sv_cn_model = None
        self._hps = None
        
        # 缓存机制
        self._enable_cache = self.config["enable_cache"]
        self._cache_max_size = self.config["cache_max_size"]
        self._ref_embedding_cache = {}
        self._ref_spepc_cache = {}
        self._tts_result_cache = {}
        self._cache_access_count = 0
        
        # 性能统计
        self._performance_stats = {
            "total_requests": 0,
            "total_time": 0,
            "total_errors": 0,
        }
        
        # 状态标志
        self._is_initialized = False
        self._lock = asyncio.Lock()
    
    async def initialize(self) -> bool:
        """
        初始化引擎，加载所有必要的模型组件
        
        Returns:
            是否初始化成功
        """
        async with self._lock:
            if self._is_initialized:
                return True
            
            start_time = time.time()
            logger.info("开始初始化优化版GPT-SoVITS引擎...")
            
            try:
                # 载入轻量级TTS推理管线，避免引入WebUI依赖
                try:
                    tts_py = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS", "TTS_infer_pack", "TTS.py")
                    import importlib.util
                    spec = importlib.util.spec_from_file_location("gsv.tts", tts_py)
                    m = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(m)
                    TTS, TTS_Config = m.TTS, m.TTS_Config
                except Exception as e:
                    raise RuntimeError(f"加载TTS管线失败: {e}")

                version = self.config.get("version") or os.environ.get("version") or "v2Pro"
                gpt_path = self.config.get("gpt_path") or os.environ.get("gpt_path")
                sovits_path = self.config.get("sovits_path") or os.environ.get("sovits_path")
                bert_path = self.config.get("bert_path") or os.environ.get("bert_path") or os.path.join(PRETRAINED_MODELS_DIR, "chinese-roberta-wwm-ext-large")
                cnhubert_path = self.config.get("cnhubert_base_path") or os.environ.get("cnhubert_base_path") or os.path.join(PRETRAINED_MODELS_DIR, "chinese-hubert-base")
                try:
                    dev_cfg = str(self.config.get("device") or ("cuda" if torch.cuda.is_available() else "cpu"))
                    prec_cfg = str(self.config.get("precision") or ("fp16" if (dev_cfg.startswith("cuda") and torch.cuda.is_available()) else "fp32"))
                    self.device = dev_cfg
                    self.precision = prec_cfg
                    logger.info(f"torch.cuda.is_available={torch.cuda.is_available()} | engine.device={self.device} | engine.precision={self.precision}")
                except Exception:
                    pass

                cfg_path = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS", "configs", "tts_infer.yaml")
                cfg = TTS_Config(cfg_path)
                cfg.device = torch.device(self.device)
                cfg.is_half = (self.precision == "fp16" and self.device.startswith("cuda") and torch.cuda.is_available())
                cfg.update_version(version)
                if gpt_path:
                    try:
                        cfg.configs["t2s_weights_path"] = gpt_path
                    except Exception:
                        pass
                if sovits_path:
                    try:
                        cfg.configs["vits_weights_path"] = sovits_path
                    except Exception:
                        pass
                if bert_path:
                    try:
                        cfg.configs["bert_base_path"] = bert_path
                    except Exception:
                        pass
                if cnhubert_path:
                    try:
                        cfg.configs["cnhuhbert_base_path"] = cnhubert_path
                    except Exception:
                        pass

                self._tts_pipeline = TTS(cfg)
                try:
                    self._tts_pipeline.set_device(torch.device(self.device), save=False)
                    try:
                        if getattr(self._tts_pipeline, "bert_model", None) is not None:
                            try:
                                self._tts_pipeline.bert_model.float()
                            except Exception:
                                pass
                        if getattr(self._tts_pipeline, "cnhuhbert_model", None) is not None:
                            try:
                                self._tts_pipeline.cnhuhbert_model.float()
                            except Exception:
                                pass
                    except Exception:
                        pass
                    try:
                        t2s_d = str(next(self._tts_pipeline.t2s_model.parameters()).device) if self._tts_pipeline.t2s_model is not None else "None"
                        vits_d = str(next(self._tts_pipeline.vits_model.parameters()).device) if self._tts_pipeline.vits_model is not None else "None"
                        bert_d = str(next(self._tts_pipeline.bert_model.parameters()).device) if self._tts_pipeline.bert_model is not None else "None"
                        cnh_d = str(next(self._tts_pipeline.cnhuhbert_model.parameters()).device) if self._tts_pipeline.cnhuhbert_model is not None else "None"
                        sv_d = str(next(self._tts_pipeline.sv_model.embedding_model.parameters()).device) if getattr(self._tts_pipeline, "sv_model", None) and getattr(self._tts_pipeline.sv_model, "embedding_model", None) is not None else "None"
                        logger.info(f"Forced device after set_device: T2S={t2s_d}, VITS={vits_d}, BERT={bert_d}, CNHuBERT={cnh_d}, SV={sv_d}")
                        try:
                            dev = torch.device(self.device)
                            def _move(m):
                                try:
                                    if m is not None:
                                        m.to(dev)
                                except Exception:
                                    pass
                            _move(getattr(self._tts_pipeline, "t2s_model", None))
                            _move(getattr(self._tts_pipeline, "vits_model", None))
                            _move(getattr(self._tts_pipeline, "bert_model", None))
                            _move(getattr(self._tts_pipeline, "cnhuhbert_model", None))
                            if getattr(self._tts_pipeline, "sv_model", None) and getattr(self._tts_pipeline.sv_model, "embedding_model", None) is not None:
                                _move(self._tts_pipeline.sv_model.embedding_model)
                            try:
                                t2s_d2 = str(next(self._tts_pipeline.t2s_model.parameters()).device) if self._tts_pipeline.t2s_model is not None else "None"
                                vits_d2 = str(next(self._tts_pipeline.vits_model.parameters()).device) if self._tts_pipeline.vits_model is not None else "None"
                                bert_d2 = str(next(self._tts_pipeline.bert_model.parameters()).device) if self._tts_pipeline.bert_model is not None else "None"
                                cnh_d2 = str(next(self._tts_pipeline.cnhuhbert_model.parameters()).device) if self._tts_pipeline.cnhuhbert_model is not None else "None"
                                sv_d2 = str(next(self._tts_pipeline.sv_model.embedding_model.parameters()).device) if getattr(self._tts_pipeline, "sv_model", None) and getattr(self._tts_pipeline.sv_model, "embedding_model", None) is not None else "None"
                                logger.info(f"Device reassigned: T2S={t2s_d2}, VITS={vits_d2}, BERT={bert_d2}, CNHuBERT={cnh_d2}, SV={sv_d2}")
                            except Exception:
                                pass
                        except Exception:
                            pass
                    except Exception:
                        pass
                except Exception:
                    pass
                try:
                    # 强制最长生成时长
                    force_max_sec = int(self.config.get("force_max_sec") or os.environ.get("TTS_FORCE_MAX_SEC") or 10)
                    self._tts_pipeline.configs.max_sec = force_max_sec
                except Exception:
                    pass
                try:
                    # 可选强制启用声码器以提高稳定性（仅支持v3/v4）
                    force_use_vocoder = str(self.config.get("force_use_vocoder") or os.environ.get("TTS_FORCE_USE_VOCODER") or "false").lower() == "true"
                    vocoder_version = str(self.config.get("vocoder_version") or os.environ.get("TTS_FORCE_VOCODER_VERSION") or "v4")
                    if force_use_vocoder and not getattr(self._tts_pipeline, "is_v2pro", False):
                        self._tts_pipeline.configs.use_vocoder = True
                        try:
                            self._tts_pipeline.init_vocoder(vocoder_version)
                        except Exception:
                            self._tts_pipeline.configs.use_vocoder = False
                except Exception:
                    pass
                self.config["sample_rate"] = int(self._tts_pipeline.configs.sampling_rate)
                self._is_initialized = True
                logger.info(f"优化版GPT-SoVITS引擎初始化完成，耗时: {time.time() - start_time:.2f}秒")
                return True
                
                self._is_initialized = True
                logger.info(f"优化版GPT-SoVITS引擎初始化完成，耗时: {time.time() - start_time:.2f}秒")
                return True
                
            except Exception as e:
                logger.error(f"初始化引擎失败: {str(e)}")
                traceback.print_exc()
                # 清理资源
                self._clean_resources()
                return False
    
    def _generate_cache_key(self, *args) -> str:
        """
        生成缓存键
        
        Args:
            *args: 缓存键的组成部分
            
        Returns:
            缓存键字符串
        """
        return "_".join(str(arg) for arg in args)
    
    def _get_from_cache(self, cache: Dict, key: str):
        """
        从缓存获取数据
        
        Args:
            cache: 缓存字典
            key: 缓存键
            
        Returns:
            缓存的数据，如果不存在则返回None
        """
        if not self._enable_cache:
            return None
        
        result = cache.get(key)
        if result is not None:
            logger.debug(f"缓存命中: {key}")
        return result
    
    def _set_to_cache(self, cache: Dict, key: str, value):
        """
        设置缓存数据
        
        Args:
            cache: 缓存字典
            key: 缓存键
            value: 要缓存的值
        """
        if not self._enable_cache:
            return
        
        # 检查缓存大小，必要时清理
        if len(cache) >= self._cache_max_size:
            self._cleanup_caches()
        
        cache[key] = value
        self._cache_access_count += 1
    
    def _cleanup_caches(self):
        """
        清理缓存，移除最旧的条目
        """
        # 为每个缓存保留80%的容量
        for cache in [self._ref_embedding_cache, self._ref_spepc_cache, self._tts_result_cache]:
            if len(cache) > self._cache_max_size:
                # 移除最旧的条目（简单实现，实际可以使用LRU等策略）
                keys_to_remove = list(cache.keys())[:len(cache) - int(self._cache_max_size * 0.8)]
                for key in keys_to_remove:
                    cache.pop(key, None)
                logger.debug(f"缓存已清理，当前大小: {len(cache)}")
    
    def _clean_resources(self):
        """
        清理资源，防止内存泄漏
        """
        try:
            # 清理CUDA缓存
            if self.device == "cuda" and torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
            
            # 强制垃圾回收
            gc.collect()
        except Exception as e:
            logger.error(f"清理资源失败: {str(e)}")
    
    def _check_parameters(self, text: str, ref_audio: str, style: int, speed: float, emotion: float) -> None:
        """
        验证输入参数
        
        Args:
            text: 要朗读的文本
            ref_audio: 参考音频文件路径
            style: 风格编号（1-4）
            speed: 语速（0.8-1.2）
            emotion: 情绪强度（0-1）
            
        Raises:
            ValueError: 如果参数无效
        """
        # 检查文本是否为空
        if not text or not text.strip():
            raise ValueError("文本不能为空")
        
        # 参考音频可选，若不存在则走无参考音频路径
        
        # 检查参数范围
        if style not in [1, 2, 3, 4]:
            raise ValueError("风格编号必须是1-4之间的整数")
        
        if not 0.8 <= speed <= 1.2:
            raise ValueError("语速必须在0.8-1.2之间")
        
        if not 0 <= emotion <= 1:
            raise ValueError("情绪强度必须在0-1之间")
    
    def _encode_speaker(self, ref_audio: str) -> torch.Tensor:
        """
        步骤2: 生成 speaker embedding - encode_speaker(ref_audio)
        
        Args:
            ref_audio: 参考音频文件路径
            
        Returns:
            说话人嵌入向量
        """
        # 生成缓存键
        ref_wav_key = self._generate_cache_key(ref_audio)
        emb_cache_key = self._generate_cache_key(ref_wav_key, "embedding")
        
        # 尝试从缓存获取
        cached_emb = self._get_from_cache(self._ref_embedding_cache, emb_cache_key)
        if cached_emb is not None:
            return cached_emb
        
        # 获取频谱特征
        refers, audio_tensor = self._get_spepc(ref_audio, ref_wav_key)
        
        # 计算嵌入
        with torch.no_grad():
            sv_emb = self._sv_cn_model.compute_embedding3(audio_tensor)
        
        # 缓存嵌入
        self._set_to_cache(self._ref_embedding_cache, emb_cache_key, sv_emb)
        
        return sv_emb
    
    def _get_spepc(self, ref_audio: str, ref_wav_key: str) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        获取频谱特征
        
        Args:
            ref_audio: 参考音频文件路径
            ref_wav_key: 参考音频缓存键
            
        Returns:
            频谱特征和音频张量
        """
        # 尝试从缓存获取
        spepc_cache_key = self._generate_cache_key(ref_wav_key, "spepc")
        cached_spepc = self._get_from_cache(self._ref_spepc_cache, spepc_cache_key)
        
        if cached_spepc is not None:
            return cached_spepc
        
        # 从参考音频获取频谱特征
        from GPT_SOVITS.inference_webui import get_spepc
        refers, audio_tensor = get_spepc(self._hps, ref_audio, torch.float16 if self.precision == "fp16" else torch.float32, self.device, is_v2pro=True)
        
        # 缓存频谱特征
        self._set_to_cache(self._ref_spepc_cache, spepc_cache_key, (refers, audio_tensor))
        
        return refers, audio_tensor
    
    def _encode_style(self, style: int, emotion: float) -> Dict[str, Union[int, float]]:
        """
        步骤3: 生成 style embedding - encode_style(style, emotion)
        
        Args:
            style: 风格编号（1-4）
            emotion: 情绪强度（0-1）
            
        Returns:
            风格参数字典
        """
        # 根据风格和情绪生成风格参数
        style_params = {
            "style": style,
            "emotion": emotion,
            "tone": "normal"  # 默认语调
        }
        
        # 根据风格调整参数
        if style == 1:  # 温柔/轻声/亲密感
            style_params["energy"] = 0.7 + emotion * 0.3
            style_params["tone"] = "soft"
        elif style == 2:  # 冷静/理性/淡淡疏离
            style_params["energy"] = 0.6 + emotion * 0.2
            style_params["tone"] = "calm"
        elif style == 3:  # 真实自然/情绪多变（主风格）
            style_params["energy"] = 0.8 + emotion * 0.2
            style_params["tone"] = "natural"
        elif style == 4:  # 活泼/明亮/偶尔撒娇
            style_params["energy"] = 0.9 + emotion * 0.1
            style_params["tone"] = "lively"
        
        return style_params
    
    def _gpt_generate(self, text: str, speaker_emb: torch.Tensor, style_params: Dict, speed: float) -> torch.Tensor:
        """
        步骤4: 合成语音 latent - gpt_generate(text, speaker, style, speed)
        
        Args:
            text: 要朗读的文本
            speaker_emb: 说话人嵌入向量
            style_params: 风格参数
            speed: 语速
            
        Returns:
            语音潜在表示
        """
        # 获取音素和BERT特征
        from GPT_SOVITS.inference_webui import get_phones_and_bert
        phones, bert, norm_text = get_phones_and_bert(text, "auto", "v2")
        
        # 准备输入张量
        phoneme_ids = torch.LongTensor(phones).to(self.device).unsqueeze(0)
        phoneme_len = torch.tensor([len(phones)]).to(self.device)
        bert = bert.to(self.device).unsqueeze(0)
        
        # 生成语义特征
        with torch.no_grad():
            # 使用GPT模型生成潜在表示
            pred_semantic, idx = self._tts_model.model.infer_panel(
                phoneme_ids,
                phoneme_len,
                None,  # 没有prompt
                bert,
                top_k=50,
                top_p=0.8,
                temperature=0.7,
                early_stop_num=24000 * 30  # 最大30秒
            )
            # 截取有效部分
            pred_semantic = pred_semantic[:, -idx:].unsqueeze(0)
        
        return pred_semantic
    
    def _vocoder(self, latent: torch.Tensor, phones: List[int], refers: torch.Tensor, speaker_emb: torch.Tensor, speed: float) -> torch.Tensor:
        """
        步骤5: 通过声码器生成最终音频 - vocoder(latent)
        
        Args:
            latent: 语音潜在表示
            phones: 音素列表
            refers: 参考频谱特征
            speaker_emb: 说话人嵌入向量
            speed: 语速
            
        Returns:
            生成的音频张量
        """
        with torch.no_grad():
            # 使用声码器解码
            audio = self._vq_model.decode(
                latent,
                torch.LongTensor(phones).to(self.device).unsqueeze(0),
                [refers],  # 包装成列表
                speed=speed,
                sv_emb=[speaker_emb]  # 包装成列表
            )[0][0]
            
            # 音频归一化
            max_audio = torch.abs(audio).max()
            if max_audio > 1:
                audio = audio / max_audio
        
        return audio
    
    def _save_audio(self, audio: torch.Tensor, output_path: str) -> None:
        """
        步骤6: 输出音频路径 - save_audio(wav, "output.wav")
        
        Args:
            audio: 音频张量
            output_path: 输出文件路径
        """
        import soundfile as sf
        
        audio_np = audio.cpu().detach().numpy()
        m = float(np.max(np.abs(audio_np))) if audio_np.size else 0.0
        if m > 1.0:
            audio_np = (audio_np / m).astype(np.float32)
        audio_np = np.clip(audio_np.astype(np.float32), -1.0, 1.0)
        pcm16 = (audio_np * 32767.0).astype(np.int16)
        sf.write(output_path, pcm16, self.config["sample_rate"])
        logger.info(f"音频已保存到: {output_path}")
    
    def _process_long_text(self, text: str, chunk_size: int = 500) -> List[str]:
        """
        处理长文本，将其分割成合适大小的块
        
        Args:
            text: 长文本
            chunk_size: 每块的最大字符数
            
        Returns:
            文本块列表
        """
        # 如果文本较短，直接返回
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        current_chunk = ""
        
        # 尝试在标点符号处分割
        punctuation_marks = ["。", "！", "？", ".", "!", "?", "；", ";", "，", ","]
        
        for char in text:
            current_chunk += char
            
            # 当达到块大小且遇到标点时分割
            if len(current_chunk) >= chunk_size and char in punctuation_marks:
                chunks.append(current_chunk)
                current_chunk = ""
        
        # 添加最后一块
        if current_chunk.strip():
            chunks.append(current_chunk)
        
        return chunks
    
    async def synthesize(self, text: str, ref_audio: Optional[str] = None, style: int = 3,
                         speed: float = 1.0, emotion: float = 0.5,
                         output_path: Optional[str] = None, **kwargs) -> np.ndarray:
        """
        标准语音生成流程
        
        Args:
            text: 要朗读的文本
            ref_audio: 参考音频文件路径
            style: 风格编号（1-4）
            speed: 语速（0.8-1.2）
            emotion: 情绪强度（0-1）
            output_path: 可选的输出文件路径
            
        Returns:
            生成的音频数据和采样率
        """
        start_time = time.time()
        try:
            tp = TextProcessor()
            cleaned_text, mk = tp.extract_markers(text)
            if isinstance(cleaned_text, str) and cleaned_text:
                text = cleaned_text
            if "speed" in mk:
                try:
                    speed = float(mk["speed"])
                except Exception:
                    pass
            if "pitch" in mk:
                try:
                    kwargs["pitch"] = float(mk["pitch"])
                except Exception:
                    pass
            if "style" in mk:
                try:
                    if isinstance(mk["style"], int):
                        style = int(mk["style"])
                    else:
                        _sm = {"soft":1, "calm":2, "natural":3, "lively":4}
                        style = _sm.get(str(mk["style"]).lower(), style)
                except Exception:
                    pass
            if "emotion" in mk:
                try:
                    emotion = float(mk["emotion"])
                except Exception:
                    pass
            if "emotion_key" in mk:
                try:
                    kwargs["emotion_key"] = str(mk["emotion_key"]).lower()
                except Exception:
                    pass
        except Exception:
            pass
        
        # 解析参考音频别名
        if not ref_audio:
            ref_audio = kwargs.get("ref_wav_path") or kwargs.get("speaker_wav") or kwargs.get("reference_audio")
        if not ref_audio:
            ref_audio = ""
        # 确保引擎已初始化
        if not self._is_initialized:
            if not await self.initialize():
                raise RuntimeError("GPT-SoVITS引擎初始化失败")
        
        try:
            if bool(kwargs.get("allow_fallback")):
                try:
                    self._check_parameters(text, ref_audio, style, speed, emotion)
                except Exception as e:
                    msg = str(e)
                    if "参考音频未找到" not in msg:
                        raise
            else:
                self._check_parameters(text, ref_audio, style, speed, emotion)

            import re, json
            def _emo_label(s):
                try:
                    m = re.match(r"\s*\[EMO:\s*\{(.+?)\}\]", s, re.S)
                    if not m:
                        return None
                    payload = "{" + m.group(1) + "}"
                    try:
                        d = json.loads(payload)
                    except Exception:
                        d = dict((a, float(b)) for a, b in re.findall(r"\"([^\"]+)\"\s*:\s*([0-9.]+)", payload))
                    if not d:
                        return None
                    return max(d.items(), key=lambda x: float(x[1]))[0]
                except Exception:
                    return None
            try:
                emo_key = str(kwargs.get("emotion_key") or "").strip().lower()
                lab = emo_key or _emo_label(text) or ""
                if lab:
                    proj_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                    ref_dir = os.path.join(proj_root, 'ref_audio', 'female')
                    files = []
                    try:
                        files = [os.path.join(ref_dir, f) for f in os.listdir(ref_dir) if f.lower().endswith('.wav') and f.lower().startswith('ref')]
                    except Exception:
                        files = []
                    key_map = {
                        'neutral': ['neutral', 'calm', '平静'],
                        'happy': ['happy', '欢', '开心', '愉快', 'huanhuan'],
                        'shy': ['shy', '害羞', '羞'],
                        'angry': ['angry', '生气', '愤怒'],
                        'jealous': ['jealous', '吃醋'],
                        'wronged': ['wronged', '委屈'],
                        'coquetry': ['coquetry', '撒娇', '娇', '妹妹'],
                        'lost': ['lost', '失落', '伤心'],
                        'excited': ['excited', '兴奋']
                    }
                    keys = key_map.get(str(lab).lower(), [str(lab).lower()])
                    def _match(p):
                        name = os.path.basename(p).lower()
                        if not name.startswith('ref'):
                            return False
                        for k in keys:
                            if str(k).lower() in name or k in os.path.basename(p):
                                return True
                        return False
                    cands = [p for p in files if _match(p)]
                    if cands:
                        ref_audio = cands[0]
            except Exception:
                pass
            how_to_cut = kwargs.get("how_to_cut") or "不切"
            prompt_text = kwargs.get("prompt_text") or ""
            prompt_language = kwargs.get("prompt_language") or "中文"
            text_language = kwargs.get("text_language") or "中文"
            def _map_lang(name: str) -> str:
                n = str(name or "").strip()
                if n in ("日文", "日语", "日本語", "Japanese", "ja", "jp"):
                    return "ja"
                if n in ("粤语", "粵語", "Cantonese", "yue"):
                    return "yue"
                if n in ("英文", "English", "en"):
                    return "en"
                return "zh" if n in ("中文", "中英混合") else "all_zh"
            _text_lang_code = _map_lang(text_language)
            _prompt_lang_code = _map_lang(prompt_language)
            if _text_lang_code == "ja":
                _text_lang_code = "all_ja"
            try:
                import soundfile as _sf
                if ref_audio and os.path.exists(ref_audio):
                    _data, _sr = _sf.read(ref_audio)
                    _dur = len(_data) / float(_sr)
                    if _data.ndim > 1:
                        _data = _data.mean(axis=1)
                    _ma = float(np.max(np.abs(_data))) if _data.size else 0.0
                    _me = float(np.mean(np.abs(_data))) if _data.size else 0.0
                    if _dur < 3.0 or _dur > 10.0 or _ma < 1e-4 or _me > 0.95:
                        # 当前参考音频质量不可用，尝试目录中的备用参考音频
                        _fallback_ref = None
                        try:
                            proj_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                            ref_dir = os.path.join(proj_root, 'ref_audio', 'female')
                            candidates = [os.path.join(ref_dir, f) for f in os.listdir(ref_dir) if f.lower().endswith('.wav') and f.lower().startswith('ref')]
                            _neutral = [p for p in candidates if 'neutral' in os.path.basename(p).lower() or '平静' in os.path.basename(p)]
                            _fallback_ref = (_neutral[0] if _neutral else (candidates[0] if candidates else None))
                        except Exception:
                            _fallback_ref = None
                        if _fallback_ref and os.path.exists(_fallback_ref):
                            ref_audio = _fallback_ref
                else:
                    # 未提供或不存在，尝试使用目录中的默认参考音频
                    _fallback_ref = None
                    try:
                        proj_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                        ref_dir = os.path.join(proj_root, 'ref_audio', 'female')
                        candidates = [os.path.join(ref_dir, f) for f in os.listdir(ref_dir) if f.lower().endswith('.wav') and f.lower().startswith('ref')]
                        _neutral = [p for p in candidates if 'neutral' in os.path.basename(p).lower() or '平静' in os.path.basename(p)]
                        _fallback_ref = (_neutral[0] if _neutral else (candidates[0] if candidates else None))
                    except Exception:
                        _fallback_ref = None
                    if _fallback_ref and os.path.exists(_fallback_ref):
                        ref_audio = _fallback_ref
            except Exception:
                # 读取异常时，尝试继续使用目录中的默认参考音频
                try:
                    proj_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                    ref_dir = os.path.join(proj_root, 'ref_audio', 'female')
                    candidates = [os.path.join(ref_dir, f) for f in os.listdir(ref_dir) if f.lower().endswith('.wav') and f.lower().startswith('ref')]
                    _neutral = [p for p in candidates if 'neutral' in os.path.basename(p).lower() or '平静' in os.path.basename(p)]
                    _fallback_ref = (_neutral[0] if _neutral else (candidates[0] if candidates else None))
                    if _fallback_ref and os.path.exists(_fallback_ref):
                        ref_audio = _fallback_ref
                except Exception:
                    pass

            # v2Pro不强制需要prompt_text；若用户未提供，则保持为空，避免将目标文本误作为参考文本
            try:
                _tp2 = tp if isinstance(tp, TextProcessor) else TextProcessor()
                _clean_text = _tp2.remove_bracketed(text)
            except Exception:
                _clean_text = text
            inputs = {
                "text": _clean_text,
                "text_lang": _text_lang_code,
                "ref_audio_path": ref_audio or "",
                "aux_ref_audio_paths": [],
                "prompt_text": prompt_text,
                "prompt_lang": _prompt_lang_code,
                "top_k": int(kwargs.get("top_k", 50)),
                "top_p": float(kwargs.get("top_p", 0.7)),
                "temperature": float(kwargs.get("temperature", 0.6)),
                "text_split_method": {"不切": "cut0", "凑四句一切": "cut1", "凑50字一切": "cut2", "按中文句号。切": "cut3", "按英文句号.切": "cut4", "按标点符号切": "cut5"}.get(how_to_cut or "按标点符号切", "cut5"),
                "batch_size": int(kwargs.get("batch_size", 1)),
                "batch_threshold": float(kwargs.get("batch_threshold", 0.75)),
                "split_bucket": bool(kwargs.get("split_bucket", False)),
                "speed_factor": float(speed),
                "fragment_interval": float(kwargs.get("pause_second", 0.2)),
                "seed": int(kwargs.get("seed", -1)),
                "media_type": "wav",
                "streaming_mode": False,
                "parallel_infer": bool(kwargs.get("parallel_infer", False)),
                "repetition_penalty": float(kwargs.get("repetition_penalty", 1.2)),
                "sample_steps": int(kwargs.get("sample_steps", 32)),
                "super_sampling": bool(kwargs.get("super_sampling", False)),
            }
            # 简单的歌唱模式调优：略降速、略提温度，保留中文分句
            if bool(kwargs.get("sing_mode")):
                inputs["text_split_method"] = "cut5"
                try:
                    inputs["speed_factor"] = max(0.85, float(speed) - 0.05)
                    inputs["temperature"] = max(0.7, float(kwargs.get("temperature", 0.72)))
                except Exception:
                    pass
            gen = self._tts_pipeline.run(inputs)
            sr = None
            segments = []
            try:
                for item in gen:
                    try:
                        _sr, _audio = item
                    except Exception:
                        continue
                    sr = _sr
                    if isinstance(_audio, np.ndarray):
                        segments.append(_audio.astype(np.float32))
                    else:
                        try:
                            segments.append(np.asarray(_audio, dtype=np.float32))
                        except Exception:
                            pass
            except Exception:
                pass
            if segments:
                try:
                    def _xf(a_list, _sr, ms=None):
                        if not a_list:
                            return np.zeros((0,), dtype=np.float32)
                        if len(a_list) == 1:
                            return a_list[0].astype(np.float32)
                        if ms is None:
                            try:
                                ms = float(kwargs.get("xfade_ms", 25))
                            except Exception:
                                ms = 25.0
                        fade = max(1, int(float(_sr) * float(ms) / 1000.0))
                        out = a_list[0].astype(np.float32)
                        for nxt in a_list[1:]:
                            b = nxt.astype(np.float32)
                            f = min(fade, len(out), len(b))
                            if f > 1:
                                ramp = np.linspace(1.0, 0.0, f, dtype=np.float32)
                                ramp2 = np.linspace(0.0, 1.0, f, dtype=np.float32)
                                tail = out[-f:] * ramp
                                head = b[:f] * ramp2
                                merged = tail + head
                                out = np.concatenate([out[:-f], merged, b[f:]], dtype=np.float32)
                            else:
                                out = np.concatenate([out, b], dtype=np.float32)
                        return out
                    audio_np = _xf(segments, sr or int(self.config.get("sample_rate") or 44100))
                except Exception:
                    audio_np = segments[0]
            else:
                sr, audio_np = next(self._tts_pipeline.run(inputs))
            try:
                _dur = float(len(audio_np)) / max(1, int(sr or self.config.get("sample_rate") or 44100))
                if _dur <= 0.5:
                    self._tts_pipeline.configs.max_sec = max(getattr(self._tts_pipeline.configs, "max_sec", 10), 10)
                    try:
                        if not getattr(self._tts_pipeline, "is_v2pro", False):
                            self._tts_pipeline.configs.use_vocoder = True
                            self._tts_pipeline.init_vocoder(str(self.config.get("vocoder_version") or "v4"))
                    except Exception:
                        pass
                    gen = self._tts_pipeline.run(inputs)
                    sr2 = None
                    segs2 = []
                    try:
                        for it in gen:
                            try:
                                _sr2, _a2 = it
                            except Exception:
                                continue
                            sr2 = _sr2
                            segs2.append(np.asarray(_a2, dtype=np.float32))
                        if segs2:
                            audio_np = np.concatenate(segs2)
                            sr = sr2 or sr
                    except Exception:
                        pass
            except Exception:
                pass

            # 合成后应用音高移调（pitch），用于情绪驱动的音高调整
            try:
                pitch_factor = float(kwargs.get("pitch", 1.0))
                if abs(pitch_factor - 1.0) > 1e-3 and sr and isinstance(sr, (int, float)):
                    import numpy as _np
                    import librosa as _librosa
                    # librosa以半音为单位，半音 = 12 * log2(factor)
                    n_steps = 12.0 * _np.log2(max(1e-3, pitch_factor))
                    audio_np = _librosa.effects.pitch_shift(audio_np.astype(_np.float32), int(sr), n_steps)
            except Exception:
                pass
            try:
                import numpy as _np
                _arr = _np.asarray(audio_np)
                if _np.issubdtype(_arr.dtype, _np.integer):
                    _max_int = _np.iinfo(_arr.dtype).max
                    audio_np = (_arr.astype(_np.float32) / float(_max_int)).clip(-1.0, 1.0)
                else:
                    audio_np = _arr.astype(_np.float32).clip(-1.0, 1.0)
                # 去直流
                _mean = float(audio_np.mean()) if audio_np.size else 0.0
                if _mean != 0.0:
                    audio_np = audio_np - _mean
                # 噪声门（动态门限）
                try:
                    sr_eff = int(sr or self.config.get("sample_rate") or 44100)
                    w = max(1, int(sr_eff * 0.03))
                    env = _np.sqrt(_np.convolve(_np.square(audio_np), _np.ones(w, dtype=_np.float32)/float(w), mode='same'))
                    th = float(kwargs.get("noise_gate_threshold", 0.006))
                    gate = (env / (env + th + 1e-8)).astype(_np.float32)
                    gain = (0.7 + 0.3 * gate).astype(_np.float32)
                    audio_np = (audio_np * gain).astype(_np.float32)
                except Exception:
                    pass
                # 高通/低通一阶滤波
                try:
                    sr_eff = int(sr or self.config.get("sample_rate") or 44100)
                    # 高通 80Hz
                    fc_hp = float(kwargs.get("hp_cut", 80.0))
                    dt = 1.0 / float(sr_eff)
                    RC_hp = 1.0 / (2.0 * 3.1415926 * fc_hp)
                    alpha_hp = RC_hp / (RC_hp + dt)
                    y = _np.zeros_like(audio_np, dtype=_np.float32)
                    x_prev = 0.0
                    y_prev = 0.0
                    for i in range(len(audio_np)):
                        x = float(audio_np[i])
                        y_prev = alpha_hp * (y_prev + x - x_prev)
                        y[i] = y_prev
                        x_prev = x
                    audio_np = y
                    # 低通 12000Hz
                    fc_lp = float(kwargs.get("lp_cut", 6000.0))
                    RC_lp = 1.0 / (2.0 * 3.1415926 * fc_lp)
                    alpha_lp = dt / (RC_lp + dt)
                    y2 = _np.zeros_like(audio_np, dtype=_np.float32)
                    for i in range(len(audio_np)):
                        y2[i] = y2[i-1] + alpha_lp * (audio_np[i] - y2[i-1]) if i > 0 else alpha_lp * audio_np[i]
                    audio_np = y2
                except Exception:
                    pass
                # 归一化与限幅
                _max = float(_np.max(_np.abs(audio_np))) if audio_np.size else 0.0
                if _max > 0.95:
                    _s = 0.95 / max(_max, 1e-6)
                    audio_np = (audio_np * _s).astype(_np.float32)
                else:
                    if _max > 0.0 and _max < 0.2:
                        _factor = min(2.0, 0.9 / max(_max, 1e-6))
                        audio_np = (audio_np * _factor).astype(_np.float32)
                audio_np = _np.tanh(audio_np * 1.1).astype(_np.float32)
                try:
                    sr_eff = int(sr or self.config.get("sample_rate") or 44100)
                    thr = float(kwargs.get("limit_threshold", 0.80))
                    atk = max(1, int(sr_eff * float(kwargs.get("limit_attack_ms", 2)) / 1000.0))
                    rel = max(1, int(sr_eff * float(kwargs.get("limit_release_ms", 80)) / 1000.0))
                    g = _np.ones_like(audio_np, dtype=_np.float32)
                    for i in range(len(audio_np)):
                        e = abs(float(audio_np[i]))
                        tgt = (thr / max(e, 1e-8)) if e > thr else 1.0
                        prev = g[i-1] if i > 0 else 1.0
                        if tgt < prev:
                            a = 1.0 - 1.0 / float(atk)
                            g[i] = a * prev + (1.0 - a) * tgt
                        else:
                            r = 1.0 - 1.0 / float(rel)
                            g[i] = r * prev + (1.0 - r) * tgt
                    audio_np = (audio_np * g).astype(_np.float32)
                except Exception:
                    pass
                try:
                    import numpy.fft as _fft
                    sr_eff = int(sr or self.config.get("sample_rate") or 44100)
                    win = max(64, int(sr_eff * 0.01))
                    step = max(1, win // 2)
                    x = audio_np.astype(_np.float32)
                    out = _np.zeros_like(x)
                    freqs = _np.fft.rfftfreq(win, d=1.0 / float(sr_eff))
                    hi_start = float(kwargs.get("de_esser_start_hz", 4000.0))
                    for i in range(0, len(x) - win, step):
                        s = x[i:i + win]
                        S = _fft.rfft(s)
                        mag = _np.abs(S)
                        tot = float(_np.sum(mag)) + 1e-8
                        ratio = float(_np.sum(mag[hi])) / tot
                        k = 0.5 if ratio > 0.18 else (0.75 if ratio > 0.12 else 1.0)
                        S[hi] = S[hi] * k
                        s2 = _fft.irfft(S, n=win).astype(_np.float32)
                        out[i:i + win] += s2
                    denom = _np.zeros_like(x)
                    for i in range(0, len(x) - win, step):
                        denom[i:i + win] += 1.0
                    denom[denom < 1] = 1.0
                    audio_np = (out / denom).astype(_np.float32)
                except Exception:
                    pass
                # 开头/结尾淡入淡出
                try:
                    sr_eff = int(sr or self.config.get("sample_rate") or 44100)
                    fms = int(float(kwargs.get("fade_ms", 15)))
                    f = max(1, int(sr_eff * fms / 1000.0))
                    ramp_in = _np.linspace(0.0, 1.0, f, dtype=_np.float32)
                    ramp_out = _np.linspace(1.0, 0.0, f, dtype=_np.float32)
                    if len(audio_np) >= f:
                        audio_np[:f] = audio_np[:f] * ramp_in
                        audio_np[-f:] = audio_np[-f:] * ramp_out
                except Exception:
                    pass
                try:
                    tgt_sr = int(float(kwargs.get("downsample_sr", 0)))
                    if tgt_sr and sr and int(sr) > tgt_sr:
                        import librosa as _librosa
                        audio_np = _librosa.resample(audio_np.astype(_np.float32), int(sr), tgt_sr).astype(_np.float32)
                        sr = int(tgt_sr)
                except Exception:
                    pass
            except Exception:
                pass

            processing_time = time.time() - start_time
            self._performance_stats["total_requests"] += 1
            self._performance_stats["total_time"] += processing_time
            self.config["sample_rate"] = int(sr)

            if output_path:
                import soundfile as sf
                import numpy as _np
                _arr = _np.asarray(audio_np, dtype=_np.float32)
                _m = float(_np.max(_np.abs(_arr))) if _arr.size else 0.0
                if _m > 1.0:
                    _arr = (_arr / _m).astype(_np.float32)
                _arr = _arr.clip(-1.0, 1.0)
                _pcm16 = (_arr * 32767.0).astype(_np.int16)
                sf.write(output_path, _pcm16, int(sr))

            logger.info(f"TTS生成完成，长度: {len(audio_np)/int(sr):.2f}秒，耗时: {processing_time:.2f}秒")
            return audio_np
            
        except Exception as e:
            logger.error(f"TTS生成失败: {str(e)}")
            self._performance_stats["total_errors"] += 1
            traceback.print_exc()
            raise
        finally:
            # 定期清理缓存
            if self._cache_access_count % 10 == 0:
                self._cleanup_caches()
            
            # 清理资源
            self._clean_resources()
    
    def get_performance_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取性能统计信息
        
        Returns:
            性能统计字典
        """
        stats = self._performance_stats.copy()
        if stats["total_requests"] > 0:
            stats["avg_time_per_request"] = stats["total_time"] / stats["total_requests"]
            stats["error_rate"] = stats["total_errors"] / stats["total_requests"]
        else:
            stats["avg_time_per_request"] = 0
            stats["error_rate"] = 0
        
        return stats
    
    async def release(self):
        """
        释放所有资源
        """
        async with self._lock:
            try:
                logger.info("开始释放优化版GPT-SoVITS引擎资源...")
                
                # 清空缓存
                self._ref_embedding_cache.clear()
                self._ref_spepc_cache.clear()
                self._tts_result_cache.clear()
                
                # 释放模型资源
                self._tts_model = None
                self._vq_model = None
                self._ssl_model = None
                self._sv_cn_model = None
                self._hps = None
                self._inference_webui = None
                
                # 清理CUDA缓存
                self._clean_resources()
                
                # 重置状态
                self._is_initialized = False
                
                logger.info("优化版GPT-SoVITS引擎资源已完全释放")
                
            except Exception as e:
                logger.error(f"释放资源时出错: {str(e)}")
                traceback.print_exc()

    async def shutdown(self):
        await self.release()

    async def synthesize_to_file(self, text: str, output_path: str, **kwargs):
        audio_np = await self.synthesize(text, **kwargs)
        import soundfile as sf
        import numpy as _np
        _arr = _np.asarray(audio_np, dtype=_np.float32)
        _m = float(_np.max(_np.abs(_arr))) if _arr.size else 0.0
        if _m > 1.0:
            _arr = (_arr / _m).astype(_np.float32)
        _arr = _arr.clip(-1.0, 1.0)
        _pcm16 = (_arr * 32767.0).astype(_np.int16)
        sf.write(output_path, _pcm16, int(self.config["sample_rate"]))

# 全局引擎实例
_optimized_engine = None

def get_optimized_engine(config: Optional[Dict[str, any]] = None) -> OptimizedGPTSoVITSEngine:
    """
    获取优化版引擎实例
    
    Args:
        config: 引擎配置
        
    Returns:
        优化版引擎实例
    """
    global _optimized_engine
    
    if _optimized_engine is None:
        _optimized_engine = OptimizedGPTSoVITSEngine(config)
    
    return _optimized_engine

def release_optimized_engine():
    """
    释放优化版引擎实例
    """
    global _optimized_engine
    
    if _optimized_engine:
        # 异步释放资源
        loop = asyncio.get_event_loop()
        loop.run_until_complete(_optimized_engine.release())
        _optimized_engine = None
