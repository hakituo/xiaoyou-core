# -*- coding: utf-8 -*-
"""
GPT-SoVITS 路径配置
此文件由 setup_gpt_sovits_path.py 自动生成
生成时间: 2025-11-19 23:52:38
"""

import os
import sys
import importlib.util

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
default_models_dir = os.path.join(project_root, "models")
env_models_dir = os.environ.get("XIAOYOU_MODEL_DIR", default_models_dir)
candidate_roots = [
    os.path.join(env_models_dir, "tts", "GPT-SoVITS-v2pro-20250604"),
    r"d:/AI/xiaoyou-core/models/tts/GPT-SoVITS-v2pro-20250604",
    os.path.join(default_models_dir, "tts", "GPT-SoVITS-v2pro-20250604"),
]
GPT_SOVITS_ROOT = next((p for p in candidate_roots if os.path.isdir(p)), candidate_roots[0])

# 确保GPT-SoVITS根目录在Python路径中
if GPT_SOVITS_ROOT not in sys.path:
    sys.path.insert(0, GPT_SOVITS_ROOT)
    
# 确保GPT_SoVITS包目录在Python路径中，使得 `import text` 可用
TEXT_MODEL_DIR = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS")
if TEXT_MODEL_DIR not in sys.path:
    sys.path.insert(0, TEXT_MODEL_DIR)

ERES2NET_DIRS = [
    os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS", "eres2net"),
    os.path.join(GPT_SOVITS_ROOT, "GPT_SOVITS", "eres2net"),
]
for d in ERES2NET_DIRS:
    if os.path.isdir(d) and d not in sys.path:
        sys.path.insert(0, d)

# 预训练模型目录（兼容大小写差异）
_pm_candidates = [
    os.path.join(GPT_SOVITS_ROOT, "pretrained_models"),
    os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS", "pretrained_models"),
    os.path.join(GPT_SOVITS_ROOT, "GPT_SOVITS", "pretrained_models"),
]
_pm_dir = next((p for p in _pm_candidates if os.path.isdir(p)), None)
if _pm_dir is None:
    try:
        for _root, _dirs, _files in os.walk(GPT_SOVITS_ROOT):
            for _d in _dirs:
                if _d.lower() == "pretrained_models":
                    _pm_dir = os.path.join(_root, _d)
                    raise StopIteration
    except StopIteration:
        pass
PRETRAINED_MODELS_DIR = _pm_dir or _pm_candidates[0]

# v2Pro模型路径
V2PRO_MODELS_DIR = os.path.join(PRETRAINED_MODELS_DIR, "v2Pro")

# 说话人编码器模型路径
SPEAKER_ENCODER_PATH = os.path.join(PRETRAINED_MODELS_DIR, "sv", "pretrained_eres2netv2w24s4ep4.ckpt")

# 路径有效性检查
def check_paths():
    """检查所有路径是否存在"""
    paths = {
        "GPT_SOVITS_ROOT": GPT_SOVITS_ROOT,
        "PRETRAINED_MODELS_DIR": PRETRAINED_MODELS_DIR,
        "V2PRO_MODELS_DIR": V2PRO_MODELS_DIR,
        "SPEAKER_ENCODER_PATH": SPEAKER_ENCODER_PATH,
        "TEXT_MODEL_DIR": TEXT_MODEL_DIR
    }
    
    missing_paths = []
    for name, path in paths.items():
        if name.endswith('_DIR') and not os.path.isdir(path):
            missing_paths.append(name + ": " + path)
        elif name.endswith('_PATH') and not os.path.isfile(path):
            missing_paths.append(name + ": " + path)
    
    return missing_paths

def ensure_gpt_sovits_import():
    """
    确保GPT_SOVITS模块可以被导入
    首先尝试直接导入，如果失败则使用importlib.util动态加载
    返回: 成功加载的GPT_SOVITS模块或None
    """
    # 检查是否已经在sys.modules中
    for name in ("GPT_SoVITS", "GPT_SOVITS"):
        if name in sys.modules:
            return sys.modules[name]
    
    # 尝试直接导入
    try:
        import GPT_SoVITS
        return GPT_SoVITS
    except ImportError:
        try:
            import GPT_SOVITS
            return GPT_SOVITS
        except ImportError:
            pass
    
    # 尝试动态加载
    gpt_sovits_dir = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS")
    init_file = os.path.join(gpt_sovits_dir, "__init__.py")
    
    if os.path.exists(init_file):
        try:
            spec = importlib.util.spec_from_file_location("GPT_SoVITS", init_file)
            if spec is not None:
                module = importlib.util.module_from_spec(spec)
                # 添加到sys.modules
                sys.modules["GPT_SoVITS"] = module
                sys.modules["GPT_SOVITS"] = module  # 兼容不同大小写调用
                # 执行模块
                spec.loader.exec_module(module)
                return module
        except Exception:
            pass
    
    return None

def import_gpt_sovits_module(module_name):
    """
    导入GPT_SOVITS的特定子模块，支持Python模块和包目录
    参数:
        module_name: 子模块名称，如 "text", "models", "utils"
    返回:
        成功加载的子模块或None
    """
    # 确保基本模块已导入
    gpt_sovits = ensure_gpt_sovits_import()
    if gpt_sovits is None:
        return None

    old_cwd = os.getcwd()
    cwd_changed = False
    try:
        os.chdir(GPT_SOVITS_ROOT)
        cwd_changed = True
    except Exception:
        pass
    
    # 模块可能的路径
    module_file = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS", module_name + ".py")
    module_dir = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS", module_name)
    init_file = os.path.join(module_dir, "__init__.py")
    
    # 方法1: 尝试直接导入（推荐）
    for prefix in ("GPT_SoVITS.", "GPT_SOVITS."):
        try:
            full_module_name = prefix + module_name
            module = importlib.import_module(full_module_name)
            return module
        except ImportError:
            pass
    
    # 方法2: 处理Python文件模块
    if os.path.exists(module_file):
        try:
            # 使用完整的模块名称进行加载
            spec = importlib.util.spec_from_file_location("GPT_SoVITS." + module_name, module_file)
            if spec is not None:
                module = importlib.util.module_from_spec(spec)
                sys.modules["GPT_SoVITS." + module_name] = module
                sys.modules["GPT_SOVITS." + module_name] = module
                spec.loader.exec_module(module)
                # 添加到GPT_SOVITS模块的属性中
                setattr(gpt_sovits, module_name, module)
                return module
        except Exception:
            pass
    
    # 方法3: 处理包目录模块
    if os.path.exists(module_dir) and os.path.exists(init_file):
        try:
            # 首先确保模块目录在sys.path中
            if module_dir not in sys.path:
                sys.path.insert(0, module_dir)
            
            # 从__init__.py加载
            spec = importlib.util.spec_from_file_location("GPT_SoVITS." + module_name, init_file)
            if spec is not None:
                module = importlib.util.module_from_spec(spec)
                sys.modules["GPT_SoVITS." + module_name] = module
                sys.modules["GPT_SOVITS." + module_name] = module
                spec.loader.exec_module(module)
                # 添加到GPT_SOVITS模块的属性中
                setattr(gpt_sovits, module_name, module)
                return module
        except Exception:
            pass
    
    # 方法4: 特殊处理text模块（可能需要添加其父目录）
    if module_name == "text" and os.path.exists(module_dir):
        try:
            # 确保TEXT_MODEL_DIR在Python路径中
            text_model_dir = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS")
            if text_model_dir not in sys.path:
                sys.path.insert(0, text_model_dir)
            
            # 尝试再次导入
            try:
                module = importlib.import_module(module_name)
                sys.modules["GPT_SoVITS." + module_name] = module
                sys.modules["GPT_SOVITS." + module_name] = module
                setattr(gpt_sovits, module_name, module)
                return module
            except ImportError:
                # 从目录直接加载
                text_dir = os.path.join(GPT_SOVITS_ROOT, "GPT_SoVITS", "text")
                if os.path.exists(os.path.join(text_dir, "__init__.py")):
                    spec = importlib.util.spec_from_file_location("text", os.path.join(text_dir, "__init__.py"))
                    if spec is not None:
                        module = importlib.util.module_from_spec(spec)
                        sys.modules["text"] = module
                        sys.modules["GPT_SoVITS.text"] = module
                        sys.modules["GPT_SOVITS.text"] = module
                        spec.loader.exec_module(module)
                        setattr(gpt_sovits, "text", module)
                        return module
        except Exception:
            pass
    
    if cwd_changed:
        try:
            os.chdir(old_cwd)
        except Exception:
            pass
    return None

# 确保中文分词模型路径正确
if hasattr(sys, 'argv') and '--debug' in sys.argv:
    print("[DEBUG] GPT_SOVITS_ROOT: " + GPT_SOVITS_ROOT)
    print("[DEBUG] TEXT_MODEL_DIR exists: " + str(os.path.exists(TEXT_MODEL_DIR)))
