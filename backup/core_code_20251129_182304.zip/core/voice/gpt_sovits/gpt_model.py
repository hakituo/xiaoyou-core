# -*- coding: utf-8 -*-
"""
GPT-SoVITS 2 Pro GPT模型封装
负责GPT声学模型的加载、推理和管理
"""

import os
import sys
import logging
import torch
import numpy as np
from typing import Optional, List, Dict, Any, Union
import time

logger = logging.getLogger(__name__)


class GPTModel:
    """
    GPT声学模型封装类
    处理模型加载、推理和资源管理
    """
    
    def __init__(self, model_path: str, device: Optional[str] = None, use_half: bool = True):
        """
        初始化GPT模型
        
        Args:
            model_path: 模型文件路径
            device: 运行设备，默认为cuda（如果可用）或cpu
            use_half: 是否使用半精度计算
        """
        # 设置设备
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 设置精度
        self.use_half = False  # 暂时禁用半精度以避免兼容性问题
        if use_half and self.device == 'cuda':
            try:
                # 兼容不同PyTorch版本的compute_capability获取方式
                props = torch.cuda.get_device_properties(0)
                compute_capability = getattr(props, 'compute_capability', (0, 0))
                if isinstance(compute_capability, tuple) and len(compute_capability) > 0 and compute_capability[0] >= 7:
                    self.use_half = True
            except Exception as e:
                logger.warning(f"无法获取GPU计算能力，禁用半精度: {str(e)}")
        self.dtype = torch.float16 if self.use_half else torch.float32
        
        # 模型路径
        self.model_path = model_path
        
        # 模型实例
        self.model = None
        self.hps = None
        
        # 初始化状态
        self._is_initialized = False
        
        # 性能统计
        self._performance_stats = {
            'total_inferences': 0,
            'total_time': 0.0,
            'avg_time': 0.0
        }
    
    def initialize(self) -> bool:
        """
        初始化模型，加载权重
        
        Returns:
            bool: 初始化是否成功
        """
        if self._is_initialized:
            logger.info("GPT模型已经初始化")
            return True
        
        try:
            logger.info(f"开始初始化GPT模型，设备: {self.device}，精度: {'float16' if self.use_half else 'float32'}")
            
            # 检查模型路径是否为空
            if not self.model_path:
                logger.error("GPT模型路径为空")
                # 尝试使用默认模型路径
                default_model_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "models", "tts", "GPT-SoVITS-v2pro-20250604")
                default_model_path = os.path.join(default_model_dir, "model_ckpt_steps_1000000.ckpt")  # 假设的模型文件名
                
                if os.path.exists(default_model_path):
                    self.model_path = default_model_path
                    logger.info(f"使用默认模型路径: {self.model_path}")
                else:
                    logger.warning(f"默认模型路径不存在: {default_model_path}")
                    # 检查模型目录是否存在
                    if os.path.exists(default_model_dir):
                        logger.info(f"模型目录存在，包含文件: {os.listdir(default_model_dir)}")
                    else:
                        logger.error(f"模型目录不存在: {default_model_dir}")
            
            # 验证模型路径
            if self.model_path and os.path.exists(self.model_path):
                logger.info(f"模型文件存在: {self.model_path}")
            else:
                logger.error(f"GPT模型文件不存在: {self.model_path}")
                return False
            
            # 延迟导入以避免依赖问题
            import sys
            import os
            import importlib.util
            
            # 计算GPT-SoVITS根目录路径
            current_file_dir = os.path.dirname(os.path.abspath(__file__))
            core_dir = os.path.dirname(os.path.dirname(current_file_dir))  # 向上两级到达core目录
            project_root = os.path.dirname(core_dir)  # 向上一级到达项目根目录
            gpt_sovits_root = os.path.join(project_root, "models", "tts", "GPT-SoVITS-v2pro-20250604")
            gpt_sovits_package = os.path.join(gpt_sovits_root, "GPT_SOVITS")
            text_module_dir = os.path.join(gpt_sovits_package, "text")
            
            # 验证路径存在性
            logger.info(f"计算的GPT-SoVITS根目录: {gpt_sovits_root}")
            logger.info(f"GPT-SoVITS根目录存在: {os.path.exists(gpt_sovits_root)}")
            logger.info(f"计算的GPT_SoVITS包目录: {gpt_sovits_package}")
            logger.info(f"GPT_SoVITS包目录存在: {os.path.exists(gpt_sovits_package)}")
            logger.info(f"计算的text模块目录: {text_module_dir}")
            logger.info(f"text模块目录存在: {os.path.exists(text_module_dir)}")
            
            # 检查关键文件是否存在
            init_file = os.path.join(gpt_sovits_package, "__init__.py")
            inference_webui_path = os.path.join(gpt_sovits_package, "inference_webui.py")
            config_path = os.path.join(gpt_sovits_package, "config.py")
            
            logger.info(f"GPT_SOVITS包__init__.py文件存在: {os.path.exists(init_file)}")
            logger.info(f"inference_webui.py文件存在: {os.path.exists(inference_webui_path)}")
            logger.info(f"config.py文件存在: {os.path.exists(config_path)}")
            
            # 方法1: 创建完全隔离的导入环境
            inference_webui = None
            original_sys_path = sys.path.copy()
            
            try:
                logger.info("尝试方法1: 创建隔离的导入环境导入GPT_SOVITS模块")
                
                # 清除可能冲突的模块缓存
                modules_to_backup = {}
                for module_name in list(sys.modules.keys()):
                    if module_name == 'config' or module_name.startswith('GPT_SOVITS'):
                        modules_to_backup[module_name] = sys.modules[module_name]
                        del sys.modules[module_name]
                
                # 创建一个新的路径列表，只包含GPT_SOVITS相关路径和Python标准库路径
                new_sys_path = []
                # 添加GPT_SOVITS包目录
                if os.path.exists(gpt_sovits_package):
                    new_sys_path.append(gpt_sovits_package)
                # 添加GPT-SoVITS根目录
                if os.path.exists(gpt_sovits_root):
                    new_sys_path.append(gpt_sovits_root)
                # 添加text模块目录
                if os.path.exists(text_module_dir):
                    new_sys_path.append(text_module_dir)
                
                # 添加Python标准库路径（跳过项目根目录和其他可能冲突的路径）
                for path in original_sys_path:
                    if 'site-packages' in path or 'python39.zip' in path or 'DLLs' in path or 'lib' in path:
                        new_sys_path.append(path)
                
                # 临时替换sys.path
                sys.path = new_sys_path
                
                # 尝试导入GPT_SOVITS模块
                logger.info("在隔离环境中尝试导入GPT_SOVITS.inference_webui")
                import GPT_SOVITS.inference_webui as inference_webui
                logger.info("成功在隔离环境中导入GPT_SOVITS模块")
                
            except ImportError as e:
                logger.error(f"方法1失败: {e}")
                # 恢复原始环境
                sys.path = original_sys_path.copy()
                # 恢复备份的模块
                for module_name, module in modules_to_backup.items():
                    sys.modules[module_name] = module
            
            # 如果方法1失败，尝试方法2: 模拟config模块并直接导入
            if inference_webui is None:
                try:
                    logger.info("尝试方法2: 模拟config模块并直接导入文件")
                    
                    if os.path.exists(inference_webui_path):
                        # 创建一个隔离的模块导入环境
                        sys.path = original_sys_path.copy()
                        
                        # 只保留必要的路径
                        sys.path = [
                            gpt_sovits_package,
                            gpt_sovits_root,
                            text_module_dir
                        ]
                        
                        # 添加Python标准库路径
                        for path in original_sys_path:
                            if 'site-packages' in path or 'python39.zip' in path or 'DLLs' in path or 'lib' in path:
                                sys.path.append(path)
                        
                        # 清除可能冲突的模块
                        modules_to_backup = {}
                        for module_name in list(sys.modules.keys()):
                            if module_name == 'config' or module_name == 'inference_webui':
                                modules_to_backup[module_name] = sys.modules[module_name]
                                del sys.modules[module_name]
                        
                        # 创建一个模拟的config模块以避免导入冲突
                        class MockConfig:
                            @staticmethod
                            def change_choices(*args, **kwargs):
                                logger.info(f"MockConfig.change_choices called with: {args}, {kwargs}")
                                return {}
                        
                        sys.modules['config'] = MockConfig()
                        
                        # 直接导入文件
                        spec = importlib.util.spec_from_file_location("inference_webui", inference_webui_path)
                        inference_webui = importlib.util.module_from_spec(spec)
                        sys.modules['inference_webui'] = inference_webui
                        spec.loader.exec_module(inference_webui)
                        
                        logger.info("成功通过直接文件导入并模拟config模块")
                    else:
                        logger.error(f"inference_webui.py文件不存在: {inference_webui_path}")
                        return False
                except Exception as e:
                    logger.error(f"方法2失败: {e}")
                    # 恢复原始路径
                    sys.path = original_sys_path.copy()
                    # 恢复备份的模块
                    for module_name, module in modules_to_backup.items():
                        sys.modules[module_name] = module
                    return False
            
            # 方法3: 如果前两种方法都失败，创建临时包装脚本
            if inference_webui is None:
                try:
                    logger.info("尝试方法3: 创建临时包装脚本")
                    
                    # 创建临时包装脚本
                    wrapper_script = os.path.join(current_file_dir, '_gpt_sovits_wrapper.py')
                    with open(wrapper_script, 'w', encoding='utf-8') as f:
                        f.write(f'''
import sys
import os

# 设置隔离的Python路径
sys.path.insert(0, r'{gpt_sovits_package}')
sys.path.insert(1, r'{gpt_sovits_root}')
sys.path.insert(2, r'{text_module_dir}')

# 移除可能导致冲突的路径
paths_to_remove = []
for path in sys.path:
    if r'{project_root}' in path and path not in [r'{gpt_sovits_package}', r'{gpt_sovits_root}', r'{text_module_dir}']:
        paths_to_remove.append(path)

for path in paths_to_remove:
    if path in sys.path:
        sys.path.remove(path)

# 尝试导入GPT_SOVITS模块
try:
    # 首先尝试创建一个简单的mock config
    class MockConfig:
        @staticmethod
        def change_choices(*args, **kwargs):
            return dict()
    
    # 将mock config放入sys.modules
    sys.modules['config'] = MockConfig()
    
    import GPT_SOVITS.inference_webui as inference_webui
    print("IMPORT_SUCCESS")
except Exception as e:
    print(f"IMPORT_ERROR:{str(e)}")
                        ''')
                
                    # 执行临时脚本
                    import subprocess
                    result = subprocess.run(
                        [sys.executable, wrapper_script],
                        capture_output=True,
                        text=True,
                        cwd=current_file_dir
                    )
                    
                    # 删除临时脚本
                    if os.path.exists(wrapper_script):
                        os.remove(wrapper_script)
                    
                    # 检查结果
                    if "IMPORT_SUCCESS" in result.stdout:
                        logger.info("临时脚本成功导入GPT_SOVITS模块")
                        # 重新尝试方法2，但这次我们知道导入是可能的
                        try:
                            # 创建隔离环境
                            sys.path = original_sys_path.copy()
                            
                            # 清除可能冲突的模块
                            modules_to_backup = {}
                            for module_name in list(sys.modules.keys()):
                                if module_name == 'config' or module_name.startswith('GPT_SOVITS'):
                                    modules_to_backup[module_name] = sys.modules[module_name]
                                    del sys.modules[module_name]
                            
                            # 设置路径
                            sys.path = [
                                gpt_sovits_package,
                                gpt_sovits_root,
                                text_module_dir
                            ] + [p for p in original_sys_path if 'site-packages' in p]
                            
                            # 创建mock config
                            class MockConfig:
                                @staticmethod
                                def change_choices(*args, **kwargs):
                                    return {}
                            
                            sys.modules['config'] = MockConfig()
                            
                            # 导入GPT_SOVITS
                            import GPT_SOVITS.inference_webui as inference_webui
                            logger.info("成功导入GPT_SOVITS模块")
                        except Exception as e:
                            logger.error(f"方法3后续导入失败: {e}")
                            # 恢复环境
                            sys.path = original_sys_path.copy()
                            for module_name, module in modules_to_backup.items():
                                sys.modules[module_name] = module
                    else:
                        error_msg = result.stdout.replace("IMPORT_ERROR:", "").strip() or str(result.stderr)
                        logger.error(f"临时脚本导入失败: {error_msg}")
                        return False
                except Exception as e:
                    logger.error(f"方法3执行失败: {e}")
                    return False
            
            # 确保inference_webui已成功导入
            if inference_webui is None:
                logger.error("所有导入方法都失败")
                return False
                 
            # 恢复原始的sys.path，避免长期污染
            sys.path = original_sys_path.copy()
            
            # 记录加载时间
            start_time = time.time()
            
            logger.info(f"尝试加载模型权重: {self.model_path}")
            try:
                # 加载模型
                # 注意：这里需要使用inference_webui模块来加载模型
                # 即使sys.path已恢复，inference_webui模块实例仍可用
                if hasattr(inference_webui, 'change_gpt_weights'):
                    inference_webui.change_gpt_weights(self.model_path, self.device)
                    logger.info("模型权重加载成功")
                else:
                    logger.error("inference_webui模块没有change_gpt_weights方法")
                    return False
                
                # 获取模型实例
                if hasattr(inference_webui, 't2s_model') and hasattr(inference_webui, 'hps'):
                    self.model = inference_webui.t2s_model
                    self.hps = inference_webui.hps
                else:
                    logger.error("inference_webui模块没有t2s_model或hps属性")
                    return False
                
                if self.model is None:
                    logger.error("获取模型实例失败: model is None")
                    return False
                     
                logger.info("成功获取模型实例")
            except Exception as e:
                logger.error(f"加载模型权重时出错: {str(e)}")
                import traceback
                traceback.print_exc()
                return False
            
            # 移动模型到指定设备和精度
            if self.model:
                logger.info(f"移动模型到设备: {self.device}，精度: {'float16' if self.use_half else 'float32'}")
                self.model.to(self.device)
                if self.use_half:
                    self.model.half()
                self.model.eval()
            
            load_time = time.time() - start_time
            logger.info(f"GPT模型加载成功，耗时: {load_time:.2f}秒")
            
            self._is_initialized = True
            return True
            
        except Exception as e:
            logger.error(f"GPT模型初始化失败: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
    
    def infer(self, phoneme_ids: torch.Tensor, phoneme_lengths: torch.Tensor,
              bert_embeddings: torch.Tensor, prompt_embeddings: Optional[torch.Tensor] = None,
              top_k: int = 5, top_p: float = 0.85, temperature: float = 0.7,
              early_stop_num: int = 24000 * 30) -> Dict[str, Any]:
        """
        执行GPT模型推理，生成语义特征
        
        Args:
            phoneme_ids: 音素ID张量，形状 [batch_size, seq_len]
            phoneme_lengths: 音素长度张量，形状 [batch_size]
            bert_embeddings: BERT特征张量，形状 [batch_size, seq_len, bert_dim]
            prompt_embeddings: 提示嵌入向量，可选
            top_k: 采样时保留的最高概率token数量
            top_p: 采样的累积概率阈值
            temperature: 采样温度参数
            early_stop_num: 最大生成长度
            
        Returns:
            Dict: 包含生成的语义特征和其他信息的字典
        """
        if not self._is_initialized:
            raise RuntimeError("GPT模型尚未初始化，请先调用initialize方法")
        
        try:
            # 移动输入到正确的设备和精度
            phoneme_ids = phoneme_ids.to(self.device)
            phoneme_lengths = phoneme_lengths.to(self.device)
            bert_embeddings = bert_embeddings.to(self.device)
            
            if self.use_half:
                bert_embeddings = bert_embeddings.half()
                if prompt_embeddings is not None:
                    prompt_embeddings = prompt_embeddings.half().to(self.device)
            
            # 记录推理开始时间
            start_time = time.time()
            
            # 执行推理
            with torch.no_grad():
                pred_semantic, idx = self.model.model.infer_panel(
                    phoneme_ids,
                    phoneme_lengths,
                    prompt_embeddings,
                    bert_embeddings,
                    top_k=top_k,
                    top_p=top_p,
                    temperature=temperature,
                    early_stop_num=early_stop_num
                )
                
                # 调整输出形状
                pred_semantic = pred_semantic[:, -idx:].unsqueeze(0)
            
            # 计算推理时间
            infer_time = time.time() - start_time
            
            # 更新性能统计
            self._update_performance_stats(infer_time)
            
            return {
                'semantic_features': pred_semantic,
                'generated_length': idx,
                'infer_time': infer_time,
                'device': str(self.device),
                'dtype': str(self.dtype)
            }
            
        except Exception as e:
            logger.error(f"GPT模型推理失败: {str(e)}")
            import traceback
            traceback.print_exc()
            raise
    
    def _update_performance_stats(self, infer_time: float):
        """
        更新性能统计信息
        
        Args:
            infer_time: 本次推理时间
        """
        self._performance_stats['total_inferences'] += 1
        self._performance_stats['total_time'] += infer_time
        self._performance_stats['avg_time'] = self._performance_stats['total_time'] / self._performance_stats['total_inferences']
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """
        获取性能统计信息
        
        Returns:
            Dict: 性能统计信息
        """
        return self._performance_stats.copy()
    
    def update_device(self, device: str) -> bool:
        """
        更新运行设备
        
        Args:
            device: 新的设备（'cuda', 'cpu'等）
            
        Returns:
            bool: 更新是否成功
        """
        try:
            if device == self.device:
                logger.info(f"设备已经是 {device}")
                return True
            
            logger.info(f"更新GPT模型设备: {self.device} -> {device}")
            
            # 更新设备信息
            self.device = device
            self.use_half = device == 'cuda' and torch.cuda.get_device_properties(0).compute_capability[0] >= 7
            self.dtype = torch.float16 if self.use_half else torch.float32
            
            # 如果模型已初始化，移动模型到新设备
            if self._is_initialized and self.model:
                self.model.to(self.device)
                if self.use_half:
                    self.model.half()
                else:
                    self.model.float()
                
            logger.info(f"GPT模型设备更新成功: {device}")
            return True
            
        except Exception as e:
            logger.error(f"更新GPT模型设备失败: {str(e)}")
            return False
    
    def reload(self, model_path: Optional[str] = None) -> bool:
        """
        重新加载模型
        
        Args:
            model_path: 新的模型路径，如果为None则使用当前路径
            
        Returns:
            bool: 重新加载是否成功
        """
        try:
            # 释放当前模型资源
            self.release()
            
            # 更新模型路径（如果提供了新路径）
            if model_path:
                self.model_path = model_path
            
            # 重新初始化
            return self.initialize()
            
        except Exception as e:
            logger.error(f"重新加载GPT模型失败: {str(e)}")
            return False
    
    def release(self):
        """
        释放模型资源
        """
        if hasattr(self, 'model') and self.model is not None:
            try:
                # 将模型移到CPU并释放
                self.model.cpu()
                del self.model
                self.model = None
                
                # 清理CUDA缓存
                if self.device == 'cuda':
                    torch.cuda.empty_cache()
                    
                logger.info("GPT模型资源已释放")
                
            except Exception as e:
                logger.error(f"释放GPT模型资源时出错: {str(e)}")
        
        self._is_initialized = False
    
    def __enter__(self):
        """
        上下文管理器入口
        """
        self.initialize()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        上下文管理器退出
        """
        self.release()


class GPTModelManager:
    """
    GPT模型管理器
    支持多模型管理、热切换等功能
    """
    
    def __init__(self):
        """
        初始化模型管理器
        """
        # 模型实例字典
        self._models = {}
        
        # 当前活跃的模型
        self._active_model_id = None
        
        # 默认配置
        self._default_config = {
            'device': 'cuda' if torch.cuda.is_available() else 'cpu',
            'use_half': True
        }
    
    def register_model(self, model_id: str, model_path: str, **kwargs) -> bool:
        """
        注册一个新的GPT模型
        
        Args:
            model_id: 模型标识符
            model_path: 模型文件路径
            **kwargs: 模型配置参数
            
        Returns:
            bool: 注册是否成功
        """
        try:
            # 合并配置
            config = {**self._default_config, **kwargs}
            
            logger.info(f"注册GPT模型: {model_id}，路径: {model_path}")
            
            # 创建模型实例
            model = GPTModel(model_path, **config)
            
            # 存储模型
            self._models[model_id] = model
            
            # 如果是第一个注册的模型，设置为活跃模型
            if self._active_model_id is None:
                self._active_model_id = model_id
                logger.info(f"设置模型 {model_id} 为活跃模型")
            
            return True
            
        except Exception as e:
            logger.error(f"注册GPT模型 {model_id} 失败: {str(e)}")
            return False
    
    def load_model(self, model_id: str) -> bool:
        """
        加载指定的模型
        
        Args:
            model_id: 模型标识符
            
        Returns:
            bool: 加载是否成功
        """
        if model_id not in self._models:
            logger.error(f"模型 {model_id} 未注册")
            return False
        
        return self._models[model_id].initialize()
    
    def switch_model(self, model_id: str) -> bool:
        """
        切换到指定的模型
        
        Args:
            model_id: 模型标识符
            
        Returns:
            bool: 切换是否成功
        """
        if model_id not in self._models:
            logger.error(f"模型 {model_id} 未注册")
            return False
        
        # 确保目标模型已加载
        if not self._models[model_id]._is_initialized:
            if not self._models[model_id].initialize():
                return False
        
        # 更新活跃模型
        self._active_model_id = model_id
        logger.info(f"已切换到模型: {model_id}")
        
        return True
    
    def get_active_model(self) -> Optional[GPTModel]:
        """
        获取当前活跃的模型
        
        Returns:
            GPTModel: 活跃的模型实例，如果没有则返回None
        """
        if self._active_model_id is None:
            return None
        return self._models.get(self._active_model_id)
    
    def unregister_model(self, model_id: str) -> bool:
        """
        注销指定的模型
        
        Args:
            model_id: 模型标识符
            
        Returns:
            bool: 注销是否成功
        """
        if model_id not in self._models:
            logger.warning(f"模型 {model_id} 未注册，无法注销")
            return False
        
        # 释放模型资源
        self._models[model_id].release()
        
        # 从字典中删除
        del self._models[model_id]
        
        # 如果删除的是活跃模型，选择另一个模型作为活跃模型
        if self._active_model_id == model_id:
            self._active_model_id = next(iter(self._models.keys()), None)
            if self._active_model_id:
                logger.info(f"已切换到新的活跃模型: {self._active_model_id}")
            else:
                logger.info("没有活跃模型")
        
        logger.info(f"模型 {model_id} 已注销")
        return True
    
    def list_models(self) -> Dict[str, Dict[str, Any]]:
        """
        列出所有注册的模型
        
        Returns:
            Dict: 模型信息字典
        """
        result = {}
        for model_id, model in self._models.items():
            result[model_id] = {
                'path': model.model_path,
                'device': model.device,
                'is_initialized': model._is_initialized,
                'is_active': model_id == self._active_model_id,
                'performance': model.get_performance_stats()
            }
        return result
    
    def release_all(self):
        """
        释放所有模型资源
        """
        for model_id in list(self._models.keys()):
            self._models[model_id].release()
            del self._models[model_id]
        
        self._active_model_id = None
        logger.info("所有GPT模型资源已释放")


# 创建全局模型管理器实例
_gpt_model_manager = None

def get_gpt_model_manager() -> GPTModelManager:
    """
    获取全局的GPT模型管理器实例
    
    Returns:
        GPTModelManager实例
    """
    global _gpt_model_manager
    if _gpt_model_manager is None:
        _gpt_model_manager = GPTModelManager()
    return _gpt_model_manager