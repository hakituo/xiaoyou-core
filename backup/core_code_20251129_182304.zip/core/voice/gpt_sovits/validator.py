# -*- coding: utf-8 -*-
"""
GPT-SoVITS 2Pro TTS参数验证器
提供全面的参数检查和错误处理机制
"""

import os
import re
import logging
from typing import Dict, List, Optional, Union, Tuple
import soundfile as sf
import numpy as np

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("GPTSoVITS-Validator")

# 自定义异常类
class TTSValidationError(Exception):
    """
    TTS验证错误异常类
    """
    def __init__(self, message: str, error_code: str = "VALIDATION_ERROR"):
        self.message = message
        self.error_code = error_code
        super().__init__(f"[{error_code}] {message}")

class FileNotFoundError(TTSValidationError):
    """
    文件未找到错误
    """
    def __init__(self, message: str):
        super().__init__(message, "FILE_NOT_FOUND")

class InvalidParameterError(TTSValidationError):
    """
    参数无效错误
    """
    def __init__(self, message: str):
        super().__init__(message, "INVALID_PARAMETER")

class AudioFormatError(TTSValidationError):
    """
    音频格式错误
    """
    def __init__(self, message: str):
        super().__init__(message, "AUDIO_FORMAT_ERROR")

class TextValidationError(TTSValidationError):
    """
    文本验证错误
    """
    def __init__(self, message: str):
        super().__init__(message, "TEXT_VALIDATION_ERROR")

class TTSPreprocessor:
    """
    TTS预处理器，负责输入清理和标准化
    """
    
    @staticmethod
    def clean_text(text: str) -> str:
        """
        清理文本，移除多余的空白字符和控制字符
        
        Args:
            text: 原始文本
            
        Returns:
            清理后的文本
        """
        # 移除控制字符（保留换行和制表符）
        text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)
        
        # 将多个空白字符替换为单个空格
        text = re.sub(r'\s+', ' ', text)
        
        # 移除首尾空白
        text = text.strip()
        
        return text
    
    @staticmethod
    def normalize_text(text: str) -> str:
        """
        标准化文本，处理常见的文本格式问题
        
        Args:
            text: 清理后的文本
            
        Returns:
            标准化后的文本
        """
        # 替换全角标点为半角
        full_to_half = {
            '，': ',', '。': '.', '！': '!', '？': '?',
            '；': ';', '：': ':', '“': '"', '”': '"',
            '‘': "'", '’': "'", '（': '(', '）': ')',
            '【': '[', '】': ']', '《': '<', '》': '>'
        }
        
        for full, half in full_to_half.items():
            text = text.replace(full, half)
        
        return text
    
    @staticmethod
    def detect_language(text: str) -> str:
        """
        检测文本语言
        
        Args:
            text: 文本内容
            
        Returns:
            检测到的语言代码（"zh"、"en"或"mix"）
        """
        # 检测中文字符
        has_chinese = bool(re.search(r'[\u4e00-\u9fff]', text))
        
        # 检测英文字符
        has_english = bool(re.search(r'[a-zA-Z]', text))
        
        if has_chinese and has_english:
            return "mix"
        elif has_chinese:
            return "zh"
        elif has_english:
            return "en"
        else:
            # 如果没有检测到中英文字符，默认为混合
            return "mix"

class TTSValidator:
    """
    TTS参数验证器
    实现严格的参数检查和预处理
    """
    
    # 支持的风格编号
    VALID_STYLES = {1, 2, 3, 4}
    
    # 速度范围
    MIN_SPEED = 0.8
    MAX_SPEED = 1.2
    
    # 情绪强度范围
    MIN_EMOTION = 0.0
    MAX_EMOTION = 1.0
    
    # 最大文本长度
    MAX_TEXT_LENGTH = 5000  # 单个请求的最大文本长度
    
    # 支持的音频格式
    SUPPORTED_AUDIO_FORMATS = {".wav", ".mp3", ".flac", ".ogg", ".aac"}
    
    # 推荐的音频采样率
    RECOMMENDED_SAMPLE_RATES = {16000, 24000, 44100, 48000}
    
    def __init__(self, strict_mode: bool = True):
        """
        初始化验证器
        
        Args:
            strict_mode: 是否启用严格模式
        """
        self.strict_mode = strict_mode
        self.preprocessor = TTSPreprocessor()
        
        # 验证结果缓存
        self._validation_cache = {}
    
    def _generate_cache_key(self, *args) -> str:
        """
        生成验证缓存键
        
        Args:
            *args: 缓存键组成部分
            
        Returns:
            缓存键字符串
        """
        return "_".join(str(arg) for arg in args)
    
    def validate_text(self, text: str) -> Tuple[str, str]:
        """
        验证文本输入
        
        Args:
            text: 输入文本
            
        Returns:
            (清理后的文本, 检测到的语言)
            
        Raises:
            TextValidationError: 如果文本验证失败
        """
        # 检查文本是否为空
        if not text or not text.strip():
            raise TextValidationError("文本不能为空")
        
        # 检查文本长度
        if len(text) > self.MAX_TEXT_LENGTH:
            raise TextValidationError(
                f"文本长度超过限制。当前: {len(text)}，最大: {self.MAX_TEXT_LENGTH}"
            )
        
        # 清理和标准化文本
        cleaned_text = self.preprocessor.clean_text(text)
        normalized_text = self.preprocessor.normalize_text(cleaned_text)
        
        # 再次检查清理后的文本
        if not normalized_text or not normalized_text.strip():
            raise TextValidationError("清理后的文本为空，请检查输入")
        
        # 检测语言
        language = self.preprocessor.detect_language(normalized_text)
        
        logger.debug(f"文本验证通过，长度: {len(normalized_text)}, 语言: {language}")
        
        return normalized_text, language
    
    def validate_reference_audio(self, audio_path: str) -> Dict[str, any]:
        """
        验证参考音频
        
        Args:
            audio_path: 音频文件路径
            
        Returns:
            音频元数据
            
        Raises:
            FileNotFoundError: 如果文件不存在
            AudioFormatError: 如果音频格式不支持或无效
        """
        # 检查文件是否存在
        if not os.path.exists(audio_path):
            raise FileNotFoundError("参考音频未找到")
        
        # 检查文件是否为常规文件
        if not os.path.isfile(audio_path):
            raise FileNotFoundError("指定的路径不是一个有效的文件")
        
        # 检查文件扩展名
        file_ext = os.path.splitext(audio_path)[1].lower()
        if file_ext not in self.SUPPORTED_AUDIO_FORMATS:
            raise AudioFormatError(
                f"不支持的音频格式: {file_ext}。支持的格式: {', '.join(self.SUPPORTED_AUDIO_FORMATS)}"
            )
        
        # 尝试打开音频文件以验证格式
        try:
            with sf.SoundFile(audio_path) as audio_file:
                sample_rate = audio_file.samplerate
                channels = audio_file.channels
                frames = audio_file.frames
                duration = frames / sample_rate
                
                # 验证音频属性
                if channels != 1:
                    # 如果是严格模式，要求单声道
                    if self.strict_mode:
                        raise AudioFormatError("参考音频必须是单声道")
                    else:
                        logger.warning("建议使用单声道音频，多声道音频可能会影响效果")
                
                # 检查采样率
                if sample_rate not in self.RECOMMENDED_SAMPLE_RATES:
                    if self.strict_mode:
                        raise AudioFormatError(
                            f"不推荐的采样率: {sample_rate}Hz。推荐采样率: {', '.join(map(str, self.RECOMMENDED_SAMPLE_RATES))}Hz"
                        )
                    else:
                        logger.warning(f"非推荐采样率: {sample_rate}Hz，可能会影响语音质量")
                
                # 检查音频长度
                if duration < 0.5:
                    raise AudioFormatError("参考音频太短（至少需要0.5秒）")
                
                if duration > 60:
                    if self.strict_mode:
                        raise AudioFormatError("参考音频太长（最大60秒）")
                    else:
                        logger.warning("参考音频较长，可能会增加处理时间")
                
                # 返回音频元数据
                return {
                    "sample_rate": sample_rate,
                    "channels": channels,
                    "duration": duration,
                    "frames": frames,
                    "format": file_ext[1:]
                }
                
        except sf.SoundFileError as e:
            raise AudioFormatError(f"音频文件格式无效: {str(e)}")
        except Exception as e:
            raise AudioFormatError(f"读取音频文件失败: {str(e)}")
    
    def validate_parameters(self, style: int, speed: float, emotion: float) -> Dict[str, any]:
        """
        验证TTS参数
        
        Args:
            style: 风格编号
            speed: 语速
            emotion: 情绪强度
            
        Returns:
            验证后的参数
            
        Raises:
            InvalidParameterError: 如果参数无效
        """
        # 验证风格编号
        if style not in self.VALID_STYLES:
            raise InvalidParameterError(
                f"无效的风格编号: {style}。有效的风格编号: {', '.join(map(str, sorted(self.VALID_STYLES)))}"
            )
        
        # 验证语速
        if not self.MIN_SPEED <= speed <= self.MAX_SPEED:
            raise InvalidParameterError(
                f"语速必须在 {self.MIN_SPEED} 到 {self.MAX_SPEED} 之间。当前值: {speed}"
            )
        
        # 验证情绪强度
        if not self.MIN_EMOTION <= emotion <= self.MAX_EMOTION:
            raise InvalidParameterError(
                f"情绪强度必须在 {self.MIN_EMOTION} 到 {self.MAX_EMOTION} 之间。当前值: {emotion}"
            )
        
        # 验证参数组合
        self._validate_parameter_combination(style, emotion)
        
        logger.debug(f"参数验证通过 - 风格: {style}, 语速: {speed}, 情绪: {emotion}")
        
        return {
            "style": style,
            "speed": speed,
            "emotion": emotion
        }
    
    def _validate_parameter_combination(self, style: int, emotion: float):
        """
        验证参数组合的合理性
        
        Args:
            style: 风格编号
            emotion: 情绪强度
            
        Raises:
            InvalidParameterError: 如果参数组合不合理
        """
        # 某些风格在低情绪强度下可能效果不佳
        if style == 4 and emotion < 0.2:
            logger.warning("活泼风格(4)搭配低情绪强度可能效果不佳，建议提高emotion值")
        
        if style == 2 and emotion > 0.8:
            logger.warning("冷静理性风格(2)搭配高情绪强度可能效果不佳，建议降低emotion值")
    
    def full_validation(self, text: str, ref_audio: str, style: int, 
                       speed: float, emotion: float) -> Dict[str, any]:
        """
        完整的TTS参数验证
        
        Args:
            text: 输入文本
            ref_audio: 参考音频路径
            style: 风格编号
            speed: 语速
            emotion: 情绪强度
            
        Returns:
            验证结果和预处理后的数据
        """
        # 生成缓存键
        cache_key = self._generate_cache_key(text, ref_audio, style, speed, emotion)
        
        # 尝试从缓存获取（可选）
        # if cache_key in self._validation_cache:
        #     return self._validation_cache[cache_key]
        
        # 验证文本
        cleaned_text, language = self.validate_text(text)
        
        # 验证参考音频
        audio_metadata = self.validate_reference_audio(ref_audio)
        
        # 验证参数
        validated_params = self.validate_parameters(style, speed, emotion)
        
        # 综合验证结果
        validation_result = {
            "text": cleaned_text,
            "language": language,
            "audio_metadata": audio_metadata,
            **validated_params,
            "is_valid": True
        }
        
        # 缓存结果
        # self._validation_cache[cache_key] = validation_result
        
        logger.info(f"完整验证通过 - 文本长度: {len(cleaned_text)}, 风格: {style}, 语言: {language}")
        
        return validation_result

# 全局验证器实例
default_validator = TTSValidator()

def validate_tts_input(text: str, ref_audio: str, style: int = 3, 
                      speed: float = 1.0, emotion: float = 0.5, 
                      strict_mode: bool = True) -> Dict[str, any]:
    """
    验证TTS输入的便捷函数
    
    Args:
        text: 输入文本
        ref_audio: 参考音频路径
        style: 风格编号
        speed: 语速
        emotion: 情绪强度
        strict_mode: 是否启用严格模式
        
    Returns:
        验证结果
    """
    validator = TTSValidator(strict_mode=strict_mode)
    return validator.full_validation(text, ref_audio, style, speed, emotion)

def validate_audio_file(audio_path: str) -> Dict[str, any]:
    """
    验证音频文件的便捷函数
    
    Args:
        audio_path: 音频文件路径
        
    Returns:
        音频元数据
    """
    validator = TTSValidator()
    return validator.validate_reference_audio(audio_path)

def validate_text_input(text: str) -> Tuple[str, str]:
    """
    验证文本输入的便捷函数
    
    Args:
        text: 输入文本
        
    Returns:
        (清理后的文本, 检测到的语言)
    """
    validator = TTSValidator()
    return validator.validate_text(text)