# -*- coding: utf-8 -*-
"""
语音合成(TTS)模块，基于GPT-SoVITS 2Pro模型的语音合成系统
"""

# 基础接口导出
from .base.engine_base import TTSEngineBase
from .base.speaker_manager_base import SpeakerManagerBase
from .base.config_base import TTSConfigBase
from .base.tts_manager_base import TTSManagerBase

# GPT-SoVITS 实现导出
from .gpt_sovits.gpt_sovits_speaker_manager import GPTSoVITSSpeakerManager
from .gpt_sovits.gpt_sovits_config import GPTSoVITSConfig
from .gpt_sovits.gpt_sovits_manager import GPTSoVITSManager
from .gpt_sovits.optimized_engine import OptimizedGPTSoVITSEngine as OptimizedTTSEngine
try:
    from core.character import AvelineCharacterManager, get_Aveline_manager, release_Aveline_manager
except Exception:
    pass
from .utils.text_processor import TextProcessor
from .utils.cache_manager import CacheManager

__version__ = "1.1.0"
__all__ = [
    # 基础接口
    "TTSEngineBase",
    "SpeakerManagerBase",
    "TTSConfigBase",
    "TTSManagerBase",
    
    # GPT-SoVITS 实现
    "OptimizedTTSEngine",
    "GPTSoVITSSpeakerManager",
    "GPTSoVITSConfig",
    "GPTSoVITSManager",
    
    # 角色实现
    # 角色相关实现已移动到core.character
    # 保留这些导出以保持向后兼容
    "AvelineCharacterManager",
    "get_Aveline_manager",
    "release_Aveline_manager",
    
    # 工具类
    "TextProcessor",
    "CacheManager",
    
    # 兼容旧接口
    "get_tts_manager",
    "get_global_tts_manager"
]

# 默认导出的管理器实例
_default_manager = None

async def create_tts_manager(config: dict = None) -> GPTSoVITSManager:
    """
    创建并初始化TTS管理器
    
    Args:
        config: TTS配置字典
        
    Returns:
        初始化好的TTS管理器实例
    """
    # 创建配置对象
    if config is None:
        config = {}
    
    tts_config = GPTSoVITSConfig.from_dict(config)
    
    # 创建并初始化管理器
    manager = GPTSoVITSManager()
    # 传递原始配置对象给管理器初始化
    await manager.initialize(tts_config)
    
    return manager

async def get_tts_manager() -> GPTSoVITSManager:
    """
    获取默认TTS管理器实例
    
    Returns:
        默认TTS管理器实例
    """
    global _default_manager
    
    if _default_manager is None:
        _default_manager = await create_tts_manager()
    
    return _default_manager

async def text_to_speech(text: str, output_path: str = None, **kwargs) -> bytes:
    """
    文本转语音的便捷方法
    
    Args:
        text: 要合成的文本
        output_path: 可选的输出文件路径
        **kwargs: 合成参数
        
    Returns:
        音频数据（如果没有指定output_path）
    """
    manager = await get_tts_manager()
    
    if output_path:
        await manager.synthesize_to_file(text, output_path, **kwargs)
        return b""
    else:
        return await manager.synthesize(text, **kwargs)

try:
    from .tts_engine_compat import get_global_tts_manager
except Exception:
    async def get_global_tts_manager():
        return await get_tts_manager()

async def clone_voice(text: str, reference_audio: str, output_path: str = None, **kwargs) -> bytes:
    """
    语音克隆的便捷方法
    
    Args:
        text: 要合成的文本
        reference_audio: 参考音频路径
        output_path: 可选的输出文件路径
        **kwargs: 合成参数
        
    Returns:
        克隆后的音频数据（如果没有指定output_path）
    """
    manager = await get_tts_manager()
    
    if output_path:
        audio_data = await manager.clone_voice(text, reference_audio, **kwargs)
        import numpy as _np
        import soundfile as sf
        _arr = _np.asarray(audio_data, dtype=_np.float32)
        _m = float(_np.max(_np.abs(_arr))) if _arr.size else 0.0
        if _m > 1.0:
            _arr = (_arr / _m).astype(_np.float32)
        _arr = _arr.clip(-1.0, 1.0)
        _pcm16 = (_arr * 32767.0).astype(_np.int16)
        sf.write(output_path, _pcm16, manager.config.sample_rate)
        return b""
    else:
        return await manager.clone_voice(text, reference_audio, **kwargs)

async def get_speakers() -> list:
    """
    获取所有可用说话人
    
    Returns:
        说话人列表
    """
    manager = await get_tts_manager()
    return await manager.get_speakers()

async def shutdown_tts():
    """
    关闭TTS服务，释放资源
    """
    global _default_manager
    
    if _default_manager is not None:
        await _default_manager.shutdown()
        _default_manager = None
