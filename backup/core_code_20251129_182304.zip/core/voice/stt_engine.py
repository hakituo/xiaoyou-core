import os
import asyncio
from typing import Dict, Optional
from dataclasses import dataclass
import yaml
from pathlib import Path
import numpy as np
import torch
from core.model_registry import global_model_registry
from core.utils.logger import get_logger
from .stt_proxy_client import get_global_stt_proxy_client

logger = get_logger("STT_ENGINE")


@dataclass
class STTConfig:
    """STT配置"""

    model_name: str = "whisper"  # whisper
    default_model_size: str = "base"  # tiny, base, small, medium, large
    enable_auto_switch: bool = True  # 启用自动模型切换
    chunk_duration: float = 30.0  # 音频分块时长（秒）
    sample_rate: int = 16000  # 采样率
    language: Optional[str] = None  # None表示自动检测


class STTEngine:
    """STT引擎抽象基类"""

    def __init__(self, config: STTConfig):
        self.config = config
        self.is_initialized = False

    async def initialize(self):
        """初始化引擎"""
        raise NotImplementedError

    async def transcribe(self, audio_data: bytes) -> Dict:
        """转录音频"""
        raise NotImplementedError

    async def shutdown(self):
        """关闭引擎并释放模型资源"""
        for model_size, model_data in self._models.items():
            key = f"whisper_{model_size}"
            global_model_registry.release(key)
            logger.info(f"Released Whisper {model_size} model")
        self._models.clear()
        logger.info("Whisper引擎已关闭")

    def get_info(self) -> Dict:
        """获取引擎信息"""
        return {
            "type": self.config.model_name,
            "initialized": self.is_initialized,
            "config": vars(self.config),
        }


class WhisperEngine(STTEngine):
    """基于Whisper的STT引擎"""

    # 模型大小与近似内存需求（GB）映射
    MODEL_MEMORY_REQUIREMENTS = {
        "tiny": 1.0,
        "base": 1.5,
        "small": 2.5,
        "medium": 5.0,
        "large": 10.0,
        "large-v2": 12.0,
        "large-v3": 14.0,
    }

    # 音频长度阈值（秒）用于自动选择模型
    AUDIO_DURATION_THRESHOLDS = {
        "tiny": 60.0,  # 小于1分钟的音频使用tiny
        "base": 300.0,  # 1-5分钟使用base
        "small": 1800.0,  # 5-30分钟使用small
        "medium": 3600.0,  # 30-60分钟使用medium
        # 大于60分钟使用large
    }

    def __init__(self, config: STTConfig):
        super().__init__(config)
        self._models: Dict[str, Dict] = {}
        self._device = None
        self._lock = asyncio.Lock()

    async def initialize(self):
        """初始化Whisper引擎"""
        if self.is_initialized:
            return

        try:
            # 检查CUDA是否可用
            self._device = "cuda" if torch.cuda.is_available() else "cpu"
            logger.info(f"Whisper引擎将使用设备: {self._device}")

            # 初始化默认模型
            await self._load_model(self.config.default_model_size)

            self.is_initialized = True
            logger.info("Whisper STT引擎初始化成功")

        except ImportError:
            logger.error("未安装whisper库，请运行: pip install openai-whisper")
            raise
        except Exception as e:
            logger.error(f"初始化Whisper引擎失败: {e}")
            raise

    async def _load_model(self, model_size: str) -> Dict:
        """加载指定大小的Whisper模型"""
        if model_size in self._models:
            return self._models[model_size]

        # 检查模型大小是否有效
        if model_size not in self.MODEL_MEMORY_REQUIREMENTS:
            raise ValueError(f"不支持的Whisper模型大小: {model_size}")

        # 检查内存是否足够
        if self._device == "cuda":
            mem_needed = self.MODEL_MEMORY_REQUIREMENTS[model_size]
            gpu_mem = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            if gpu_mem < mem_needed:
                logger.warning(
                    f"GPU内存不足，切换到CPU模式。需要: {mem_needed}GB, 可用: {gpu_mem:.2f}GB"
                )
                self._device = "cpu"

        # 从模型注册中心加载模型
        def load_whisper_model():
            import whisper

            logger.info(f"正在加载Whisper {model_size}模型到{self._device}")
            model = whisper.load_model(model_size, device=self._device)
            return {"model": model, "loaded_at": asyncio.get_event_loop().time()}

        # 使用模型注册中心
        key = f"whisper_{model_size}"
        model_data = global_model_registry.get_or_load(key, load_whisper_model)

        self._models[model_size] = model_data
        logger.info(f"Whisper {model_size}模型加载成功")
        return model_data

    def _estimate_audio_duration(self, audio_data: bytes) -> float:
        """估算音频时长（秒）"""
        # 简单估算：假设16kHz 16bit单声道音频
        # 每秒钟大约32KB数据
        estimated_bytes_per_second = 16000 * 2  # 16kHz * 16bit
        duration = len(audio_data) / estimated_bytes_per_second
        return duration

    def _select_model_size(self, audio_data: bytes) -> str:
        """根据音频长度自动选择模型大小"""
        if not self.config.enable_auto_switch:
            return self.config.default_model_size

        duration = self._estimate_audio_duration(audio_data)
        logger.debug(f"音频估计时长: {duration:.2f}秒")

        # 根据时长选择模型
        for model_size, threshold in sorted(
            self.AUDIO_DURATION_THRESHOLDS.items(), key=lambda x: x[1]
        ):
            if duration < threshold:
                return model_size

        # 默认返回large
        return "large"

    async def transcribe(self, audio_data: bytes) -> Dict:
        """转录音频"""
        if not self.is_initialized:
            await self.initialize()

        import io
        import soundfile as sf

        async with self._lock:
            # 选择模型
            model_size = self._select_model_size(audio_data)
            logger.info(f"使用Whisper {model_size}模型进行转录")

            # 确保模型已加载
            model_data = await self._load_model(model_size)
            whisper_model = model_data["model"]

            # 处理音频数据
            def process_audio():
                # 读取音频数据
                audio_io = io.BytesIO(audio_data)
                try:
                    audio, sr = sf.read(audio_io, dtype="float32")
                except:
                    # 尝试使用Whisper的音频加载功能
                    import whisper

                    audio = whisper.load_audio(io.BytesIO(audio_data))
                    sr = 16000

                # 重采样到16kHz
                if sr != 16000:
                    import librosa

                    audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)

                # 如果是立体声，转换为单声道
                if len(audio.shape) > 1:
                    audio = np.mean(audio, axis=1)

                return audio

            # 预处理音频
            audio = process_audio()

            # 转录
            def do_transcribe():
                result = whisper_model.transcribe(
                    audio, language=self.config.language, fp16=self._device == "cuda"
                )
                return result

            # 直接执行
            result = do_transcribe()

            logger.info(f"Whisper转录完成，识别文本长度: {len(result['text'])}字符")
            return result


class STTEngineFactory:
    """STT引擎工厂类"""

    @staticmethod
    def create_engine(config: STTConfig) -> STTEngine:
        """创建STT引擎实例"""
        if config.model_name == "whisper":
            return WhisperEngine(config)
        else:
            raise ValueError(f"不支持的STT引擎类型: {config.model_name}")


class STTManager:
    """STT管理器"""

    def __init__(self, use_proxy: bool = False):
        self._engine: Optional[STTEngine] = None
        self._proxy_client = None
        self._default_config = STTConfig()
        self._use_proxy = use_proxy

        # 加载配置
        self._load_config()
        logger.info(f"STT管理器初始化完成, 模式: {'代理模式' if use_proxy else '直接模式'}")

    def _load_config(self):
        """加载STT配置"""
        config_path = Path("d:/AI/xiaoyou-core/configs/paths.yaml")
        if config_path.exists():
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = yaml.safe_load(f)
                    if (
                        config
                        and "model_paths" in config
                        and "stt" in config["model_paths"]
                    ):
                        # 可以在这里添加更多配置处理
                        pass
            except Exception as e:
                logger.error(f"加载STT配置失败: {e}")

    async def get_engine(self) -> STTEngine:
        """获取STT引擎实例"""
        if self._use_proxy:
            # 代理模式下抛出异常
            raise RuntimeError("代理模式下不支持直接访问引擎实例")
            
        if self._engine is None:
            # 创建并初始化引擎
            self._engine = STTEngineFactory.create_engine(self._default_config)
            await self._engine.initialize()

        return self._engine
    
    async def _get_proxy_client(self):
        """获取代理客户端实例"""
        if not self._proxy_client:
            self._proxy_client = get_global_stt_proxy_client()
        return self._proxy_client

    async def speech_to_text(self, audio_data: bytes) -> Dict:
        """
        语音转文本

        Args:
            audio_data: 音频数据

        Returns:
            包含转录结果的字典
        """
        if not audio_data:
            raise ValueError("音频数据不能为空")

        # 限制音频大小（防止过大的文件）
        max_audio_size = 100 * 1024 * 1024  # 100MB
        if len(audio_data) > max_audio_size:
            raise ValueError(
                f"音频文件过大，最大支持{max_audio_size / (1024 * 1024)}MB"
            )

        # 根据模式选择调用方式
        if self._use_proxy:
            # 使用代理客户端
            logger.info("使用STT代理客户端进行转录")
            proxy_client = await self._get_proxy_client()
            return await proxy_client.speech_to_text(audio_data)
        else:
            # 直接调用引擎
            engine = await self.get_engine()
            return await engine.transcribe(audio_data)

    def set_language(self, language: Optional[str]):
        """设置默认语言"""
        self._default_config.language = language
        logger.info(f"已设置STT默认语言: {language}")

    def enable_auto_model_switch(self, enable: bool):
        """启用/禁用自动模型切换"""
        self._default_config.enable_auto_switch = enable
        logger.info(f"已{'启用' if enable else '禁用'}自动模型切换")

    def set_default_model_size(self, model_size: str):
        """设置默认模型大小"""
        if model_size in WhisperEngine.MODEL_MEMORY_REQUIREMENTS:
            self._default_config.default_model_size = model_size
            logger.info(f"已设置默认Whisper模型大小: {model_size}")
        else:
            logger.error(f"不支持的Whisper模型大小: {model_size}")
            raise ValueError(f"不支持的Whisper模型大小: {model_size}")

    async def get_status(self) -> Dict:
        """获取STT管理器状态"""
        if self._use_proxy:
            # 代理模式下获取远程状态
            try:
                proxy_client = await self._get_proxy_client()
                remote_status = await proxy_client.get_status()
                return {
                    "mode": "proxy",
                    "remote_status": remote_status,
                    "config": vars(self._default_config)
                }
            except Exception as e:
                logger.error(f"获取远程状态失败: {e}")
                return {
                    "mode": "proxy",
                    "error": str(e),
                    "config": vars(self._default_config)
                }
        else:
            # 直接模式下获取本地状态
            engine_info = self._engine.get_info() if self._engine else {}
            return {
                "mode": "direct",
                "engine": engine_info, 
                "config": vars(self._default_config)
            }

    def get_recommended_model(self, audio_size: int) -> str:
        """根据音频文件大小推荐模型"""
        # 估算音频时长
        duration = audio_size / (16000 * 2)  # 假设16kHz 16bit单声道

        for model_size, threshold in sorted(
            WhisperEngine.AUDIO_DURATION_THRESHOLDS.items(), key=lambda x: x[1]
        ):
            if duration < threshold:
                return model_size

        return "large"

    async def shutdown(self):
        """关闭引擎并释放资源"""
        if self._use_proxy:
            # 关闭代理客户端
            if self._proxy_client:
                await self._proxy_client.shutdown()
                self._proxy_client = None
        else:
            # 关闭本地引擎
            if self._engine:
                await self._engine.shutdown()
                self._engine = None
        logger.info("STT管理器已关闭")


# 全局STT管理器实例
_global_stt_manager_instance = None

def get_global_stt_manager(use_proxy: bool = None) -> STTManager:
    """获取全局STT管理器实例"""
    global _global_stt_manager_instance
    # 检查是否需要使用代理模式
    if use_proxy is None:
        # 尝试从环境变量读取配置
        use_proxy = os.environ.get("STT_USE_PROXY", "false").lower() == "true"
        # 或者从配置文件读取
        config_path = Path("config/integrated_config.py")
        if config_path.exists():
            try:
                # 动态导入配置
                import importlib.util
                spec = importlib.util.spec_from_file_location("integrated_config", config_path)
                config_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(config_module)
                if hasattr(config_module, "get_settings"):
                    proxy_setting = config_module.get_settings().get("voice.stt.use_proxy", "false")
                    use_proxy = str(proxy_setting).lower() == "true"
            except Exception as e:
                logger.warning(f"读取配置时出错: {e}")
    
    # 单例管理
    if _global_stt_manager_instance is None:
        _global_stt_manager_instance = STTManager(use_proxy=use_proxy)
    else:
        # 如果已有实例但模式不匹配，记录警告但不关闭（避免异步问题）
        instance = _global_stt_manager_instance
        if instance._use_proxy != use_proxy:
            logger.warning(f"STT管理器模式与现有实例不匹配: {instance._use_proxy} != {use_proxy}")
            logger.warning("请先关闭现有实例再切换模式")
    
    return _global_stt_manager_instance

async def create_global_stt_manager(use_proxy: bool = None) -> STTManager:
    """异步创建全局STT管理器实例，支持安全切换模式"""
    global _global_stt_manager_instance
    # 检查是否需要使用代理模式
    if use_proxy is None:
        # 尝试从环境变量读取配置
        use_proxy = os.environ.get("STT_USE_PROXY", "false").lower() == "true"
        # 或者从配置文件读取
        config_path = Path("config/integrated_config.py")
        if config_path.exists():
            try:
                # 动态导入配置
                import importlib.util
                spec = importlib.util.spec_from_file_location("integrated_config", config_path)
                config_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(config_module)
                if hasattr(config_module, "get_settings"):
                    proxy_setting = config_module.get_settings().get("voice.stt.use_proxy", "false")
                    use_proxy = str(proxy_setting).lower() == "true"
            except Exception as e:
                logger.warning(f"读取配置时出错: {e}")
    
    # 单例管理
    if _global_stt_manager_instance is None:
        _global_stt_manager_instance = STTManager(use_proxy=use_proxy)
    else:
        # 如果已有实例但模式不匹配，关闭旧实例并创建新实例
        instance = _global_stt_manager_instance
        if instance._use_proxy != use_proxy:
            logger.info(f"STT管理器模式变更: {instance._use_proxy} -> {use_proxy}")
            # 关闭旧实例
            await instance.shutdown()
            # 创建新实例
            _global_stt_manager_instance = STTManager(use_proxy=use_proxy)
    
    return _global_stt_manager_instance
