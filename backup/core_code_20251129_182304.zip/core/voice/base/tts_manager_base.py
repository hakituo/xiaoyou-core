# -*- coding: utf-8 -*-
"""
TTS管理器基类，提供统一的TTS管理接口
"""

import asyncio
from typing import Dict, Optional, Any
from abc import ABC, abstractmethod

from .engine_base import TTSEngineBase
from .speaker_manager_base import SpeakerManagerBase
from .config_base import TTSConfigBase


class TTSManagerBase(ABC):
    """
    TTS管理器基类，提供统一的TTS管理接口
    """
    
    def __init__(self):
        """
        初始化TTS管理器
        """
        self._engines: Dict[str, TTSEngineBase] = {}
        self._speaker_managers: Dict[str, SpeakerManagerBase] = {}
        self._active_engine_id: Optional[str] = None
        self._config: Optional[TTSConfigBase] = None
        self._lock = asyncio.Lock()
    
    @abstractmethod
    async def initialize(self, config: TTSConfigBase):
        """
        初始化TTS管理器
        
        Args:
            config: TTS配置对象
            
        Raises:
            RuntimeError: 初始化失败
        """
        self._config = config
    
    @abstractmethod
    async def register_engine(self, engine_id: str, engine: TTSEngineBase, set_active: bool = False):
        """
        注册TTS引擎
        
        Args:
            engine_id: 引擎ID
            engine: TTS引擎实例
            set_active: 是否设为当前活动引擎
            
        Raises:
            ValueError: 引擎ID已存在
        """
        pass
    
    @abstractmethod
    async def register_speaker_manager(self, manager_id: str, manager: SpeakerManagerBase):
        """
        注册说话人管理器
        
        Args:
            manager_id: 管理器ID
            manager: 说话人管理器实例
            
        Raises:
            ValueError: 管理器ID已存在
        """
        pass
    
    @abstractmethod
    async def set_active_engine(self, engine_id: str):
        """
        设置当前活动引擎
        
        Args:
            engine_id: 引擎ID
            
        Raises:
            ValueError: 引擎不存在
        """
        pass
    
    async def synthesize(self, text: str, **kwargs) -> Any:
        """
        使用当前活动引擎合成语音
        
        Args:
            text: 要合成的文本
            **kwargs: 合成参数
            
        Returns:
            音频数据
            
        Raises:
            RuntimeError: 无活动引擎或合成失败
        """
        if not self._active_engine_id or self._active_engine_id not in self._engines:
            raise RuntimeError("没有活动的TTS引擎可用")
        
        return await self._engines[self._active_engine_id].synthesize(text, **kwargs)
    
    async def synthesize_to_file(self, text: str, output_path: str, **kwargs):
        """
        使用当前活动引擎合成语音并保存到文件
        
        Args:
            text: 要合成的文本
            output_path: 输出文件路径
            **kwargs: 合成参数
            
        Raises:
            RuntimeError: 无活动引擎或合成失败
            IOError: 文件保存失败
        """
        if not self._active_engine_id or self._active_engine_id not in self._engines:
            raise RuntimeError("没有活动的TTS引擎可用")
        
        return await self._engines[self._active_engine_id].synthesize_to_file(text, output_path, **kwargs)
    
    async def get_speakers(self) -> list:
        """
        获取所有可用说话人列表
        
        Returns:
            说话人列表
        """
        speakers = []
        for manager in self._speaker_managers.values():
            if manager.is_initialized:
                speakers.extend(await manager.get_speakers())
        return speakers
    
    @property
    def active_engine(self) -> Optional[TTSEngineBase]:
        """
        获取当前活动引擎
        
        Returns:
            当前活动的TTS引擎实例或None
        """
        if self._active_engine_id and self._active_engine_id in self._engines:
            return self._engines[self._active_engine_id]
        return None
    
    @property
    def config(self) -> Optional[TTSConfigBase]:
        """
        获取当前配置
        
        Returns:
            当前配置对象或None
        """
        return self._config
    
    async def shutdown(self):
        """
        关闭所有资源
        """
        # 关闭所有引擎
        for engine in self._engines.values():
            await engine.shutdown()
        
        # 关闭所有说话人管理器
        for manager in self._speaker_managers.values():
            await manager.shutdown()
        
        self._engines.clear()
        self._speaker_managers.clear()
        self._active_engine_id = None