# -*- coding: utf-8 -*-
"""
配置基类，定义TTS相关配置接口
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional


@dataclass
class TTSConfigBase:
    """
    TTS配置基类，定义通用配置项
    """
    # 设备配置
    device: str = "cpu"  # 运行设备
    
    # 音频配置
    sample_rate: int = 24000  # 音频采样率
    audio_channels: int = 1  # 音频通道数
    
    # 合成参数
    speed: float = 1.0  # 语速调整系数
    pitch: float = 1.0  # 音高调整系数
    volume: float = 1.0  # 音量调整系数
    
    # 分段配置
    max_segment_length: int = 500  # 最大分段长度
    segment_overlap: int = 0  # 分段重叠长度
    
    # 模型配置
    model_path: Optional[str] = None  # 模型路径
    model_config: Dict[str, Any] = field(default_factory=dict)  # 模型特定配置
    
    # 缓存配置
    cache_enabled: bool = True  # 是否启用缓存
    cache_size_mb: int = 100  # 缓存大小(MB)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典
        
        Returns:
            配置字典
        """
        return {
            "device": self.device,
            "sample_rate": self.sample_rate,
            "audio_channels": self.audio_channels,
            "speed": self.speed,
            "pitch": self.pitch,
            "volume": self.volume,
            "max_segment_length": self.max_segment_length,
            "segment_overlap": self.segment_overlap,
            "model_path": self.model_path,
            "model_config": self.model_config,
            "cache_enabled": self.cache_enabled,
            "cache_size_mb": self.cache_size_mb,
        }
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "TTSConfigBase":
        """
        从字典创建配置对象
        
        Args:
            config_dict: 配置字典
            
        Returns:
            配置对象
        """
        return cls(**config_dict)