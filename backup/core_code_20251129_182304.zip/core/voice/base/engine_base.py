# -*- coding: utf-8 -*-
"""
TTS引擎基类，定义TTS引擎通用接口
"""

import asyncio
import numpy as np
from abc import ABC, abstractmethod


class TTSEngineBase(ABC):
    """
    TTS引擎基类，定义所有TTS引擎实现必须遵循的接口
    """
    
    def __init__(self, device: str = 'cpu', sample_rate: int = 24000):
        """
        初始化TTS引擎基类
        
        Args:
            device: 设备类型，如'cpu'或'cuda'
            sample_rate: 音频采样率
        """
        self.device = device
        self.sample_rate = sample_rate
        self._is_initialized = False
        self._lock = asyncio.Lock()
    
    @abstractmethod
    async def initialize(self, **kwargs):
        """
        初始化TTS引擎
        
        Args:
            **kwargs: 初始化参数
        
        Raises:
            RuntimeError: 初始化失败时抛出异常
        """
        pass
    
    @abstractmethod
    async def synthesize(self, text: str, **kwargs) -> np.ndarray:
        """
        将文本合成为语音数据
        
        Args:
            text: 要合成的文本
            **kwargs: 合成参数，如说话人ID、语速、音高等
            
        Returns:
            numpy数组格式的音频数据
            
        Raises:
            ValueError: 参数错误
            RuntimeError: 合成失败
        """
        pass
    
    async def synthesize_to_file(self, text: str, output_path: str, **kwargs):
        """
        合成语音并保存到文件
        
        Args:
            text: 要合成的文本
            output_path: 输出文件路径
            **kwargs: 合成参数
            
        Raises:
            IOError: 文件保存失败
            RuntimeError: 合成失败
        """
        import soundfile as sf
        import numpy as _np
        audio_data = await self.synthesize(text, **kwargs)
        _arr = _np.asarray(audio_data, dtype=_np.float32)
        _m = float(_np.max(_np.abs(_arr))) if _arr.size else 0.0
        if _m > 1.0:
            _arr = (_arr / _m).astype(_np.float32)
        _arr = _arr.clip(-1.0, 1.0)
        _pcm16 = (_arr * 32767.0).astype(_np.int16)
        try:
            sf.write(output_path, _pcm16, self.sample_rate)
        except Exception as e:
            raise IOError(f"保存音频文件失败: {str(e)}")
    
    def get_supported_features(self) -> dict:
        """
        获取引擎支持的功能列表
        
        Returns:
            功能字典，包含引擎支持的特性
        """
        return {
            "segmentation": True,  # 是否支持文本分段
            "voice_cloning": False,  # 是否支持语音克隆
            "speaker_id": False,  # 是否支持说话人ID
            "speed": True,  # 是否支持语速调整
            "pitch": True,  # 是否支持音高调整
            "style": False,  # 是否支持风格设置
        }
    
    async def shutdown(self):
        """
        关闭引擎，释放资源
        """
        self._is_initialized = False
    
    @property
    def is_initialized(self) -> bool:
        """
        检查引擎是否已初始化
        
        Returns:
            初始化状态
        """
        return self._is_initialized
