# -*- coding: utf-8 -*-
"""
说话人管理器基类，定义说话人管理通用接口
"""

import numpy as np
from abc import ABC, abstractmethod


class SpeakerManagerBase(ABC):
    """
    说话人管理器基类，定义说话人管理和嵌入特征提取接口
    """
    
    def __init__(self):
        """
        初始化说话人管理器
        """
        self._is_initialized = False
    
    @abstractmethod
    async def initialize(self):
        """
        初始化说话人管理器
        
        Raises:
            RuntimeError: 初始化失败时抛出异常
        """
        pass
    
    @abstractmethod
    async def get_speakers(self) -> list:
        """
        获取可用说话人列表
        
        Returns:
            说话人列表，每个元素是包含id和name的字典
        """
        pass
    
    @abstractmethod
    async def get_speaker_embedding(self, speaker_id: str) -> np.ndarray:
        """
        获取指定说话人的嵌入特征
        
        Args:
            speaker_id: 说话人ID
            
        Returns:
            嵌入特征向量
            
        Raises:
            ValueError: 说话人不存在
        """
        pass
    
    @abstractmethod
    async def extract_embedding_from_audio(self, audio_path: str) -> np.ndarray:
        """
        从音频文件中提取说话人嵌入特征
        
        Args:
            audio_path: 音频文件路径
            
        Returns:
            嵌入特征向量
            
        Raises:
            FileNotFoundError: 文件不存在
            ValueError: 音频格式不支持
            RuntimeError: 特征提取失败
        """
        pass
    
    async def shutdown(self):
        """
        关闭说话人管理器，释放资源
        """
        self._is_initialized = False
    
    @property
    def is_initialized(self) -> bool:
        """
        检查管理器是否已初始化
        
        Returns:
            初始化状态
        """
        return self._is_initialized