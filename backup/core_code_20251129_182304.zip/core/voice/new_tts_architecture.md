# 新TTS模块架构设计

## 1. 架构概览

新的TTS模块将采用模块化、可扩展的设计，支持多种语音合成模型和后端，提供统一的API接口。主要组件包括：

```
core/voice/
├── __init__.py              # 模块初始化和导出
├── tts_engine/              # TTS引擎核心目录
│   ├── __init__.py
│   ├── base_engine.py       # 引擎基类
│   ├── coqui_engine.py      # Coqui TTS引擎实现
│   ├── bark_engine.py       # Bark模型引擎实现
│   └── edge_tts_engine.py   # Edge TTS引擎实现
├── speaker/                 # 说话人管理
│   ├── __init__.py
│   ├── embedding.py         # 说话人嵌入提取
│   ├── manager.py           # 说话人管理器
│   └── cache.py             # 缓存机制
├── models/                  # 模型管理
│   ├── __init__.py
│   ├── loader.py            # 模型加载器
│   └── registry.py          # 模型注册表
├── utils/                   # 工具函数
│   ├── __init__.py
│   ├── audio_processing.py  # 音频处理工具
│   ├── text_utils.py        # 文本处理工具
│   └── resource_manager.py  # 资源管理
├── config.py                # 配置管理
├── manager.py               # 统一的TTS管理器
├── exceptions.py            # 自定义异常
└── tests/                   # 单元测试
```

## 2. 核心组件设计

### 2.1 TTS引擎接口 (base_engine.py)

```python
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, Tuple, List
import numpy as np

class TTSEngineBase(ABC):
    """TTS引擎抽象基类，定义所有引擎必须实现的接口"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model = None
        self.is_initialized = False
    
    @abstractmethod
    async def initialize(self):
        """初始化TTS引擎"""
        pass
    
    @abstractmethod
    async def synthesize(self, text: str, **kwargs) -> Tuple[np.ndarray, int]:
        """合成语音
        
        Args:
            text: 要合成的文本
            **kwargs: 其他参数（如speaker_id, speaker_wav, speed, pitch等）
            
        Returns:
            (音频数据, 采样率) 元组
        """
        pass
    
    @abstractmethod
    async def synthesize_to_file(self, text: str, output_path: str, **kwargs) -> str:
        """合成语音到文件
        
        Args:
            text: 要合成的文本
            output_path: 输出文件路径
            **kwargs: 其他参数
            
        Returns:
            输出文件路径
        """
        pass
    
    @abstractmethod
    def set_speaker(self, speaker_id: Optional[str] = None, speaker_wav: Optional[str] = None):
        """设置说话人
        
        Args:
            speaker_id: 说话人ID
            speaker_wav: 参考音频路径（用于语音克隆）
        """
        pass
    
    @abstractmethod
    def clean_resources(self):
        """清理资源"""
        pass
    
    @property
    @abstractmethod
    def supported_features(self) -> List[str]:
        """返回引擎支持的特性列表"""
        pass
```

### 2.2 说话人嵌入提取器 (embedding.py)

```python
from typing import Optional, Dict, Any
import numpy as np
from pathlib import Path

class SpeakerEmbeddingExtractor:
    """说话人嵌入提取器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model = None
        self.cache_dir = Path(config.get('cache_dir', './cache/speaker_embeddings'))
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    async def initialize(self):
        """初始化嵌入提取器"""
        pass
    
    async def extract(self, audio_path: str) -> np.ndarray:
        """从音频提取说话人嵌入
        
        Args:
            audio_path: 音频文件路径
            
        Returns:
            说话人嵌入向量
        """
        pass
    
    async def find_similar(self, target_embedding: np.ndarray, top_k: int = 3) -> list:
        """查找相似说话人
        
        Args:
            target_embedding: 目标嵌入
            top_k: 返回前k个最相似结果
            
        Returns:
            相似说话人列表
        """
        pass
    
    def save_embedding(self, embedding: np.ndarray, speaker_id: str):
        """保存嵌入到缓存"""
        pass
    
    def load_embedding(self, speaker_id: str) -> Optional[np.ndarray]:
        """从缓存加载嵌入"""
        pass
```

### 2.3 统一TTS管理器 (manager.py)

```python
from typing import Optional, Dict, Any, List
from core.voice.tts_engine.base_engine import TTSEngineBase
from core.voice.models.registry import ModelRegistry
from core.voice.speaker.manager import SpeakerManager

class TTSManager:
    """统一的TTS管理器，提供高级API"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model_registry = ModelRegistry()
        self.speaker_manager = SpeakerManager(config.get('speaker', {}))
        self.active_engine: Optional[TTSEngineBase] = None
        self.active_model = None
    
    async def initialize(self):
        """初始化TTS管理器"""
        await self.speaker_manager.initialize()
        # 注册默认模型
        self._register_default_models()
    
    async def use_model(self, model_name: str) -> TTSEngineBase:
        """使用指定模型
        
        Args:
            model_name: 模型名称
            
        Returns:
            TTS引擎实例
        """
        pass
    
    async def synthesize(self, text: str, model_name: Optional[str] = None, 
                         speaker_id: Optional[str] = None, 
                         speaker_wav: Optional[str] = None, 
                         **kwargs) -> tuple:
        """合成语音
        
        Args:
            text: 要合成的文本
            model_name: 模型名称
            speaker_id: 说话人ID
            speaker_wav: 参考音频路径
            **kwargs: 其他参数
            
        Returns:
            (音频数据, 采样率) 元组
        """
        pass
    
    async def synthesize_to_file(self, text: str, output_path: str, 
                               model_name: Optional[str] = None, 
                               speaker_id: Optional[str] = None, 
                               speaker_wav: Optional[str] = None, 
                               **kwargs) -> str:
        """合成语音到文件"""
        pass
    
    async def get_available_models(self) -> List[str]:
        """获取可用模型列表"""
        pass
    
    async def get_available_speakers(self, model_name: Optional[str] = None) -> List[str]:
        """获取可用说话人列表"""
        pass
    
    def _register_default_models(self):
        """注册默认模型"""
        pass
    
    def clean_resources(self):
        """清理资源"""
        if self.active_engine:
            self.active_engine.clean_resources()
            self.active_engine = None
```

## 3. 功能特性设计

### 3.1 多模型支持

- **Coqui TTS**：支持多种语言和模型架构
- **Bark**：支持高质量语音合成和克隆
- **Edge TTS**：微软云服务的TTS能力
- **自定义模型**：通过插件系统支持自定义模型

### 3.2 语音克隆增强

- 支持高质量说话人嵌入提取
- 实现嵌入缓存机制，避免重复提取
- 支持基于相似度的说话人推荐
- 提供参数调优功能，优化克隆效果

### 3.3 文本处理增强

- 智能分段处理，支持超长文本
- 标点符号处理优化
- 支持SSML标记语言
- 语言检测和自动选择

### 3.4 音频处理功能

- 音频格式转换
- 音量归一化
- 降噪处理
- 音频拼接和混合

## 4. 资源管理

### 4.1 内存管理

- 智能内存清理策略
- 资源使用监控
- 防止内存泄漏的机制

### 4.2 模型管理

- 模型自动下载和更新
- 模型缓存机制
- 模型版本控制

## 5. 错误处理和日志

- 全面的错误类型定义
- 详细的日志记录
- 降级策略（当首选模型失败时）
- 健康检查机制

## 6. API接口设计

### 6.1 同步API

```python
def synthesize_sync(text, **kwargs):
    """同步合成API"""
    pass

def synthesize_to_file_sync(text, output_path, **kwargs):
    """同步合成到文件API"""
    pass
```

### 6.2 异步API

```python
async def synthesize_async(text, **kwargs):
    """异步合成API"""
    pass

async def synthesize_to_file_async(text, output_path, **kwargs):
    """异步合成到文件API"""
    pass
```

### 6.3 流式API（未来扩展）

```python
async def synthesize_stream(text, **kwargs):
    """流式合成API"""
    pass
```

## 7. 配置系统

### 7.1 默认配置

```python
DEFAULT_CONFIG = {
    "engine": {
        "default_model": "tts_models/zh-CN/baker/tacotron2-DDC-GST",
        "preferred_backend": "coqui",
        "device": "cpu",  # 默认为CPU以提高稳定性
    },
    "speaker": {
        "embedding_cache_dir": "./cache/speaker_embeddings",
        "reference_audio_dir": "./bots/data/voices",
        "default_speaker": None,
    },
    "processing": {
        "max_segment_length": 500,
        "enable_segmentation": True,
        "normalization": True,
        "denoising": False,
    },
    "model": {
        "download_dir": "./models/tts",
        "auto_download": True,
        "mirror": "hf-mirror",
    },
    "cache": {
        "enabled": True,
        "max_size_mb": 1024,
        "ttl_hours": 72,
    }
}
```

## 8. 实现路线图

1. **阶段一：基础架构**
   - 实现引擎基类和接口
   - 实现配置系统
   - 实现基础的Coqui引擎

2. **阶段二：核心功能**
   - 实现说话人管理
   - 实现模型加载和注册
   - 实现文本处理和分段

3. **阶段三：增强功能**
   - 实现语音克隆增强
   - 实现多模型支持
   - 实现资源管理优化

4. **阶段四：测试和优化**
   - 编写单元测试
   - 性能优化
   - 文档完善

## 9. 向后兼容性

- 提供兼容层，支持旧版API调用方式
- 支持配置文件迁移
- 详细的升级指南

## 10. 测试策略

- 单元测试覆盖核心功能
- 集成测试验证组件交互
- 性能测试评估合成速度和资源使用
- 质量测试评估合成语音质量

---

此架构设计提供了一个模块化、可扩展的TTS系统框架，支持多种模型和后端，增强了语音克隆功能，并改进了资源管理和错误处理机制。