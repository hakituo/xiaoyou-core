#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一模型适配器
作为所有模型适配器的统一入口
"""

import os
import logging
import torch
import json
from typing import Dict, Optional, Any, Union
from PIL import Image

from .text_model_adapter import BaseAdapter, TextModelAdapter
from .sd_adapter import SDAdapter
from .model_manager import get_model_manager
from .llm.infer_service_client import get_infer_client

logger = logging.getLogger(__name__)


class ModelManifest:
    """
    模型清单验证类
    验证模型清单的完整性和一致性
    """
    def __init__(self, manifest_path: str):
        self.manifest_path = manifest_path
        self.manifest = self._load_manifest()
        self._validate_manifest()
        
    def _load_manifest(self) -> Dict[str, Any]:
        """加载模型清单"""
        if not os.path.exists(self.manifest_path):
            logger.warning(f"模型清单文件不存在: {self.manifest_path}")
            return {"models": []}
        
        try:
            with open(self.manifest_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载模型清单失败: {str(e)}")
            return {"models": []}
    
    def _validate_manifest(self):
        """验证模型清单格式"""
        if "models" not in self.manifest or not isinstance(self.manifest["models"], list):
            logger.error("模型清单格式不正确，缺少models字段或不是列表")
            self.manifest["models"] = []
    
    def get_model_info(self, model_name: str) -> Optional[Dict[str, Any]]:
        """获取指定模型的信息"""
        for model in self.manifest["models"]:
            if model.get("name") == model_name:
                return model
        return None
    
    def validate_model_path(self, model_path: str) -> bool:
        """验证模型路径是否存在"""
        return os.path.exists(model_path)
    
    def calculate_directory_hash(self, directory: str) -> str:
        """计算目录的哈希值"""
        if not os.path.exists(directory):
            return ""
        
        import hashlib
        hasher = hashlib.md5()
        
        try:
            for root, _, files in os.walk(directory):
                for file in sorted(files):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'rb') as f:
                            buf = f.read(65536)  # 读取64KB块
                            while buf:
                                hasher.update(buf)
                                buf = f.read(65536)
                    except Exception as e:
                        logger.warning(f"无法读取文件 {file_path}: {str(e)}")
        except Exception as e:
            logger.error(f"计算目录哈希失败: {str(e)}")
        
        return hasher.hexdigest()


class ModelAdapter:
    """
    统一模型适配器
    作为所有模型任务的统一入口，委托给特定的适配器处理
    """
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        # 不再继承BaseAdapter，而是作为一个复合适配器
        
        # 默认配置
        self.default_config = {
            'text_model': {
                'model_type': 'transformers',  # transformers, ollama, vllm, infer_service
                'text_model_path': '',
                'device': 'auto',
                'quantization': {
                    'enabled': False,
                    'load_in_8bit': False,
                    'load_in_4bit': False,
                    'torch_dtype': torch.float16 if torch.cuda.is_available() else torch.float32
                },
                'ollama_base_url': 'http://localhost:11434',
                'ollama_model': 'llama3',
                'vllm_base_url': 'http://localhost:8000/generate',
                'vllm_model': 'facebook/opt-125m',
                'timeout': 60,
                'max_retries': 3
            },
            'image_model': {
                'model_type': 'stable_diffusion',
                'sd_model_path': '',
                'device': 'auto',
                'quantization': {
                    'enabled': True,
                    'torch_dtype': torch.float16 if torch.cuda.is_available() else torch.float32,
                    'device_map': 'auto',
                    'precision_level': 'fp16'
                },
                'generation': {
                    'width': 512,
                    'height': 512,
                    'num_inference_steps': 20,
                    'guidance_scale': 7.0,
                    'negative_prompt': 'ugly, blurry, low quality, bad anatomy',
                    'low_vram_mode': True,
                    'disable_postprocessing': True
                },
                'lora': {
                    'enabled': False,
                    'path': '',
                    'weight': 0.7,
                    'base_model_path': ''
                },
                'safety_checker': False
            },
            'memory_config': {
                'low_memory_threshold': 0.7,   # 70%
                'high_memory_pressure': 0.85,  # 85%
                'cleanup_after_request': True
            }
        }
        
        # 合并配置
        self.config = self._merge_config_with_defaults(self.default_config, config)
        
        # 初始化子适配器
        self.text_adapter = None
        self.image_adapter = None
        self.vision_adapter = None
        self.infer_client = None
        
        # 跟踪已加载的模型类型
        self.model_loaded = {
            'text': False,
            'image_gen': False,
            'vision': False,
            'infer_service': False
        }
        
        # 性能统计
        self.performance_stats = {
            'total_generations': 0,
            'total_time': 0,
            'avg_time': 0,
            'peak_memory': 0
        }
        
        # 初始化模型
        self._init_adapters()
    
    def _merge_config_with_defaults(self, default_config, user_config=None):
        """合并默认配置和用户配置"""
        if user_config is None:
            return default_config.copy()
        
        result = default_config.copy()
        
        def merge_dicts(default, user):
            for key, value in user.items():
                if key in default and isinstance(default[key], dict) and isinstance(value, dict):
                    default[key] = merge_dicts(default[key], value)
                else:
                    default[key] = value
            return default
        
        return merge_dicts(result, user_config)
    
    def _init_adapters(self):
        """初始化各类型的适配器"""
        try:
            # 获取模型管理器
            model_manager = get_model_manager()
            
            # 初始化文本适配器，确保传递所有必需参数
            text_model_config = self.config['text_model']
            # 创建模型名称
            model_name = f"text_{text_model_config['model_type']}"
            if text_model_config.get('text_model_path'):
                model_name += f"_{hash(text_model_config['text_model_path']) % 10000}"
            
            # 直接创建TextModelAdapter实例，它会自己处理参数
            self.text_adapter = TextModelAdapter(text_model_config)
            logger.info("文本模型适配器初始化成功")
            
            # 初始化图像生成适配器
            self.image_adapter = SDAdapter(self.config['image_model'])
            logger.info("图像生成适配器初始化成功")
        except Exception as e:
            logger.error(f"初始化适配器失败: {str(e)}")
    
    def get_current_memory_usage(self) -> float:
        """
        获取当前Python进程的内存使用情况
        返回MB
        """
        try:
            import psutil
            process = psutil.Process(os.getpid())
            return process.memory_info().rss / 1024 / 1024  # 转换为MB
        except Exception as e:
            logger.warning(f"无法获取内存使用情况: {str(e)}")
            return 0
    
    def _clear_memory(self, full_cleanup: bool = False):
        """
        清理内存
        Args:
            full_cleanup: 是否进行完全清理
        """
        import gc
        
        # 清理CUDA缓存
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            if full_cleanup:
                torch.cuda.ipc_collect()
        
        # 强制垃圾回收
        gc.collect()
        
        # 根据需要重置模型
        if full_cleanup:
            for model_type in self.model_loaded:
                self.model_loaded[model_type] = False
    
    def _init_infer_service(self):
        """初始化推理服务客户端"""
        try:
            if self.infer_client is None and not self.model_loaded["infer_service"]:
                self.infer_client = get_infer_client()
                logger.info("推理服务客户端初始化成功")
                self.model_loaded["infer_service"] = True
        except Exception as e:
            logger.error(f"初始化推理服务客户端失败: {str(e)}")
    
    def chat(self, messages, model_name=None, temperature=0.7, max_tokens=512, **kwargs):
        """
        处理聊天请求，委托给文本适配器
        """
        try:
            if not self.text_adapter:
                logger.error("文本适配器未初始化")
                return {"status": "error", "error": "文本适配器未初始化"}
            
            # 如果提供了特定模型名称，更新配置
            if model_name:
                self.text_adapter.config['text_model_path'] = model_name
                self.text_adapter._register_model()
            
            # 委托给文本适配器处理
            result = self.text_adapter.chat(
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs
            )
            
            # 根据内存配置决定是否清理内存
            if self.config['memory_config']['cleanup_after_request']:
                import psutil
                current_memory = psutil.virtual_memory().percent / 100.0
                if current_memory > self.config['memory_config']['low_memory_threshold']:
                    self._clear_memory()
            
            return result
        except Exception as e:
            logger.error(f"聊天请求处理失败: {str(e)}")
            return {"status": "error", "error": f"聊天请求处理失败: {str(e)}"}
    
    def generate_image(self, prompt, negative_prompt=None, **kwargs):
        """
        处理图像生成请求，委托给图像适配器
        """
        try:
            if not self.image_adapter:
                logger.error("图像适配器未初始化")
                return {"status": "error", "error": "图像适配器未初始化"}
            
            # 委托给图像适配器处理
            result = self.image_adapter.generate_image(
                prompt=prompt,
                negative_prompt=negative_prompt,
                **kwargs
            )
            
            # 根据内存配置决定是否清理内存
            if self.config['memory_config']['cleanup_after_request']:
                import psutil
                current_memory = psutil.virtual_memory().percent / 100.0
                if current_memory > self.config['memory_config']['low_memory_threshold']:
                    self._clear_memory()
            
            return result
        except Exception as e:
            logger.error(f"图像生成请求处理失败: {str(e)}")
            return {"status": "error", "error": f"图像生成请求处理失败: {str(e)}"}
    
    def describe_image(self, image, prompt=None):
        """
        处理图像描述请求，这里可以扩展为专用视觉模型适配器
        目前提供一个基础实现
        """
        try:
            # 如果有专门的视觉适配器，委托给它
            if self.vision_adapter:
                return self.vision_adapter.describe_image(image, prompt)
            
            # 基础实现 - 使用文本模型进行图像描述
            logger.warning("未初始化专用视觉适配器，使用文本模型进行简单图像描述")
            return {"status": "error", "error": "专用视觉适配器未初始化"}
        except Exception as e:
            logger.error(f"图像描述请求处理失败: {str(e)}")
            return {"status": "error", "error": f"图像描述请求处理失败: {str(e)}"}
    
    def process_request(self, request_type, **kwargs):
        """
        通过统一接口处理不同类型的请求
        支持文本生成(chat)、图像描述(describe_image)和图像生成(generate_image)
        """
        if request_type == "chat":
            return self.chat(**kwargs)
        elif request_type == "describe_image":
            return self.describe_image(**kwargs)
        elif request_type == "generate_image":
            return self.generate_image(**kwargs)
        else:
            return {"status": "error", "error": f"不支持的请求类型: {request_type}"}
    
    def _load_text_model(self):
        """加载文本模型，用于app.py中的初始化调用"""
        try:
            if self.text_adapter and hasattr(self.text_adapter, '_register_model'):
                self.text_adapter._register_model()
                logger.info("文本模型注册完成")
            # 为了兼容app.py中的检查，设置text_model属性
            self.text_model = self.text_adapter
            logger.info("文本模型加载成功")
            return True
        except Exception as e:
            logger.error(f"加载文本模型失败: {str(e)}")
            self.text_model = None
            return False
