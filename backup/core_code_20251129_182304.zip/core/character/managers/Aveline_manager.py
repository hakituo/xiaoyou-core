"""
角色管理器模块
负责管理Aveline角色的初始化、加载和状态维护
"""
import os
import json
import logging
from typing import Optional, Dict, Any


logger = logging.getLogger(__name__)


class AvelineCharacterManager:
    """
    Aveline角色管理器
    负责加载和管理角色配置、状态和行为
    """
    
    def __init__(self):
        """
        初始化角色管理器
        """
        self.character_config = {}
        self.character_state = {}
        self.config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            'configs', 'Aveline.json'
        )
        
        # 尝试加载配置文件
        self.load_character_config()
        
        logger.info("Aveline角色管理器初始化完成")
    
    def initialize(self):
        """
        初始化角色管理器（兼容接口）
        确保与现有代码兼容
        
        Returns:
            bool: 是否初始化成功
        """
        # 由于初始化工作已经在__init__中完成，这里只需要返回成功
        # 但可以添加额外的初始化逻辑
        logger.info("Aveline角色管理器initialize方法被调用")
        
        # 确保配置已加载
        if not self.character_config:
            return self.load_character_config()
        
        return True
    
    def load_character_config(self) -> bool:
        """
        加载角色配置文件
        
        Returns:
            bool: 是否成功加载配置
        """
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.character_config = json.load(f)
                logger.info(f"成功加载角色配置: {self.config_path}")
                return True
            else:
                # 如果配置文件不存在，创建默认配置
                self.create_default_config()
                logger.warning(f"配置文件不存在，已创建默认配置: {self.config_path}")
                return True
        except Exception as e:
            logger.error(f"加载角色配置失败: {e}")
            return False
    
    def create_default_config(self) -> None:
        """
        创建默认角色配置
        """
        # 确保配置目录存在
        config_dir = os.path.dirname(self.config_path)
        if not os.path.exists(config_dir):
            os.makedirs(config_dir)
        
        # 默认角色配置
        default_config = {
            "name": "Aveline",
                "description": "一个友好、智能的AI助手",
                "personality": "温和、乐于助人、知识丰富",
                "greeting": "你好！我是Aveline，很高兴能帮助你。",
            "context": "你是一个专业的AI助手，擅长回答各种问题，并提供有用的建议。",
            "version": "1.0.0",
            "settings": {
                "max_history": 100,
                "temperature": 0.7,
                "max_tokens": 2048
            }
        }
        
        # 保存默认配置
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, ensure_ascii=False, indent=2)
            self.character_config = default_config
        except Exception as e:
            logger.error(f"创建默认配置失败: {e}")
    
    def get_character_info(self) -> Dict[str, Any]:
        """
        获取角色信息
        
        Returns:
            Dict: 角色配置信息
        """
        return self.character_config
    
    def update_character_state(self, state_data: Dict[str, Any]) -> None:
        """
        更新角色状态
        
        Args:
            state_data: 状态数据字典
        """
        self.character_state.update(state_data)
    
    def get_character_state(self) -> Dict[str, Any]:
        """
        获取角色当前状态
        
        Returns:
            Dict: 角色状态信息
        """
        return self.character_state
    
    def get_personality(self) -> str:
        """
        获取角色性格描述
        
        Returns:
            str: 性格描述
        """
        return self.character_config.get('personality', '亲密、直接的引导者')
    
    def get_greeting(self) -> str:
        """
        获取角色问候语
        
        Returns:
            str: 问候语
        """
        return self.character_config.get('greeting', '你好！')
    
    def get_context(self) -> str:
        """
        获取角色上下文信息
        
        Returns:
            str: 上下文信息
        """
        return self.character_config.get('context', '')
    
    def save_character_config(self) -> bool:
        """
        保存角色配置
        
        Returns:
            bool: 是否成功保存
        """
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.character_config, f, ensure_ascii=False, indent=2)
            logger.info(f"成功保存角色配置: {self.config_path}")
            return True
        except Exception as e:
            logger.error(f"保存角色配置失败: {e}")
            return False
    
    def reload_config(self) -> bool:
        """
        重新加载配置
        
        Returns:
            bool: 是否成功重新加载
        """
        return self.load_character_config()
    
    def get_setting(self, key: str, default: Any = None) -> Any:
        """
        获取特定设置项
        
        Args:
            key: 设置项名称
            default: 默认值
        
        Returns:
            Any: 设置值或默认值
        """
        settings = self.character_config.get('settings', {})
        return settings.get(key, default)


# 创建全局角色管理器实例
_character_manager_instance = None


def get_Aveline_manager() -> AvelineCharacterManager:
    """
    获取Aveline角色管理器实例
    使用单例模式确保全局只有一个实例

    Returns:
        AvelineCharacterManager: 角色管理器实例
    """
    global _character_manager_instance
    if _character_manager_instance is None:
        _character_manager_instance = AvelineCharacterManager()
    return _character_manager_instance


def release_Aveline_manager() -> None:
    """
    释放角色管理器实例
    清理资源
    """
    global _character_manager_instance
    if _character_manager_instance:
        logger.info("释放Aveline角色管理器实例")
        _character_manager_instance = None
