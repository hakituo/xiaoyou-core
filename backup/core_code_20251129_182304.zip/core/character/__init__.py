# Character module initialization
from .aveline import (
    get_aveline_fallback_response,
    get_aveline_character_info,
    format_aveline_message,
    AvelineCharacter
)

__all__ = [
    'get_aveline_fallback_response',
    'get_aveline_character_info',
    'format_aveline_message',
    'AvelineCharacter'
]