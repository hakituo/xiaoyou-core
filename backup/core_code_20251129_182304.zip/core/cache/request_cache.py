#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
请求结果缓存模块

此模块实现了一个高效的请求结果缓存机制，用于存储和检索频繁请求的结果，
以减少重复计算并提高系统性能。
"""

import hashlib
import json
import time
import threading
import asyncio
from typing import Any, Dict, Optional, Union, Callable, Tuple
from functools import wraps
from core.utils.logger import get_logger
from core.config_manager import get_config

logger = get_logger("REQUEST_CACHE")

class RequestCache:
    """请求结果缓存管理器"""
    
    def __init__(self):
        """初始化缓存管理器"""
        # 缓存数据存储
        self._cache: Dict[str, Dict[str, Any]] = {}
        
        # 缓存锁，保证线程安全
        self._lock = threading.RLock()
        
        # 缓存配置
        self._config = {
            "enabled": get_config("cache.enabled", True),
            "max_size": get_config("cache.max_size", 1000),
            "default_ttl": get_config("cache.default_ttl", 300),  # 默认5分钟
            "cleanup_interval": get_config("cache.cleanup_interval", 300),  # 默认5分钟
            "memory_limit_mb": get_config("cache.memory_limit_mb", 512)
        }
        
        # 缓存统计信息
        self._stats = {
            "hits": 0,
            "misses": 0,
            "entries": 0,
            "evictions": 0,
            "memory_usage": 0
        }
        
        # 启动定期清理任务
        self._start_cleanup_task()
        
        logger.info(f"请求缓存初始化完成 - 最大大小: {self._config['max_size']}, 默认TTL: {self._config['default_ttl']}秒")
    
    def _start_cleanup_task(self):
        """启动定期清理过期缓存的任务"""
        def cleanup_task():
            while True:
                try:
                    self.cleanup()
                except Exception as e:
                    logger.error(f"缓存清理任务出错: {e}")
                time.sleep(self._config["cleanup_interval"])
        
        # 创建并启动清理线程
        self._cleanup_thread = threading.Thread(target=cleanup_task, daemon=True)
        self._cleanup_thread.start()
        logger.info("缓存清理任务已启动")
    
    def _generate_key(self, *args, **kwargs) -> str:
        """根据参数生成缓存键
        
        Args:
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            str: 生成的缓存键
        """
        # 将参数转换为可序列化的形式
        key_data = {
            "args": [str(arg) if not isinstance(arg, (str, int, float, bool, type(None))) else arg 
                     for arg in args],
            "kwargs": {k: str(v) if not isinstance(v, (str, int, float, bool, type(None))) else v 
                      for k, v in sorted(kwargs.items())}
        }
        
        # 序列化并计算哈希
        key_str = json.dumps(key_data, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def _calculate_memory_usage(self, data: Any) -> int:
        """估算数据的内存使用量（字节）
        
        Args:
            data: 要估算内存使用量的数据
            
        Returns:
            int: 估算的内存使用量（字节）
        """
        # 简单估算，实际项目中可以使用更精确的方法
        try:
            serialized = json.dumps(data)
            return len(serialized.encode())
        except:
            # 如果无法序列化，返回一个默认值
            return 1024
    
    def get(self, key: str) -> Optional[Any]:
        """从缓存中获取数据
        
        Args:
            key: 缓存键
            
        Returns:
            Any: 缓存的数据，如果缓存不存在或已过期则返回None
        """
        if not self._config["enabled"]:
            return None
        
        with self._lock:
            if key not in self._cache:
                self._stats["misses"] += 1
                return None
            
            # 获取缓存项
            cache_item = self._cache[key]
            current_time = time.time()
            
            # 检查是否过期
            if current_time > cache_item["expires_at"]:
                # 删除过期项
                del self._cache[key]
                self._stats["entries"] -= 1
                self._stats["memory_usage"] -= cache_item["size"]
                self._stats["misses"] += 1
                return None
            
            # 更新访问时间
            cache_item["last_accessed"] = current_time
            
            # 更新统计信息
            self._stats["hits"] += 1
            
            return cache_item["data"]
    
    def set(self, key: str, data: Any, ttl: Optional[int] = None) -> bool:
        """将数据存入缓存
        
        Args:
            key: 缓存键
            data: 要缓存的数据
            ttl: 过期时间（秒），默认为配置中的默认值
            
        Returns:
            bool: 是否成功缓存
        """
        if not self._config["enabled"]:
            return False
        
        # 使用默认TTL如果未指定
        if ttl is None:
            ttl = self._config["default_ttl"]
        
        # 计算数据大小
        data_size = self._calculate_memory_usage(data)
        
        with self._lock:
            # 检查内存限制
            if (self._stats["memory_usage"] + data_size) > (self._config["memory_limit_mb"] * 1024 * 1024):
                logger.warning("缓存内存限制达到，执行清理")
                self._evict_entries(10)  # 驱逐10个条目
                
                # 如果还是超出限制，放弃缓存
                if (self._stats["memory_usage"] + data_size) > (self._config["memory_limit_mb"] * 1024 * 1024):
                    logger.warning(f"数据太大，无法缓存: {data_size / 1024:.2f} KB")
                    return False
            
            # 检查缓存大小限制
            if len(self._cache) >= self._config["max_size"] and key not in self._cache:
                self._evict_entries(1)
            
            # 更新或添加缓存项
            if key in self._cache:
                # 减去旧数据的大小
                self._stats["memory_usage"] -= self._cache[key]["size"]
            else:
                self._stats["entries"] += 1
            
            # 设置缓存项
            current_time = time.time()
            self._cache[key] = {
                "data": data,
                "expires_at": current_time + ttl,
                "created_at": current_time,
                "last_accessed": current_time,
                "size": data_size
            }
            
            # 更新内存使用统计
            self._stats["memory_usage"] += data_size
            
            return True
    
    def delete(self, key: str) -> bool:
        """从缓存中删除数据
        
        Args:
            key: 缓存键
            
        Returns:
            bool: 是否成功删除
        """
        with self._lock:
            if key in self._cache:
                # 更新统计信息
                self._stats["entries"] -= 1
                self._stats["memory_usage"] -= self._cache[key]["size"]
                
                # 删除缓存项
                del self._cache[key]
                return True
            return False
    
    def clear(self) -> None:
        """清空所有缓存"""
        with self._lock:
            self._cache.clear()
            self._stats["entries"] = 0
            self._stats["memory_usage"] = 0
            logger.info("缓存已清空")
    
    def cleanup(self) -> int:
        """清理过期缓存项
        
        Returns:
            int: 删除的过期项数量
        """
        if not self._config["enabled"]:
            return 0
        
        with self._lock:
            current_time = time.time()
            expired_keys = [k for k, v in self._cache.items() if current_time > v["expires_at"]]
            
            # 删除过期项
            for key in expired_keys:
                self._stats["memory_usage"] -= self._cache[key]["size"]
                del self._cache[key]
            
            # 更新统计信息
            expired_count = len(expired_keys)
            self._stats["entries"] -= expired_count
            
            if expired_count > 0:
                logger.info(f"清理了 {expired_count} 个过期缓存项")
            
            return expired_count
    
    def _evict_entries(self, count: int) -> int:
        """驱逐最久未使用的缓存项
        
        Args:
            count: 要驱逐的条目数量
            
        Returns:
            int: 实际驱逐的条目数量
        """
        with self._lock:
            # 获取按最后访问时间排序的条目
            sorted_items = sorted(self._cache.items(), key=lambda x: x[1]["last_accessed"])
            
            # 驱逐最久未使用的条目
            evicted = 0
            for key, _ in sorted_items[:count]:
                self._stats["memory_usage"] -= self._cache[key]["size"]
                del self._cache[key]
                evicted += 1
            
            # 更新统计信息
            self._stats["entries"] -= evicted
            self._stats["evictions"] += evicted
            
            if evicted > 0:
                logger.info(f"为腾出空间，驱逐了 {evicted} 个缓存项")
            
            return evicted
    
    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息
        
        Returns:
            Dict: 缓存统计信息
        """
        with self._lock:
            hit_rate = self._stats["hits"] / (self._stats["hits"] + self._stats["misses"]) * 100 \
                      if (self._stats["hits"] + self._stats["misses"]) > 0 else 0
            
            return {
                **self._stats,
                "hit_rate": round(hit_rate, 2),
                "memory_usage_mb": round(self._stats["memory_usage"] / (1024 * 1024), 2),
                "cache_size": len(self._cache)
            }
    
    def update_config(self, **kwargs) -> None:
        """更新缓存配置
        
        Args:
            **kwargs: 要更新的配置项
        """
        with self._lock:
            for key, value in kwargs.items():
                if key in self._config:
                    self._config[key] = value
                    logger.info(f"缓存配置更新: {key} = {value}")
            
            # 如果禁用缓存，清空所有缓存
            if not self._config["enabled"]:
                self.clear()

# 创建全局缓存实例
_request_cache_instance = None
_request_cache_lock = threading.RLock()

def get_request_cache() -> RequestCache:
    """获取全局缓存实例
    
    Returns:
        RequestCache: 全局缓存实例
    """
    global _request_cache_instance
    
    with _request_cache_lock:
        if _request_cache_instance is None:
            _request_cache_instance = RequestCache()
        
        return _request_cache_instance

# 缓存装饰器
def cached(ttl: Optional[int] = None, key_generator: Optional[Callable] = None):
    """缓存函数结果的装饰器
    
    Args:
        ttl: 缓存过期时间（秒）
        key_generator: 自定义缓存键生成函数
        
    Returns:
        Callable: 装饰后的函数
    """
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            # 获取缓存实例
            cache = get_request_cache()
            
            # 生成缓存键
            if key_generator:
                cache_key = key_generator(*args, **kwargs)
            else:
                # 跳过self/cls参数
                cache_args = args[1:] if args else args
                cache_key = f"{func.__module__}.{func.__name__}:{cache._generate_key(*cache_args, **kwargs)}"
            
            # 尝试从缓存获取结果
            result = cache.get(cache_key)
            if result is not None:
                logger.debug(f"缓存命中: {func.__name__}")
                return result
            
            # 缓存未命中，执行函数
            logger.debug(f"缓存未命中: {func.__name__}")
            result = await func(*args, **kwargs)
            
            # 缓存结果
            cache.set(cache_key, result, ttl)
            
            return result
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            # 获取缓存实例
            cache = get_request_cache()
            
            # 生成缓存键
            if key_generator:
                cache_key = key_generator(*args, **kwargs)
            else:
                # 跳过self/cls参数
                cache_args = args[1:] if args else args
                cache_key = f"{func.__module__}.{func.__name__}:{cache._generate_key(*cache_args, **kwargs)}"
            
            # 尝试从缓存获取结果
            result = cache.get(cache_key)
            if result is not None:
                logger.debug(f"缓存命中: {func.__name__}")
                return result
            
            # 缓存未命中，执行函数
            logger.debug(f"缓存未命中: {func.__name__}")
            result = func(*args, **kwargs)
            
            # 缓存结果
            cache.set(cache_key, result, ttl)
            
            return result
        
        # 根据函数类型返回适当的包装器
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator

# 缓存管理函数
def clear_cache() -> None:
    """清空所有缓存"""
    get_request_cache().clear()

def get_cache_stats() -> Dict[str, Any]:
    """获取缓存统计信息
    
    Returns:
        Dict: 缓存统计信息
    """
    return get_request_cache().get_stats()

def update_cache_config(**kwargs) -> None:
    """更新缓存配置
    
    Args:
        **kwargs: 要更新的配置项
    """
    get_request_cache().update_config(**kwargs)