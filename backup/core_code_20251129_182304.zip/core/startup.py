#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
小优AI 统一启动模块
管理所有服务的启动、配置和生命周期
"""

import os
import sys
import time
import signal
import logging
import argparse
import asyncio
import threading
import multiprocessing
import gc
from typing import Dict, List, Optional, Callable, Any

# 配置日志
logs_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
os.makedirs(logs_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(
            os.path.join(logs_dir, f"xiaoyou_{time.strftime('%Y%m%d_%H%M%S')}.log"), encoding="utf-8"
        ),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("xiaoyou.startup")

# 添加项目根目录到系统路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入Aveline服务初始化函数
from services.fallback_service import initialize_aveline_service


class ServiceManager:
    """服务管理器，负责启动、监控和关闭所有服务"""

    def __init__(self):
        self.config = self._load_config()
        self.processes = []
        self.running = False
        self._setup_signal_handlers()
        self._optimize_environment()

        # 初始化数据库（按需）
        self.initialize_database()
        
        # 初始化Aveline服务
        initialize_aveline_service()
        logger.info("Aveline服务初始化完成")

    def _load_config(self) -> Dict[str, Any]:
        """加载配置信息，使用统一配置管理系统"""
        # 基础配置（默认值）
        local_config = {
            "host": os.environ.get("XIAOYOU_HOST", "0.0.0.0"),
            "http_port": int(os.environ.get("XIAOYOU_HTTP_PORT", "5000")),
            "ws_port": int(os.environ.get("XIAOYOU_WS_PORT", "8765")),
            "api_port": int(os.environ.get("XIAOYOU_API_PORT", "8000")),
            "device": (
                "cuda" if os.environ.get("XIAOYOU_USE_CUDA", "0") == "1" else "cpu"
            ),
            "model_dir": os.environ.get("XIAOYOU_MODEL_DIR", "./models"),
            "log_level": os.environ.get("XIAOYOU_LOG_LEVEL", "INFO"),
            "max_memory": os.environ.get("XIAOYOU_MAX_MEMORY", "80%"),
            "auto_reload": os.environ.get("XIAOYOU_AUTO_RELOAD", "True").lower()
            == "true",
        }

        # 使用统一配置管理系统
        try:
            from config import get_settings

            logger.info("使用统一配置管理系统加载配置")

            # 从统一配置中加载相关设置
            # HTTP端口
            ws_port = get_settings().get("app.websocket.port")
            if ws_port and "ws_port" not in os.environ:
                local_config["ws_port"] = int(ws_port)

            # 服务器端口
            server_port = get_settings().get("app.server.port")
            if server_port and "http_port" not in os.environ:
                local_config["http_port"] = int(server_port)

            # 日志级别
            log_level = get_settings().get("app.logging.level")
            if log_level and "log_level" not in os.environ:
                local_config["log_level"] = log_level

            # 模型路径
            model_path = get_settings().get("app.model.path")
            if model_path and "model_dir" not in os.environ:
                local_config["model_dir"] = model_path

            # 设备配置（从env.yaml）
            device_type = get_settings().get("cuda.device_id")
            if device_type is not None and "device" not in os.environ:
                local_config["device"] = "cuda"

            logger.debug(f"加载的配置: {local_config}")

        except ImportError as e:
            logger.warning(f"未找到配置管理模块，使用默认配置: {e}")
        except Exception as e:
            logger.error(f"加载配置时出错: {e}", exc_info=True)

        return local_config

    def _setup_signal_handlers(self):
        """设置信号处理器，用于优雅关闭"""

        def signal_handler(sig, frame):
            logger.info(f"收到信号 {sig}，正在准备退出...")
            self.stop_all_services()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

    def _optimize_environment(self):
        """优化运行环境"""
        # 优化垃圾回收
        gc.set_threshold(5000, 10, 10)

        # 尝试设置进程优先级（Windows系统）
        if sys.platform == "win32":
            try:
                import win32api
                import win32process

                win32process.SetPriorityClass(
                    win32api.GetCurrentProcess(),
                    win32process.BELOW_NORMAL_PRIORITY_CLASS,
                )
                logger.info("进程优先级已设置为低于正常")
            except Exception as e:
                logger.warning(f"无法设置进程优先级: {e}")
    async def start_websocket_server(self):
        """启动WebSocket服务器"""
        try:
            logger.info(
                f"启动WebSocket服务器，监听在 {self.config['host']}:{self.config['ws_port']}"
            )
            # 首先尝试导入ws_server模块
            try:
                from ws_server import main
            except ModuleNotFoundError:
                logger.warning("未找到ws_server模块，WebSocket功能将不可用")
                logger.warning("请运行 'pip install -r requirements.txt' 安装依赖")
                return

            await main(port=self.config["ws_port"])
        except Exception as e:
            logger.error(f"启动WebSocket服务器失败: {e}", exc_info=True)
            # 不再抛出异常，允许系统继续运行
            logger.warning("WebSocket服务启动失败，但系统将继续运行其他服务")
def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="小优AI系统启动脚本")
    parser.add_argument("--http-port", type=int, help="HTTP服务端口")
    parser.add_argument("--ws-port", type=int, help="WebSocket服务端口")
    parser.add_argument("--api-port", type=int, help="API服务端口")
    parser.add_argument("--device", choices=["cpu", "cuda"], help="运行设备")
    parser.add_argument("--model-dir", type=str, help="模型目录")
    parser.add_argument(
        "--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], help="日志级别"
    )
    parser.add_argument(
        "--services",
        nargs="+",
        choices=["flask", "websocket", "api"],
        help="要启动的服务",
    )
    return parser.parse_args()


def main():
    """主函数"""
    args = parse_arguments()

    # 设置环境变量
    if args.http_port:
        os.environ["XIAOYOU_HTTP_PORT"] = str(args.http_port)
    if args.ws_port:
        os.environ["XIAOYOU_WS_PORT"] = str(args.ws_port)
    if args.api_port:
        os.environ["XIAOYOU_API_PORT"] = str(args.api_port)
    if args.device:
        os.environ["XIAOYOU_USE_CUDA"] = "1" if args.device == "cuda" else "0"
    if args.model_dir:
        os.environ["XIAOYOU_MODEL_DIR"] = args.model_dir
    if args.log_level:
        os.environ["XIAOYOU_LOG_LEVEL"] = args.log_level

    # 创建并运行服务管理器
    manager = ServiceManager()
    manager.run(services=args.services)


if __name__ == "__main__":
    main()
