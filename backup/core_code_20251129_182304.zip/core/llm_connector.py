import asyncio
import os
import logging
import json
from typing import List, Dict, Optional
from memory.memory_manager import MemoryManager

# 导入我们新创建的文本推理模块
from core.text_infer import load_model, generate_response
# 导入LLM代理客户端
from core.llm_proxy_client import get_global_llm_proxy_client
# 导入统一错误响应
from core.api.error_response import ErrorCode, APIError
import io
import base64

# Configure logger
logger = logging.getLogger(__name__)

# 配置代理模式
use_llm_proxy = os.environ.get("LLM_USE_PROXY", "false").lower() == "true"
# 尝试从配置文件读取
from pathlib import Path
config_path = Path("config/integrated_config.py")
if config_path.exists():
    try:
        # 动态导入配置
        import importlib.util
        spec = importlib.util.spec_from_file_location("integrated_config", config_path)
        config_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(config_module)
        if hasattr(config_module, "get_settings"):
            proxy_setting = config_module.get_settings().get("llm.use_proxy", "false")
            use_llm_proxy = str(proxy_setting).lower() == "true"
    except Exception as e:
        logger.warning(f"读取配置时出错: {e}")

logger.info(f"LLM模式: {'代理模式' if use_llm_proxy else '直接模式'}")


# =======================================================
# 1. Initialize Model Instance
# =======================================================
# 预先加载模型以提高首次响应速度
try:
    load_model()
except Exception:
    pass

# Custom AI Personality Configuration (can be set for personalized responses)


# =======================================================
# 2. Command System
# =======================================================
class CommandHandler:
    """Command processing system using dictionary mapping for efficient command handling"""

    def __init__(self):
        # Command mapping dictionary
        self.commands = {
            "clear": self._handle_clear,
            "save": self._handle_save,
            "load": self._handle_load,
            "memory": self._handle_memory,
            "setmemory": self._handle_setmemory,
            "system": self._handle_system,
            "help": self._handle_help,
        }

        # Precompile help text
        self._help_text = "\n".join(
            [
                "Available commands:",
                "/clear - Clear history",
                "/save - Save history to file",
                "/load - Load history from file",
                "/memory - View current memory status",
                "/setmemory [number] - Set maximum history length",
                "/system - View system information",
                "/help - Show this help information",
            ]
        )

    def handle(self, text, memory: MemoryManager):
        """
        Process commands from user input

        Args:
            text: User input text
            memory: Memory manager instance

        Returns:
            tuple: (is_command, response_text)
        """
        if not text.startswith("/"):
            return False, ""

        command_parts = text[1:].strip().split(" ", 1)
        command = command_parts[0].lower()
        args = command_parts[1] if len(command_parts) > 1 else ""

        if command in self.commands:
            return True, self.commands[command](memory, args)

        return True, f"Unknown command: {command}, use /help to see available commands"

    def _handle_clear(self, memory, args):
        return memory.clear()

    def _handle_save(self, memory, args):
        return memory.save_history()

    def _handle_load(self, memory, args):
        return memory.load_history()

    def _handle_memory(self, memory, args):
        stats = memory.get_stats()
        return f"Memory status: Current history {stats['current_length']}/{stats['max_length']} messages"

    def _handle_setmemory(self, memory, args):
        try:
            max_len = int(args)
            # Add boundary checks to prevent setting too small or too large values
            if max_len < 1 or max_len > 100:
                return "Please set a valid number between 1-100"
            return memory.set_max_length(max_len)
        except ValueError:
            return "Please enter a valid number for the maximum history length"

    def _handle_system(self, memory, args):
        """Handle system information command"""
        import sys

        return f"System Information:\nPython: {sys.version}\nMemory status: {memory.get_stats()}\n"

    def _handle_help(self, memory, args):
        return self._help_text


# Create command handler instance
command_handler = CommandHandler()


# =======================================================
# 4. Status and Shutdown Functions
# =======================================================

async def get_llm_status() -> Dict:
    """
    获取LLM服务状态
    
    Returns:
        状态信息字典
    """
    if use_llm_proxy:
        # 代理模式
        try:
            proxy_client = get_global_llm_proxy_client()
            proxy_status = await proxy_client.get_status()
            return {
                "mode": "proxy",
                "proxy_status": proxy_status,
                "connected": proxy_client.connected
            }
        except Exception as e:
            logger.error(f"获取代理状态失败: {e}")
            return {
                "mode": "proxy",
                "error": str(e),
                "connected": False
            }
    else:
        # 直接模式
        return {
            "mode": "direct",
            "status": "local_model"
        }


async def shutdown_llm_services():
    """
    关闭LLM相关服务
    """
    if use_llm_proxy:
        # 关闭代理客户端
        try:
            proxy_client = get_global_llm_proxy_client()
            await proxy_client.shutdown()
            logger.info("LLM代理客户端已关闭")
        except Exception as e:
            logger.error(f"关闭LLM代理客户端失败: {e}")
    # 直接模式下的资源释放由text_infer模块处理
    logger.info("LLM服务已关闭")


# Function compatible with old interface
def handle_command(text, memory: MemoryManager):
    """Process user commands synchronously"""
    return command_handler.handle(text, memory)


async def handle_command_async(text, memory: MemoryManager):
    """Process user commands asynchronously"""
    # For simplicity, we'll just call the synchronous version
    return await asyncio.to_thread(handle_command, text, memory)


# =======================================================
# 3. Optimized LLM Query Function (Final Revision: async + asyncio.to_thread + Error Handling)
# =======================================================


def _process_image_file(file_path):
    """
    Process image file for analysis

    Args:
        file_path: Path to the image file

    Returns:
        str: Base64 encoded image data
    """
    try:
        # Check if file exists
        if not os.path.exists(file_path):
            logger.error(f"Image file not found: {file_path}")
            return None

        # Open and process the image
        with open(file_path, "rb") as f:
            image_data = f.read()

        # Encode image to base64
        encoded_image = base64.b64encode(image_data).decode("utf-8")
        return encoded_image
    except Exception as e:
        logger.error(f"Error processing image file: {e}")
        return None


def _is_image_query(text):
    """
    Check if the query contains image-related keywords

    Args:
        text: User input text

    Returns:
        bool: True if contains image keywords
    """
    image_keywords = [
        "图片",
        "图像",
        "照片",
        "分析",
        "描述",
        "显示",
        "内容",
        "识别",
        "是什么",
    ]
    return any(keyword in text for keyword in image_keywords)


async def _query_proxy_model(text: str, memory: MemoryManager) -> str:
    """
    使用代理客户端查询LLM模型
    
    Args:
        text: 用户输入文本
        memory: 记忆管理器实例
        
    Returns:
        生成的响应文本
    """
    try:
        # 获取代理客户端
        proxy_client = get_global_llm_proxy_client()
        
        # 构建消息历史
        history = memory.get_history()
        
        # 添加当前用户消息
        user_message = {"role": "user", "content": text}
        messages = history + [user_message]
        
        # 处理图像查询
        if _is_image_query(text):
            # 检查是否有图像分析的特殊处理
            messages.insert(0, {
                "role": "system",
                "content": "You are an AI assistant that can analyze images. Please provide a detailed description of the image content."
            })
        
        # 发送请求
        response = await proxy_client.chat(messages=messages)
        
        # 从响应中提取内容
        if isinstance(response, dict):
            reply_text = response.get("content", "")
        else:
            reply_text = str(response)
            
        # 检查响应是否为空或过短
        if not reply_text or len(reply_text.strip()) < 5:
            logger.warning(f"Empty or too short proxy response: {reply_text}")
            return "抱歉，我无法生成有效的响应。请尝试用不同的方式提问。"
            
        return reply_text
    except Exception as e:
        logger.error(f"Error in proxy query: {e}", exc_info=True)
        return f"代理服务错误: {str(e)}"

async def query_model(text, memory: MemoryManager):
    """
    Main query function to process user input and generate response

    Args:
        text: User input text
        memory: Memory manager instance

    Returns:
        str: Generated response
    """
    # First check if it's a command
    is_command, command_response = await handle_command_async(text, memory)
    if is_command:
        return command_response

    # 根据模式选择不同的查询方式
    if use_llm_proxy:
        # 使用代理模式
        logger.info("Using LLM proxy for query")
        return await _query_proxy_model(text, memory)
    else:
        # 直接模式
        return await _query_direct_model(text, memory)

async def _query_direct_model(text, memory: MemoryManager):
    """
    直接调用本地模型生成响应
    
    Args:
        text: 用户输入文本
        memory: 记忆管理器实例
        
    Returns:
        生成的响应文本
    """
    # Add user message to history
    user_content = f"User says: {text}"

    # Create history
    history = memory.get_history()

    # Check if we need to handle image-related content
    if _is_image_query(text):
        # Look for recent file uploads in history that might contain image paths
        image_paths = []
        for msg in reversed(history):
            if msg.get("role") == "user" and "image" in msg.get("content", "").lower():
                # Extract potential image path from message content
                if "file_path" in msg.get("content", ""):
                    # This is a placeholder - in a real implementation, you would extract the actual path
                    image_paths.append("/path/to/recent/image.jpg")
                break

        # If we found image paths, process the first one
        if image_paths:
            encoded_image = _process_image_file(image_paths[0])
            if encoded_image:
                # Add multimodal prompt to user content
                user_content += "\n[Image analysis request]"
                logger.info("Processing image analysis request")

    # Add the current user message to history
    history = history + [{"role": "user", "content": user_content}]

    # Generate response with timeout control
    try:
        # 设置异步超时，增加到5分钟以适应模型处理复杂请求
        timeout_seconds = 300  # 5分钟超时

        async def generate_with_timeout():
            # For image analysis, we'll add a special prompt to guide the model
            if _is_image_query(text):
                # Prepend system message for image analysis
                system_prompt = {
                    "role": "system",
                    "content": "You are an AI assistant that can analyze images. Please provide a detailed description of the image content, including objects, text, colors, and overall scene. Then address the user's specific question about the image.",
                }
                history_with_system = [system_prompt] + history
                return await asyncio.to_thread(generate_response, history_with_system)
            else:
                # Standard text generation
                return await asyncio.to_thread(generate_response, history)

        # 使用asyncio.wait_for添加超时控制
        reply_text = await asyncio.wait_for(
            generate_with_timeout(), timeout=timeout_seconds
        )

        # 检查响应是否为空或过短
        if not reply_text or len(reply_text.strip()) < 5:
            logger.warning(f"Empty or too short response: {reply_text}")
            return "抱歉，我无法生成有效的响应。请尝试用不同的方式提问。"

        return reply_text
    except asyncio.TimeoutError:
        logger.error("Response generation timeout at connector level")
        raise APIError(
            error_code=ErrorCode.LLM_RATE_LIMITED,
            message="抱歉，响应生成超时。请尝试更简洁的问题。"
        )
    except TimeoutError:
        logger.error("Timeout during model inference")
        raise APIError(
            error_code=ErrorCode.LLM_RATE_LIMITED,
            message="抱歉，模型处理超时。请稍后再试。"
        )
    except APIError:
        # 重新抛出已经标准化的错误
        raise
    except Exception as e:
        logger.error(f"Error generating response: {e}", exc_info=True)
        raise APIError(
            error_code=ErrorCode.LLM_INFERENCE_ERROR,
            message="抱歉，我在生成回复时遇到了问题。请稍后再试。"
        ) from e
