"""
异步工具模块
提供统一的异步工具函数和装饰器
"""
import asyncio
import functools
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Any, TypeVar, cast, Optional

logger = logging.getLogger(__name__)

# 定义类型变量
F = TypeVar('F', bound=Callable[..., Any])


# 全局线程池
_thread_pool = None


def get_thread_pool() -> ThreadPoolExecutor:
    """
    获取全局线程池
    
    Returns:
        ThreadPoolExecutor: 线程池实例
    """
    global _thread_pool
    if _thread_pool is None:
        # 根据CPU核心数创建线程池
        import multiprocessing
        cpu_count = multiprocessing.cpu_count()
        _thread_pool = ThreadPoolExecutor(max_workers=cpu_count * 2)
        logger.info(f"创建全局线程池，工作线程数: {cpu_count * 2}")
    return _thread_pool
async def run_in_thread(func: Callable[..., Any], *args, **kwargs) -> Any:
    """
    在线程池中运行同步函数
    
    Args:
        func: 要运行的同步函数
        *args: 函数参数
        **kwargs: 函数关键字参数
    
    Returns:
        函数执行结果
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        get_thread_pool(),
        functools.partial(func, *args, **kwargs)
    )


async def to_async(func: Callable[..., Any], *args, **kwargs) -> Any:
    """
    将同步函数转换为异步执行
    
    Args:
        func: 要转换的函数
        *args: 函数参数
        **kwargs: 函数关键字参数
    
    Returns:
        函数执行结果
    """
    if asyncio.iscoroutinefunction(func):
        # 如果已经是协程函数，直接调用
        return await func(*args, **kwargs)
    else:
        # 否则在线程池中运行
        return await run_in_thread(func, *args, **kwargs)
class AsyncContextManager:
    """
    异步上下文管理器基类
    """
    async def __aenter__(self):
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.cleanup()
    
    async def initialize(self):
        """
        初始化方法，子类实现
        """
        pass
    
    async def cleanup(self):
        """
        清理方法，子类实现
        """
        pass
async def retry_async(
    func: Callable[..., Any],
    max_retries: int = 3,
    delay: float = 1.0,
    backoff_factor: float = 2.0,
    exceptions: tuple = (Exception,)
) -> Any:
    """
    异步重试装饰器
    
    Args:
        func: 要重试的函数
        max_retries: 最大重试次数
        delay: 初始延迟时间（秒）
        backoff_factor: 退避因子
        exceptions: 要捕获的异常类型
    
    Returns:
        函数执行结果
    """
    retries = 0
    current_delay = delay
    
    while True:
        try:
            return await to_async(func)
        except exceptions as e:
            retries += 1
            if retries > max_retries:
                logger.error(f"达到最大重试次数 {max_retries}，函数 {func.__name__} 执行失败: {e}")
                raise
            
            logger.warning(f"函数 {func.__name__} 执行失败，{retries} 秒后重试 ({retries}/{max_retries}): {e}")
            await asyncio.sleep(current_delay)
            current_delay *= backoff_factor


async def timeout(
    func: Callable[..., Any],
    timeout_seconds: float,
    *args, **kwargs
) -> Any:
    """
    带超时的异步执行
    
    Args:
        func: 要执行的函数
        timeout_seconds: 超时时间（秒）
        *args: 函数参数
        **kwargs: 函数关键字参数
    
    Returns:
        函数执行结果
    
    Raises:
        asyncio.TimeoutError: 当执行超时时
    """
    return await asyncio.wait_for(to_async(func, *args, **kwargs), timeout=timeout_seconds)


async def gather_with_concurrency(
    limit: int,
    *coros_or_futures,
    return_exceptions: bool = False
) -> list:
    """
    限制并发数的gather
    
    Args:
        limit: 最大并发数
        *coros_or_futures: 协程或Future对象
        return_exceptions: 是否将异常作为结果返回
    
    Returns:
        结果列表
    """
    semaphore = asyncio.Semaphore(limit)
    
    async def sem_coro(coro):
        async with semaphore:
            return await coro
    
    sem_coros = [sem_coro(c) for c in coros_or_futures]
    return await asyncio.gather(*sem_coros, return_exceptions=return_exceptions)


class AsyncTimer:
    """
    异步定时器类
    """
    def __init__(self):
        self.start_time = 0
        self.end_time = 0
    
    async def __aenter__(self):
        self.start_time = time.time()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.end_time = time.time()
        return False
    
    @property
    def duration(self) -> float:
        """获取执行持续时间"""
        return self.end_time - self.start_time


async def run_periodic_task(
    task_func: Callable[..., Any],
    interval: float,
    *args, **kwargs
) -> asyncio.Task:
    """
    运行周期性任务
    
    Args:
        task_func: 要周期性执行的函数
        interval: 执行间隔（秒）
        *args: 函数参数
        **kwargs: 函数关键字参数
    
    Returns:
        asyncio.Task: 任务对象
    """
    async def periodic_task():
        while True:
            try:
                await to_async(task_func, *args, **kwargs)
            except Exception as e:
                logger.error(f"周期性任务执行失败: {e}", exc_info=True)
            await asyncio.sleep(interval)
    
    task = asyncio.create_task(periodic_task())
    logger.info(f"已创建周期性任务，间隔: {interval}秒")
    return task
def ensure_event_loop() -> asyncio.AbstractEventLoop:
    """确保存在活跃的事件循环，如果不存在则创建一个新的。"""
    try:
        loop = asyncio.get_event_loop()
        return loop
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop


# 导出常用函数和类
__all__ = [
    'get_thread_pool',
    'close_thread_pool',
    'run_in_thread',
    'to_async',
    'async_wrap',
    'sync_wrap',
    'AsyncContextManager',
    'async_cache',
    'retry_async',
    'timeout',
    'gather_with_concurrency',
    'AsyncTimer',
    'run_periodic_task',
    'ensure_event_loop',
    'is_async_callable'
]