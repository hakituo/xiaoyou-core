"""工具模块初始化文件"""
# 导出常用功能
from .logger import get_logger, debug, info, warning, error, critical, default_logger
from .profiler import ResourceProfiler, global_profiler
from .report import ReportGenerator, global_report_generator, plot_tts_results
from .common import ensure_directory, safe_file_operation, generate_hash, run_in_thread, merge_dicts
# 创建全局实例
if "global_profiler" not in globals():
    global_profiler = ResourceProfiler()
if "global_report_generator" not in globals():
    global_report_generator = ReportGenerator()
__all__ = [
    # 日志相关
    "get_logger",
    "debug",
    "info",
    "warning",
    "error",
    "critical",
    "default_logger",
    # 性能分析相关
    "ResourceProfiler",
    "global_profiler",
    # 报告生成相关
    "ReportGenerator",
    "global_report_generator",
    "plot_tts_results",
    # 通用工具相关
    "ensure_directory",
    "safe_file_operation",
    "generate_hash",
    "run_in_thread",
    "merge_dicts",
]
