#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强版回复策略模块

功能特点：
1. 基于对话历史的上下文感知回复
2. 个性化回复生成
3. 主题相关回复
4. 情感感知
5. 回复长度自适应
6. 回复多样性
7. 智能提示词优化
"""

import sys
import logging
import re
import random
from typing import List, Dict, Any, Optional, Union, Tuple
from pathlib import Path

# 添加项目根目录到Python路径
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# 导入增强版记忆管理器
from memory.enhanced_memory_manager import get_memory_manager, EnhancedMemoryManager

# 配置日志
logger = logging.getLogger(__name__)

# 常量定义
DEFAULT_MAX_REPLY_LENGTH = 500
MAX_REPLY_LENGTH_MIN = 100
MAX_REPLY_LENGTH_MAX = 2000

class EnhancedReplyStrategy:
    """
    增强版回复策略类，负责生成上下文感知的个性化回复
    """
    def __init__(self, memory_manager: Optional[EnhancedMemoryManager] = None,
                 user_id: str = "default",
                 max_reply_length: int = DEFAULT_MAX_REPLY_LENGTH,
                 use_personalization: bool = True):
        """
        初始化增强版回复策略
        
        Args:
            memory_manager: 增强版记忆管理器实例，如不提供则自动创建
            user_id: 用户ID
            max_reply_length: 最大回复长度
            use_personalization: 是否启用个性化回复
        """
        # 初始化记忆管理器
        if memory_manager is not None:
            self.memory_manager = memory_manager
            self.user_id = memory_manager.user_id
        else:
            self.user_id = user_id
            self.memory_manager = get_memory_manager(user_id=user_id)
        
        # 参数验证和设置
        self.max_reply_length = max(MAX_REPLY_LENGTH_MIN, min(max_reply_length, MAX_REPLY_LENGTH_MAX))
        self.use_personalization = bool(use_personalization)
        
        # 初始化属性
        self.emotion_patterns = self._load_emotion_patterns()
        self.topics_map = self._load_topics_map()
        self.reply_templates = self._load_reply_templates()
    
    def _load_emotion_patterns(self) -> Dict[str, List[str]]:
        """
        加载情感模式配置
        
        Returns:
            Dict[str, List[str]]: 情感类别和对应的关键词列表
        """
        return {
            "happy": ["高兴", "开心", "愉快", "兴奋", "喜欢", "满意", "太棒了", "太好了", "优秀", "赞"],
            "sad": ["难过", "悲伤", "伤心", "沮丧", "失望", "可惜", "遗憾", "不幸"],
            "angry": ["生气", "愤怒", "恼火", "不满", "讨厌", "可恨", "烦人", "烦躁"],
            "surprised": ["惊讶", "吃惊", "震惊", "没想到", "意外", "神奇"],
            "anxious": ["焦虑", "担心", "紧张", "害怕", "恐惧", "不安"],
            "neutral": ["还行", "一般", "普通", "无所谓", "随便", "都可以"]
        }
    
    def _load_topics_map(self) -> Dict[str, List[str]]:
        """
        加载主题映射配置
        
        Returns:
            Dict[str, List[str]]: 主题和对应的关键词列表
        """
        return {
            "技术": ["编程", "代码", "软件", "算法", "开发", "项目", "架构", "框架", "数据结构", "API", "函数", "变量"],
            "生活": ["吃饭", "睡觉", "旅游", "购物", "电影", "音乐", "运动", "健康", "家庭", "朋友", "爱情"],
            "工作": ["会议", "报告", "任务", "截止日期", "同事", "客户", "公司", "老板", "团队", "效率", "项目"],
            "学习": ["考试", "作业", "书籍", "课程", "学校", "成绩", "老师", "学生", "复习", "预习", "研究"],
            "娱乐": ["游戏", "视频", "直播", "社交媒体", "明星", "综艺", "动漫", "小说", "追剧", "听歌", "刷视频"],
            "健康": ["健身", "饮食", "减肥", "营养", "运动", "医生", "医院", "疾病", "健康", "体检", "睡眠"],
            "科技": ["手机", "电脑", "设备", "科技", "创新", "AI", "人工智能", "互联网", "APP", "软件", "硬件"],
            "财经": ["股票", "投资", "理财", "经济", "金融", "市场", "财富", "收入", "支出", "预算", "消费"],
        }
    
    def _load_reply_templates(self) -> Dict[str, List[str]]:
        """
        加载回复模板
        
        Returns:
            Dict[str, List[str]]: 回复模板字典
        """
        return {
            "greeting": [
                "你好！有什么我可以帮助你的吗？",
                "嗨！很高兴再次见到你。今天有什么想聊的？",
                "你好啊！今天感觉怎么样？",
                "嗨！请问需要我为你提供什么帮助吗？"
            ],
            "farewell": [
                "好的，祝你有美好的一天！",
                "如果还有其他问题，随时找我哦！",
                "很高兴能帮到你，再见！",
                "有需要时随时回来找我，祝您愉快！"
            ],
            "asking_help": [
                "我很乐意帮助你，请问具体需要了解什么？",
                "请告诉我更多细节，这样我能更好地帮助你。",
                "为了更好地解答你的问题，请提供更多相关信息。",
                "没问题，请问有什么具体的需求吗？"
            ],
            "providing_info": [
                "根据我的了解，相关信息如下：",
                "这里有一些可能对你有帮助的信息：",
                "基于你的问题，我为你整理了以下内容：",
                "我找到了一些相关信息，希望对你有帮助："
            ],
            "technical_question": [
                "关于技术问题，我的建议是：",
                "从技术角度分析，你可以考虑：",
                "这个技术问题可以这样解决：",
                "关于这个技术问题，我了解到："
            ]
        }
    def _detect_emotions(self, message: str) -> List[Tuple[str, float]]:
        """
        检测消息中的情感
        
        Args:
            message: 消息内容（小写）
            
        Returns:
            List[Tuple[str, float]]: 情感类别和置信度列表
        """
        emotions = []
        
        for emotion, keywords in self.emotion_patterns.items():
            match_count = 0
            total_keywords = len(keywords)
            
            for keyword in keywords:
                if keyword in message:
                    match_count += 1
            
            if match_count > 0:
                # 计算置信度
                confidence = min(1.0, match_count / min(total_keywords, 3))  # 最多考虑3个关键词
                emotions.append((emotion, confidence))
        
        # 按置信度排序
        emotions.sort(key=lambda x: x[1], reverse=True)
        
        # 如果没有检测到特定情感，默认中性
        if not emotions:
            emotions.append(("neutral", 0.6))
        
        return emotions[:2]  # 最多返回前两个情感
    
    def _detect_topics(self, message: str) -> List[str]:
        """
        检测消息中的主题
        
        Args:
            message: 消息内容（小写）
            
        Returns:
            List[str]: 主题列表
        """
        topics = []
        topic_matches = {}
        
        for topic, keywords in self.topics_map.items():
            match_count = 0
            
            for keyword in keywords:
                if keyword in message:
                    match_count += 1
            
            if match_count > 0:
                topic_matches[topic] = match_count
        
        # 按匹配数量排序
        sorted_topics = sorted(topic_matches.items(), key=lambda x: x[1], reverse=True)
        
        # 取匹配数最多的主题
        for topic, _ in sorted_topics[:2]:  # 最多返回2个主题
            topics.append(topic)
        
        return topics
    
    def _detect_question_types(self, message: str) -> List[str]:
        """
        检测问题类型
        
        Args:
            message: 消息内容
            
        Returns:
            List[str]: 问题类型列表
        """
        question_types = []
        
        # 问题类型模式
        patterns = {
            "who": [r"谁是", r"是谁", r"什么人", r"哪位"],
            "what": [r"什么是", r"是什么", r"什么", r"什么意思"],
            "when": [r"什么时候", r"何时", r"时间", r"日期"],
            "where": [r"在哪里", r"在哪里", r"地点", r"位置"],
            "why": [r"为什么", r"为啥", r"原因", r"为何"],
            "how": [r"如何", r"怎么", r"怎样", r"方法"],
            "yes_no": [r"是吗", r"是不是", r"对吗", r"对不对", r"会不会"],
            "suggestion": [r"建议", r"推荐", r"有什么", r"应该"],
            "definition": [r"定义", r"是什么意思", r"指的是"],
            "comparison": [r"比较", r"哪个", r"哪个好", r"区别"]
        }
        
        for q_type, type_patterns in patterns.items():
            for pattern in type_patterns:
                if re.search(pattern, message):
                    question_types.append(q_type)
                    break
        
        # 检查是否为问号结尾的一般问题
        if "?" in message or "？" in message and not question_types:
            question_types.append("general")
        
        return question_types
# 便捷函数
# 便捷函数：获取优化提示词
# 单元测试入口点
if __name__ == "__main__":
    # 设置基本日志
    logging.basicConfig(level=logging.INFO, 
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # 简单的功能测试
    print("测试增强版回复策略模块...")
    
    # 创建实例
    strategy = EnhancedReplyStrategy(user_id="test_user")
    
    # 测试分析功能
    test_message = "我今天很高兴，因为我学会了如何使用Python编程！"
    analysis = strategy.analyze_message(test_message)
    print(f"消息分析: {analysis}")
    
    # 测试提示词生成
    prompt = strategy.get_optimal_prompt(test_message)
    print(f"\n优化提示词:")
    print(prompt)
    
    # 测试回复处理
    raw_reply = "Python是一种非常流行的编程语言，它简单易学，功能强大，广泛应用于Web开发、数据分析、人工智能等领域。学会Python对你的编程能力提升会有很大帮助！"
    processed_reply = strategy.process_reply(test_message, raw_reply)
    print(f"\n处理后的回复:")
    print(processed_reply)
    
    print("\n测试完成！")