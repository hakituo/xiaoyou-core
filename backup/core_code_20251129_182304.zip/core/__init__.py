"""
核心模块包
此模块导出核心引擎和相关组件，提供统一的接口访问系统核心功能。
"""
# 从engine模块导入核心功能
from .engine import CoreEngine
from .event_bus import EventBus, get_event_bus, EventTypes, event_handler
# 全局引擎实例
_engine_instance = None
async def get_core_engine() -> CoreEngine:
    """
    获取全局Core Engine实例（单例模式）
    Returns:
        CoreEngine: 引擎实例
    """
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = CoreEngine()
        await _engine_instance.initialize()
    return _engine_instance
async def load_module(module_name):
    """
    便捷函数：加载指定模块（懒加载）
    Args:
        module_name: 模块名称（llm, image, voice等）
    Returns:
        any: 模块实例
    """
    engine = await get_core_engine()
    return await engine.load_module(module_name)
async def unload_module(module_name):
    """
    便捷函数：卸载指定模块
    Args:
        module_name: 模块名称
    """
    engine = await get_core_engine()
    await engine.unload_module(module_name)
async def shutdown_engine():
    """
    关闭引擎，释放所有资源
    """
    global _engine_instance
    if _engine_instance:
        await _engine_instance.shutdown()
        _engine_instance = None
from .cache import CacheStrategy, EnhancedCacheManager, get_cache_manager, cache_decorator
from core.llm import LLMConfig, BaseLLM
from core.model_registry import global_model_registry
from .memory import MemoryMonitor, MemoryManager, GarbageCollector, get_memory_manager, initialize_memory_manager
# 导出所有公共接口
__all__ = [
    # 核心引擎
    "CoreEngine",
    "get_core_engine",
    # 事件总线
    "EventBus",
    "get_event_bus",
    "EventTypes",
    "event_handler",
    # 模型相关
    "LLMConfig",
    "BaseLLM",
    "global_model_registry",
    # 缓存模块
    "CacheStrategy",
    "EnhancedCacheManager",
    "get_cache_manager",
    "cache_decorator",
    # 模型模块
    "LLMConfig",
    "LLMInterface",
    "BaseLLM",
    "register_model",
    "get_model_instance",
    "list_available_models",
    # 内存管理模块
    "MemoryMonitor",
    "MemoryManager",
    "GarbageCollector",
    "get_memory_manager",
    "initialize_memory_manager"
]