"""
模型管理器
使用单例模式集中管理所有模型的加载、卸载和检查
防止重复加载和内存溢出
增强支持量化加载选项和显存/资源检测
"""
import os
import logging
import gc
import threading
import time
import subprocess
import re
from typing import Dict, Optional, Union, List, Any, Tuple
import torch
import psutil
import numpy as np
import asyncio
from typing import Any as _Any
try:
    from watchdog.observers import Observer as _Observer
    from watchdog.events import FileSystemEventHandler as _FSEH
except Exception:
    _Observer = None
    _FSEH = object

# 获取logger
logger = logging.getLogger(__name__)


class ModelInfo:
    """
    模型信息类
    存储每个模型的元数据和状态
    """
    def __init__(self, model_name: str, model_type: str, model_path: str):
        self.model_name = model_name
        self.model_type = model_type  # 如 'llm', 'tts', 'stt', 'embedding', 'vision', 'image_gen'
        self.model_path = model_path
        self.load_time = None  # 加载时间戳
        self.last_used_time = None  # 最后使用时间戳
        self.is_loaded = False  # 模型是否已加载
        self.model_obj = None  # 模型对象
        self.tokenizer_obj = None  # 分词器对象（如果有）
        self.quantized = False  # 是否量化
        self.quantization_config = None  # 量化配置
        self.device = None  # 运行设备
        self.memory_used = None  # 内存使用估计值
        self.torch_dtype = None  # 数据类型
        self.load_options = {}  # 加载选项


class ModelManager:
    """
    模型管理器（单例模式）
    负责所有模型的生命周期管理
    """
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(ModelManager, cls).__new__(cls)
                # 初始化实例属性
                cls._instance._models: Dict[str, ModelInfo] = {}
                cls._instance._model_locks: Dict[str, threading.Lock] = {}
                cls._instance._global_lock = threading.RLock()
                cls._instance._max_models = int(os.environ.get('MAX_MODELS', 5))
                cls._instance._memory_threshold = float(os.environ.get('MODEL_MEMORY_THRESHOLD', 0.7))  # 70%
                cls._instance._pinned_models = set()
        return cls._instance
    
    def __init__(self):
        # 确保初始化代码只执行一次
        with self._global_lock:
            if not hasattr(self, '_initialized'):
                self._initialized = True
                # 初始化配置
                self._max_models = int(os.environ.get('MAX_MODELS', 5))
                self._memory_threshold = float(os.environ.get('MODEL_MEMORY_THRESHOLD', 0.7))  # 70%
                self._gpu_memory_threshold = float(os.environ.get('GPU_MEMORY_THRESHOLD', 0.8))  # 80%
                
                # 检测系统资源
                self.system_resources = self.detect_system_resources()
                
                # 根据系统资源调整默认配置
                self._adjust_defaults_based_on_resources()
                
                logger.info(f"初始化模型管理器，最大模型数: {self._max_models}, 内存阈值: {self._memory_threshold}")
                logger.info(f"系统资源: {self.system_resources}")
    
    def register_model(self, model_name: str, model_type: str, model_path: str) -> bool:
        """
        注册模型信息
        
        Args:
            model_name: 模型名称（唯一标识符）
            model_type: 模型类型 ('llm', 'tts', 'stt', 'embedding')
            model_path: 模型路径
            
        Returns:
            bool: 是否注册成功
        """
        with self._global_lock:
            if model_name in self._models:
                logger.warning(f"模型 {model_name} 已存在")
                return False
            
            # 创建模型信息
            self._models[model_name] = ModelInfo(
                model_name=model_name,
                model_type=model_type,
                model_path=model_path
            )
            
            # 创建模型专属锁
            self._model_locks[model_name] = threading.Lock()
            
            logger.info(f"注册模型: {model_name} ({model_type}) - {model_path}")
            return True

    def pin_model(self, model_name: str) -> bool:
        with self._global_lock:
            if model_name not in self._models:
                logger.error(f"未注册的模型: {model_name}")
                return False
            self._pinned_models.add(model_name)
            logger.info(f"固定模型驻留内存: {model_name}")
            return True
    
    def load_model(self, model_name: str, **kwargs) -> Optional[Any]:
        """
        加载模型，增强支持智能资源检测和自适应量化
        
        Args:
            model_name: 模型名称
            **kwargs:
                - device: 设备映射，默认为 'auto'
                - torch_dtype: 数据类型，如 torch.float16, torch.float32
                - quantization_config: 量化配置字典，包含：
                    - enabled: 是否启用
                    - load_in_8bit: 使用8位量化
                    - load_in_4bit: 使用4位量化
                    - bitsandbytes: 使用bitsandbytes库
                - model_kwargs: 传递给模型加载函数的其他参数
                - model_size: 模型大小估计 ('small', 'medium', 'large')
            
        Returns:
            Optional[Any]: 加载的模型对象，失败返回None
        """
        # 检查模型是否已注册
        if model_name not in self._models:
            logger.error(f"未注册的模型: {model_name}")
            return None
        
        model_info = self._models[model_name]
        # 确保模型锁存在
        if model_name not in self._model_locks:
            self._model_locks[model_name] = threading.Lock()
        model_lock = self._model_locks[model_name]
        
        # 检查是否已加载
        if model_info.is_loaded:
            logger.debug(f"模型 {model_name} 已加载，返回已有实例")
            model_info.last_used_time = time.time()
            return model_info.model_obj
        
        # 资源状态记录
        resources = self.detect_system_resources()
        has_gpu = resources.get('has_gpu', False)
        
        # 初始化量化配置，优先沿用注册时的选项
        quantization_config = kwargs.get('quantization_config')
        if quantization_config is None or (isinstance(quantization_config, dict) and not quantization_config):
            saved_q = model_info.load_options.get('quantization_config') if isinstance(model_info.load_options, dict) else None
            if isinstance(saved_q, dict) and saved_q:
                quantization_config = saved_q
            else:
                quantization_config = {}
        # 默认启用NF4 4bit量化以降低显存占用（除非明确禁用）
        try:
            quantization_config = quantization_config or {}
        except Exception:
            pass
        
        # 先获取模型大小估计
        model_size = kwargs.get('model_size', model_info.load_options.get('model_size', 'medium'))
        
        # 根据资源情况自动调整量化配置（这里先使用基础估计值）
        base_estimate = self.estimate_required_memory(model_info.model_type, model_size)
        self._auto_adjust_quantization(quantization_config, resources, base_estimate)
        
        # 确定量化类型用于更准确的内存估计
        quantization_type = None
        if quantization_config.get('enabled', False):
            if quantization_config.get('load_in_4bit', False):
                quantization_type = 'nf4'  # 我们使用的是NF4 4位量化
            elif quantization_config.get('load_in_8bit', False):
                quantization_type = '8bit'
        
        # 使用考虑量化因素的更准确内存估计
        estimated_memory = self.estimate_required_memory(model_info.model_type, model_size, quantization_type)
        
        # 使用增强版内存检查，传入更准确的估计需求
        memory_check = self._check_memory_available(estimated_memory)
        try:
            # 在存在GPU且已启用NF4量化时，放宽系统内存限制，优先使用GPU
            gpu_free = resources.get('gpu_memory_free_gb')
            if has_gpu and quantization_type in ('nf4', '4bit') and isinstance(gpu_free, (int, float)):
                if gpu_free >= max(1.0, estimated_memory * 0.8):
                    if not memory_check.get('available', True):
                        logger.info("在GPU可用且启用NF4量化的情况下放宽系统内存限制，继续尝试GPU加载")
                        memory_check['available'] = True
        except Exception:
            pass
        
        # 处理内存警告
        if not memory_check['available']:
            logger.warning(f"加载模型 {model_name} 前的资源警告: {', '.join(memory_check['warnings'])}，尝试释放资源...")
            
            # 1. 先尝试垃圾回收和缓存清理
            self._perform_resource_cleanup()
            
            # 2. 尝试卸载最不常用的模型
            unloaded = self._unload_oldest_model()
            if unloaded:
                logger.info(f"已卸载最不常用模型以释放资源")
                # 重新检查内存
                memory_check = self._check_memory_available(estimated_memory)
        # 合并设备与量化设置，保持与注册时一致
        if 'device' not in kwargs or kwargs.get('device') in (None, 'auto'):
            if model_info.device:
                kwargs['device'] = model_info.device
            elif 'device' in model_info.load_options:
                kwargs['device'] = model_info.load_options.get('device')
        kwargs['quantization_config'] = quantization_config
        if 'model_kwargs' not in kwargs and isinstance(model_info.load_options, dict):
            mk = model_info.load_options.get('model_kwargs')
            if isinstance(mk, dict):
                kwargs['model_kwargs'] = mk
        
        # 仍然内存不足，尝试更强的量化或CPU回退
        retry_attempts = 0
        max_retry = 3
        load_success = False
        
        while not load_success and retry_attempts < max_retry:
            # 检查当前资源状态
            memory_check = self._check_memory_available(estimated_memory)
            try:
                stats = self.get_gpu_memory_stats()
                if stats and quantization_type in ('nf4', '4bit'):
                    available_gpu_gb = stats.get('free', 0) / 1024.0
                    if available_gpu_gb >= max(1.0, estimated_memory * 0.8):
                        memory_check['available'] = True
                        logger.info("在GPU可用且启用NF4量化的情况下放宽内存检查")
            except Exception:
                pass
            
            if memory_check['available']:
                # 资源足够，尝试加载
                with model_lock:
                    # 双重检查，防止在等待锁的过程中被其他线程加载
                    if model_info.is_loaded:
                        model_info.last_used_time = time.time()
                        return model_info.model_obj
                    
                    try:
                        load_result = self._attempt_model_load(model_info, kwargs, estimated_memory)
                        if load_result:
                            model_obj, tokenizer_obj = load_result
                            # 更新模型信息
                            model_info.model_obj = model_obj
                            model_info.tokenizer_obj = tokenizer_obj
                            model_info.is_loaded = True
                            model_info.load_time = time.time()
                            model_info.last_used_time = time.time()
                            model_info.device = kwargs.get('device', 'cpu')
                            model_info.quantized = quantization_config.get('enabled', False)
                            model_info.quantization_config = quantization_config
                            model_info.load_options = kwargs.copy()
                            
                            # 估算内存使用
                            model_info.memory_used = self._estimate_model_memory(model_obj)
                            
                            logger.info(f"模型 {model_name} 加载成功，内存估计: {model_info.memory_used:.2f}MB")
                            return model_obj
                    except Exception as e:
                        logger.error(f"加载模型 {model_name} 失败 (尝试 {retry_attempts + 1}/{max_retry}): {str(e)}")
            
            # 策略调整
            retry_attempts += 1
            if retry_attempts < max_retry:
                # 1. 跳过量化调整
                
                # 2. 设备策略：仅在无GPU时回退到CPU；有GPU则保持auto
                if not torch.cuda.is_available():
                    kwargs['device'] = 'cpu'
                    logger.info(f"尝试在CPU上加载模型 {model_name}")
                else:
                    kwargs['device'] = kwargs.get('device', 'auto') or 'auto'
                    logger.info(f"保留GPU设备映射: {kwargs['device']}")
                
                # 3. 强制释放更多内存
                self._force_memory_release()
            else:
                logger.error(f"加载模型 {model_name} 失败，已达到最大重试次数")
                break
        
        # 循环结束仍未加载成功，尝试最终CPU兜底
        try:
            kwargs['device'] = 'cpu'
            mk = kwargs.get('model_kwargs', {}) or {}
            mk['low_cpu_mem_usage'] = True
            mk['device_map'] = 'cpu'
            mk['torch_dtype'] = torch.float32
            kwargs['model_kwargs'] = mk
            logger.info(f"最终兜底尝试: 在CPU上加载 {model_name}，启用 low_cpu_mem_usage")
            load_result = self._attempt_model_load(model_info, kwargs, estimated_memory)
            if load_result:
                model_obj, tokenizer_obj = load_result
                # 更新模型信息
                model_info.model_obj = model_obj
                model_info.tokenizer_obj = tokenizer_obj
                model_info.is_loaded = True
                model_info.load_time = time.time()
                model_info.last_used_time = time.time()
                model_info.device = 'cpu'
                model_info.quantized = False
                model_info.quantization_config = kwargs.get('quantization_config', {})
                model_info.load_options = kwargs.copy()
                model_info.memory_used = self._estimate_model_memory(model_obj)
                logger.info(f"CPU兜底加载成功: {model_name}，内存估计 {model_info.memory_used:.2f}MB")
                return model_obj
        except Exception as e:
            logger.error(f"CPU兜底加载失败: {str(e)}")
        return None
        
    def _auto_adjust_quantization(self, quantization_config: Dict, resources: Dict, estimated_memory: float):
        """
        根据可用资源自动调整量化配置
        
        Args:
            quantization_config: 量化配置字典
            resources: 系统资源信息
            estimated_memory: 估计所需内存(GB)
        """
        has_gpu = resources.get('has_gpu', False)
        available_gpu_memory = resources.get('gpu', {}).get('free', 0) / 1024.0  # 转换为GB
        total_gpu_memory = resources.get('gpu', {}).get('total', 0) / 1024.0  # 转换为GB
        
        logger.info(f"===== 量化配置调整分析 =====")
        logger.info(f"模型估计内存需求: {estimated_memory:.2f}GB")
        logger.info(f"GPU可用内存: {available_gpu_memory:.2f}GB / 总内存: {total_gpu_memory:.2f}GB")
        logger.info(f"当前量化配置: {quantization_config}")
        
        # 如果已明确启用量化，保留设置
        if quantization_config.get('enabled', False):
            # 确保如果使用4位量化，默认使用NF4格式
            if quantization_config.get('load_in_4bit', False):
                if 'bnb_4bit_quant_type' not in quantization_config:
                    quantization_config['bnb_4bit_quant_type'] = 'nf4'
                    quantization_config['bnb_4bit_compute_dtype'] = torch.float16
                    quantization_config['bnb_4bit_use_double_quant'] = True
                    logger.info(f"已为4位量化配置NF4格式和优化参数")
                else:
                    logger.info(f"使用已配置的4位量化设置: {quantization_config['bnb_4bit_quant_type']}")
            elif quantization_config.get('load_in_8bit', False):
                logger.info(f"使用8位量化配置")
            return
        
        # 如果没有GPU或未指定量化，根据资源情况自动决定
        if has_gpu and available_gpu_memory > 0:
            logger.info(f"内存评估完成，不自动启用量化")
        else:
            logger.info(f"无可用GPU或GPU内存，可能会使用CPU加载")
        logger.info(f"===== 量化配置调整完成 =====")
    
    def _attempt_model_load(self, model_info: ModelInfo, kwargs: Dict, estimated_memory: float) -> Optional[Tuple[Any, Any]]:
        """
        尝试加载模型，包含资源监控
        
        Args:
            model_info: 模型信息
            kwargs: 加载参数
            estimated_memory: 估计所需内存
            
        Returns:
            模型和分词器对象的元组，失败返回None
        """
        logger.info(f"开始加载模型: {model_info.model_name} (类型: {model_info.model_type})")
        start_time = time.time()
        
        try:
            # 记录加载前的内存状态
            before_memory = None
            if torch.cuda.is_available():
                before_memory = torch.cuda.memory_allocated()
            
            # 根据模型类型调用不同的加载函数
            model_obj, tokenizer_obj = self._load_model_by_type(model_info.model_name, **kwargs)
            
            # 记录加载后的内存状态和耗时
            load_time = time.time() - start_time
            memory_increase = None
            
            if torch.cuda.is_available() and before_memory is not None:
                after_memory = torch.cuda.memory_allocated()
                memory_increase = (after_memory - before_memory) / (1024 * 1024)  # MB
                
            logger.info(
                f"模型 {model_info.model_name} 加载完成，耗时: {load_time:.2f}s"
                + (f", 内存增长: {memory_increase:.2f}MB" if memory_increase is not None else "")
                + (f", 量化: {kwargs.get('quantization_config', {}).get('enabled', False)}" if 'quantization_config' in kwargs else "")
                + (f", 设备: {kwargs.get('device', 'auto')}" if 'device' in kwargs else "")
            )
            
            return model_obj, tokenizer_obj
            
        except RuntimeError as e:
            # 处理可能的OOM错误
            error_msg = str(e)
            if 'out of memory' in error_msg.lower() or 'cuda out of memory' in error_msg.lower():
                logger.error(f"模型加载OOM错误: {error_msg}")
                # 尝试释放内存
                torch.cuda.empty_cache()
                gc.collect()
                raise MemoryError(f"GPU内存不足，无法加载模型 {model_info.model_name}。建议使用更高级别的量化或在CPU上加载。")
            else:
                raise
        except Exception as e:
            logger.error(f"加载模型时发生其他错误: {str(e)}")
            raise
    
    def _perform_resource_cleanup(self):
        """
        增强的资源清理方法
        更彻底地释放内存和GPU缓存
        """
        logger.info("执行资源清理")
        
        # 分步骤执行更彻底的资源清理
        
        # 1. 先进行简单的垃圾回收
        gc.collect()
        
        # 2. 释放PyTorch缓存（包括更高级的清理）
        if torch.cuda.is_available():
            try:
                # 释放CUDA缓存
                torch.cuda.empty_cache()
                # 清除CUDA分配器缓存
                torch.cuda.ipc_collect()
                # 清除备用缓存
                if hasattr(torch.cuda, 'memory_reserved'):
                    torch.cuda.memory_reserved()  # 触发缓存检查
                logger.info("已清理PyTorch缓存和CUDA资源")
            except Exception as e:
                logger.warning(f"清理PyTorch缓存失败: {str(e)}")
        
        # 3. 再次执行垃圾回收，确保释放已不再引用的大对象
        gc.collect()
        
        # 4. 显示内存状态，便于调试
        if torch.cuda.is_available():
            try:
                mem_stats = torch.cuda.memory_summary()
                logger.debug(f"CUDA内存状态: {mem_stats}")
            except:
                pass
    
    def _force_memory_release(self):
        """
        强制释放更多内存，用于重试加载
        """
        logger.info("强制释放更多内存")
        
        # 使用全局锁保护资源释放操作
        with self._global_lock:
            # 先执行常规清理
            self._perform_resource_cleanup()
            
            # 卸载一半已加载的模型
            loaded_models = self.get_loaded_models()
            if len(loaded_models) > 1:
                # 按最后使用时间排序
                models_to_unload = sorted(
                    [(name, self._models[name].last_used_time) for name in loaded_models],
                    key=lambda x: x[1] if x[1] else 0
                )
                # 卸载最早使用的一半模型
                count_to_unload = max(1, len(models_to_unload) // 2)
                for i in range(count_to_unload):
                    model_name = models_to_unload[i][0]
                    logger.info(f"强制卸载模型以释放内存: {model_name}")
                    self.unload_model(model_name)
                
                # 再次清理
                self._perform_resource_cleanup()
            else:
                logger.warning("没有足够的已加载模型可卸载")
            
            # 检查模型数量限制
            if len([m for m in self._models.values() if m.is_loaded]) >= self._max_models:
                self._unload_oldest_model()
                
            # 尝试释放缓存
            if torch.cuda.is_available():
                try:
                    torch.cuda.empty_cache()
                except Exception as e:
                    logger.warning(f"释放CUDA缓存失败: {str(e)}")
    
    def get_system_resources(self) -> Dict[str, Any]:
        """
        获取系统资源信息
        
        Returns:
            系统资源信息字典
        """
        return self.detect_system_resources()
    
    def health_check(self) -> Dict[str, Any]:
        """
        健康检查，返回模型管理器和模型的状态
        
        Returns:
            包含健康状态信息的字典
        """
        # 获取系统资源
        resources = self.get_system_resources()
        
        # 检查每个模型的状态
        models_status = {}
        for model_name, model_info in self._models.items():
            models_status[model_name] = {
                'type': model_info.model_type,
                'loaded': model_info.is_loaded,
                'last_used': model_info.last_used_time,
                'path': model_info.model_path,
                'torch_dtype': str(model_info.torch_dtype) if model_info.torch_dtype else None,
                'quantization': model_info.load_options.get('quantization_config', {}) if model_info.load_options else {}
            }
        
        # 构建健康报告
        health_report = {
            'status': 'healthy',
            'timestamp': time.time(),
            'system_resources': resources,
            'models_count': len(self._models),
            'loaded_models_count': sum(1 for m in self._models.values() if m.is_loaded),
            'models': models_status
        }
        
        # 检查是否有内存警告
        memory = psutil.virtual_memory()
        if memory.percent > self._memory_threshold * 100:
            health_report['status'] = 'warning'
            health_report['warnings'] = health_report.get('warnings', []) + [
                f"系统内存使用率过高: {memory.percent:.1f}%"
            ]
        
        # 检查GPU内存
        if torch.cuda.is_available():
            gpu_stats = self.get_gpu_memory_stats()
            if gpu_stats and gpu_stats['used_percent'] > self._gpu_memory_threshold:
                health_report['status'] = 'warning'
                health_report['warnings'] = health_report.get('warnings', []) + [
                    f"GPU内存使用率过高: {gpu_stats['used_percent'] * 100:.1f}%"
                ]
        
        return health_report
    
    def unload_model(self, model_name: str) -> bool:
        """
        卸载指定模型
        
        Args:
            model_name: 模型名称
            
        Returns:
            bool: 是否卸载成功
        """
        if model_name not in self._models:
            logger.error(f"未注册的模型: {model_name}")
            return False
        
        model_info = self._models[model_name]
        model_lock = self._model_locks[model_name]
        
        with model_lock:
            if not model_info.is_loaded:
                logger.debug(f"模型 {model_name} 未加载，无需卸载")
                return True
            
            try:
                logger.info(f"开始卸载模型: {model_name}")
                self._clean_model_resources(model_info)
                logger.info(f"模型 {model_name} 卸载完成")
                return True
            except Exception as e:
                logger.error(f"卸载模型 {model_name} 失败: {str(e)}")
                return False
    
    def get_model(self, model_name: str) -> Optional[Any]:
        """
        获取模型对象（不自动加载）
        
        Args:
            model_name: 模型名称
            
        Returns:
            Optional[Any]: 模型对象，未加载返回None
        """
        if model_name not in self._models:
            logger.error(f"未注册的模型: {model_name}")
            return None
        
        model_info = self._models[model_name]
        if model_info.is_loaded:
            model_info.last_used_time = time.time()
            return model_info.model_obj
        
        return None
    
    def get_tokenizer(self, model_name: str) -> Optional[Any]:
        """
        获取分词器对象（如果有）
        
        Args:
            model_name: 模型名称
            
        Returns:
            Optional[Any]: 分词器对象，未加载返回None
        """
        if model_name not in self._models:
            logger.error(f"未注册的模型: {model_name}")
            return None
        
        model_info = self._models[model_name]
        if model_info.is_loaded:
            return model_info.tokenizer_obj
        
        return None
    
    def is_model_loaded(self, model_name: str) -> bool:
        """
        检查模型是否已加载
        
        Args:
            model_name: 模型名称
            
        Returns:
            bool: 是否已加载
        """
        if model_name not in self._models:
            return False
        return self._models[model_name].is_loaded
    
    def get_loaded_models(self) -> List[str]:
        """
        获取所有已加载的模型名称
        
        Returns:
            List[str]: 已加载的模型名称列表
        """
        return [name for name, info in self._models.items() if info.is_loaded]
    
    def get_model_info(self, model_name: str) -> Optional[ModelInfo]:
        """
        获取模型详细信息
        
        Args:
            model_name: 模型名称
            
        Returns:
            Optional[ModelInfo]: 模型信息对象
        """
        return self._models.get(model_name)
    
    def clear_all_models(self) -> bool:
        """
        清空所有已加载的模型
        
        Returns:
            bool: 是否成功
        """
        try:
            loaded_models = [m for m in self.get_loaded_models() if m not in getattr(self, '_pinned_models', set())]
            for model_name in loaded_models:
                self.unload_model(model_name)
            logger.info(f"已清空所有模型，共 {len(loaded_models)} 个")
            return True
        except Exception as e:
            logger.error(f"清空模型失败: {str(e)}")
            return False
    
    def _load_model_by_type(self, model_name: str, **kwargs):
        """
        根据模型类型加载模型
        增强支持量化加载选项
        """
        model_info = self._models[model_name]
        model_type = model_info.model_type
        model_path = model_info.model_path
        
        # 保存加载选项
        model_info.load_options = kwargs.copy()
        model_info.torch_dtype = kwargs.get('torch_dtype', torch.float16 if torch.cuda.is_available() else torch.float32)
        
        # 根据量化配置调整加载参数
        quantization_config = kwargs.get('quantization_config', {})
        model_kwargs = kwargs.get('model_kwargs', {})
        
        # 处理量化参数
        self._process_quantization_options(model_kwargs, quantization_config)
        
        # 根据模型类型加载
        if model_type == 'llm':
            return self._load_llm_model(model_path, kwargs)
        elif model_type == 'embedding':
            return self._load_embedding_model(model_path, kwargs)
        elif model_type == 'tts':
            return self._load_tts_model(model_path, kwargs)
        elif model_type == 'stt':
            return self._load_stt_model(model_path, kwargs)
        elif model_type == 'vision':
            return self._load_vision_model(model_path, kwargs)
        elif model_type == 'image_gen':
            return self._load_image_gen_model(model_path, kwargs)
        else:
            raise ValueError(f"不支持的模型类型: {model_type}")
    
    def _process_quantization_options(self, model_kwargs: Dict, quantization_config: Dict):
        """
        处理量化选项，增强对不同量化方法的支持
        确保不会同时传递load_in_4bit和quantization_config参数
        """
        # 检查是否启用量化
        if quantization_config.get('enabled', False):
            # 检查可用的量化方法
            try:
                # 对于4位量化，直接使用quantization_config而不是load_in_4bit参数
                if quantization_config.get('load_in_4bit', False):
                    # 不设置load_in_4bit=True，避免与quantization_config冲突
                    # 而是在后续的_load_llm_model方法中创建BitsAndBytesConfig对象
                    logger.info("启用4位量化 (通过quantization_config)")
                # 尝试8位量化
                elif quantization_config.get('load_in_8bit', False):
                    # 不设置load_in_8bit=True，避免与quantization_config冲突
                    # 而是在后续的_load_llm_model方法中创建BitsAndBytesConfig对象
                    logger.info("启用8位量化 (通过quantization_config)")
            except Exception as e:
                logger.warning(f"设置量化选项时出错: {str(e)}")
        
        # 添加bitsandbytes相关配置
        if quantization_config.get('bitsandbytes', False):
            try:
                # 检查bitsandbytes是否可用
                import bitsandbytes
                # 不直接设置load_in_8bit，避免冲突
                logger.info("使用bitsandbytes进行量化 (通过quantization_config)")
            except ImportError:
                logger.warning("bitsandbytes不可用，尝试其他量化方法")
    
    def _load_llm_model(self, model_path: str, kwargs: Dict) -> Tuple[Any, Any]:
        """
        加载大语言模型，增强支持多种量化选项和优化内存管理
        """
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            from config.integrated_config import get_settings
            
            # 获取应用配置，支持本地模型加载模式
            app_settings = get_settings()
            load_mode = app_settings.model.load_mode if hasattr(app_settings, 'model') and hasattr(app_settings.model, 'load_mode') else 'local'
            local_model_prefix = app_settings.model.local_model_prefix if hasattr(app_settings, 'model') and hasattr(app_settings.model, 'local_model_prefix') else './models/'
            
            # 如果是本地模式，构建本地模型路径
            final_model_path = model_path
            if load_mode == 'local':
                # 如果已经是绝对路径或者完整路径，直接使用
                if not os.path.isabs(model_path) and not os.path.exists(model_path):
                    # 构建本地路径
                    final_model_path = os.path.join(local_model_prefix, model_path)
                    logger.info(f"🔄 使用本地模型路径: {final_model_path}")
            
            # 验证模型路径是否存在
            if load_mode == 'local' and not os.path.exists(final_model_path):
                logger.warning(f"⚠️ 本地模型路径不存在: {final_model_path}")
            
            tokenizer = AutoTokenizer.from_pretrained(final_model_path, trust_remote_code=True, local_files_only=(load_mode == 'local'))
            
            # 准备模型加载参数
            model_kwargs = kwargs.get('model_kwargs', {})
            device = kwargs.get('device', 'auto')
            
            # 添加本地模式标志
            model_kwargs['local_files_only'] = (load_mode == 'local')
            
            # 添加智能设备映射策略
            if device == 'auto' and torch.cuda.is_available():
                # 对于大模型，优先使用offload_folder策略
                model_kwargs['device_map'] = 'auto'
                # 添加模型分片和梯度检查点以节省内存
                model_kwargs['low_cpu_mem_usage'] = True
                model_kwargs['torch_dtype'] = torch.float16  # 优先使用FP16
            else:
                model_kwargs['device_map'] = device
                model_kwargs['torch_dtype'] = kwargs.get('torch_dtype', torch.float32 if device == 'cpu' else torch.float16)
            
            # 记录加载前的内存状态
            if torch.cuda.is_available():
                before_mem = torch.cuda.memory_allocated() / (1024 * 1024)
                before_cache = torch.cuda.memory_reserved() / (1024 * 1024)
                logger.info(f"加载前GPU内存状态 - 已分配: {before_mem:.2f}MB, 已缓存: {before_cache:.2f}MB")
            
            # 尝试优先加载AWQ量化权重
            try:
                cand_awq = [final_model_path, os.path.join(final_model_path, "awq")]
                found_awq = False
                for p in cand_awq:
                    if os.path.isdir(p) and (os.path.isfile(os.path.join(p, "awq_config.json")) or os.path.isdir(os.path.join(p, "awq_cache"))):
                        found_awq = True
                        final_awq_path = p if p != final_model_path else final_model_path
                        break
                if found_awq:
                    from awq import AutoAWQForCausalLM
                    model = AutoAWQForCausalLM.from_pretrained(final_awq_path, trust_remote_code=True, device_map='auto')
                    return model, tokenizer
            except Exception:
                pass
            # 获取quantization_config
            quantization_config = kwargs.get('quantization_config', {})
            
            # 处理4位量化
            if quantization_config.get('enabled', False) and quantization_config.get('load_in_4bit', False):
                # 增强4位量化配置 - 强制使用NF4格式
                try:
                    from transformers import BitsAndBytesConfig
                    # 确保量化类型为NF4
                    quant_type = quantization_config.get('bnb_4bit_quant_type', 'nf4')
                    compute_dtype = quantization_config.get('bnb_4bit_compute_dtype', torch.float16)
                    use_double_quant = quantization_config.get('bnb_4bit_use_double_quant', True)
                    
                    # 创建量化配置
                    bnb_config = BitsAndBytesConfig(
                        bnb_4bit_compute_dtype=compute_dtype,
                        bnb_4bit_use_double_quant=use_double_quant,
                        bnb_4bit_quant_type=quant_type
                    )
                    
                    # 只设置quantization_config，不设置load_in_4bit
                    model_kwargs['quantization_config'] = bnb_config
                    
                    # 确保model_kwargs中没有load_in_4bit参数
                    if 'load_in_4bit' in model_kwargs:
                        model_kwargs.pop('load_in_4bit')
                    
                    logger.info("🔍 使用NF4格式4位量化配置 - 优化内存使用和性能")
                    logger.info("📊 NF4量化配置详情:")
                    logger.info(f"  - 量化类型: {quant_type} (4-bit NormalFloat)")
                    logger.info(f"  - 计算精度: {compute_dtype}")
                    logger.info(f"  - 双重量化: {'已启用' if use_double_quant else '未启用'}")
                except ImportError:
                    logger.warning("⚠️ BitsAndBytes不可用，使用基础4位量化")
            # 处理8位量化
            elif quantization_config.get('enabled', False) and quantization_config.get('load_in_8bit', False):
                # 8位量化增强
                try:
                    from transformers import BitsAndBytesConfig
                    # 创建8位量化配置
                    bnb_config = BitsAndBytesConfig()
                    model_kwargs['quantization_config'] = bnb_config
                    
                    # 确保model_kwargs中没有load_in_8bit参数
                    if 'load_in_8bit' in model_kwargs:
                        model_kwargs.pop('load_in_8bit')
                    
                    logger.info("🔍 使用增强版8位量化配置")
                except ImportError:
                    logger.warning("⚠️ BitsAndBytes不可用，使用基础8位量化")
            
            # 添加模型并行和优化参数
            model_kwargs['trust_remote_code'] = True  # 支持Qwen等模型的自定义代码
            
            # 打印最终加载参数摘要
            logger.info("📋 最终模型加载参数:")
            logger.info(f"  - 加载模式: {load_mode}")
            logger.info(f"  - 模型路径: {final_model_path}")
            logger.info(f"  - 设备映射: {model_kwargs.get('device_map', 'auto')}")
            logger.info(f"  - 数据类型: {model_kwargs.get('torch_dtype', 'default')}")
            logger.info(f"  - 量化配置: {'NF4 4-bit' if 'quantization_config' in model_kwargs and hasattr(model_kwargs['quantization_config'], 'bnb_4bit_quant_type') and model_kwargs['quantization_config'].bnb_4bit_quant_type == 'nf4' else '8-bit' if 'quantization_config' in model_kwargs and hasattr(model_kwargs['quantization_config'], 'load_in_8bit') and model_kwargs['quantization_config'].load_in_8bit else 'None'}")
            
            # 尝试加载模型
            logger.info("🚀 开始加载模型...")
            start_load_time = time.time()
            model = AutoModelForCausalLM.from_pretrained(
                final_model_path,
                **model_kwargs
            )
            load_time = time.time() - start_load_time
            
            # 记录加载后的内存状态
            if torch.cuda.is_available():
                after_mem = torch.cuda.memory_allocated() / (1024 * 1024)
                after_cache = torch.cuda.memory_reserved() / (1024 * 1024)
                mem_increase = after_mem - before_mem
                logger.info(f"✅ 加载后GPU内存状态 - 已分配: {after_mem:.2f}MB (+{mem_increase:.2f}MB), 已缓存: {after_cache:.2f}MB")
                logger.info(f"📊 估计模型占用: {after_cache:.2f}MB ({after_cache/1024:.2f}GB)")
            
            logger.info(f"✅ LLM模型加载成功: {model_path}")
            logger.info(f"⏱️ 加载耗时: {load_time:.2f}秒")
            return model, tokenizer
            
        except Exception as e:
            logger.error(f"加载LLM模型失败: {str(e)}")
            # 如果失败，尝试备选方案
            return self._load_llm_fallback(model_path, kwargs)
    
    def _load_llm_fallback(self, model_path: str, kwargs: Dict) -> Tuple[Any, Any]:
        """
        LLM加载失败时的增强备选方案
        提供多层次的回退策略
        """
        logger.info("尝试备选加载方案")
        
        # 多级回退策略
        fallback_strategies = [
            # 策略1: 尝试使用NF4 4位量化 + 优化配置
            {'name': 'NF4 4-bit量化优化', 'params': {'load_in_4bit': True, 'optimize_memory': True}},
            # 策略2: 尝试使用CPU + NF4量化
            {'name': 'CPU+NF4量化', 'params': {'device_map': 'cpu', 'torch_dtype': torch.float16, 'load_in_4bit': True}},
            # 策略3: 尝试CPU + 无量化但优化内存
            {'name': 'CPU优化内存', 'params': {'device_map': 'cpu', 'torch_dtype': torch.float32, 'low_cpu_mem_usage': True}},
        ]
        
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            from config.integrated_config import get_settings
            
            # 获取应用配置，支持本地模型加载模式
            app_settings = get_settings()
            load_mode = app_settings.model.load_mode if hasattr(app_settings, 'model') and hasattr(app_settings.model, 'load_mode') else 'local'
            local_model_prefix = app_settings.model.local_model_prefix if hasattr(app_settings, 'model') and hasattr(app_settings.model, 'local_model_prefix') else './models/'
            
            # 如果是本地模式，构建本地模型路径
            final_model_path = model_path
            if load_mode == 'local':
                # 如果已经是绝对路径或者完整路径，直接使用
                if not os.path.isabs(model_path) and not os.path.exists(model_path):
                    # 构建本地路径
                    final_model_path = os.path.join(local_model_prefix, model_path)
                    logger.info(f"🔄 备选方案 - 使用本地模型路径: {final_model_path}")
            
            # 验证模型路径是否存在
            if load_mode == 'local' and not os.path.exists(final_model_path):
                logger.warning(f"⚠️ 备选方案 - 本地模型路径不存在: {final_model_path}")
            
            tokenizer = AutoTokenizer.from_pretrained(final_model_path, trust_remote_code=True, local_files_only=(load_mode == 'local'))
            
            for strategy in fallback_strategies:
                try:
                    model_kwargs = kwargs.get('model_kwargs', {}).copy()
                    model_kwargs['trust_remote_code'] = True
                    
                    # 应用当前策略
                    logger.warning(f"尝试备选策略: {strategy['name']}")
                    
                    if strategy['params'].get('optimize_memory', False):
                        model_kwargs['low_cpu_mem_usage'] = True
                        model_kwargs['device_map'] = 'auto'
                        model_kwargs['torch_dtype'] = torch.float16
                    
                    # 添加策略特定参数
                    for key, value in strategy['params'].items():
                        if key not in ['optimize_memory', 'name']:
                            model_kwargs[key] = value
                    
                    # 处理量化配置
                    if model_kwargs.pop('load_in_4bit', False):
                        try:
                            from transformers import BitsAndBytesConfig
                            bnb_config = BitsAndBytesConfig(
                                # 移除load_in_4bit=True以避免与quantization_config参数冲突
                                bnb_4bit_compute_dtype=torch.float16,
                                bnb_4bit_use_double_quant=True,
                                bnb_4bit_quant_type='nf4'
                            )
                            model_kwargs['quantization_config'] = bnb_config
                            logger.info("使用增强版4位量化作为备选策略")
                        except ImportError:
                            logger.warning("BitsAndBytes不可用，跳过量化配置")
                    
                    # 添加本地模式标志
                    model_kwargs['local_files_only'] = (load_mode == 'local')
                    
                    # 尝试加载模型
                    model = AutoModelForCausalLM.from_pretrained(
                        final_model_path,
                        **model_kwargs
                    )
                    
                    logger.info(f"备选策略成功: {strategy['name']}")
                    return model, tokenizer
                    
                except Exception as e:
                    logger.warning(f"备选策略 {strategy['name']} 失败: {str(e)}")
                    # 释放内存后继续尝试下一个策略
                    torch.cuda.empty_cache() if torch.cuda.is_available() else None
                    gc.collect()
            
            # 所有策略都失败
            raise Exception("所有备选加载策略均失败")
            
        except Exception as e:
            logger.error(f"备选方案全部失败: {str(e)}")
            raise
    
    def _load_embedding_model(self, model_path: str, kwargs: Dict) -> Tuple[Any, Any]:
        """
        加载嵌入模型
        """
        try:
            from transformers import AutoModel, AutoTokenizer
            
            tokenizer = AutoTokenizer.from_pretrained(model_path)
            model = AutoModel.from_pretrained(
                model_path,
                device_map=kwargs.get('device', 'auto'),
                torch_dtype=kwargs.get('torch_dtype', torch.float16 if torch.cuda.is_available() else torch.float32),
                **(kwargs.get('model_kwargs', {}))
            )
            
            return model, tokenizer
        except Exception as e:
            logger.error(f"加载嵌入模型失败: {str(e)}")
            raise
    
    def _load_tts_model(self, model_path: str, kwargs: Dict) -> Tuple[Any, Any]:
        """
        加载TTS模型
        """
        # 示例实现，实际使用时需要根据TTS库进行修改
        model = None
        tokenizer = None
        return model, tokenizer
    
    def _load_stt_model(self, model_path: str, kwargs: Dict) -> Tuple[Any, Any]:
        """
        加载STT模型
        """
        # 示例实现，实际使用时需要根据STT库进行修改
        model = None
        tokenizer = None
        return model, tokenizer
    
    def _load_vision_model(self, model_path: str, kwargs: Dict) -> Tuple[Any, Any]:
        """
        加载视觉模型
        """
        try:
            from transformers import AutoModelForImageClassification, AutoImageProcessor
            
            # 加载图像处理器和模型
            processor = AutoImageProcessor.from_pretrained(model_path)
            model = AutoModelForImageClassification.from_pretrained(
                model_path,
                device_map=kwargs.get('device', 'auto'),
                torch_dtype=kwargs.get('torch_dtype', torch.float16 if torch.cuda.is_available() else torch.float32),
                **(kwargs.get('model_kwargs', {}))
            )
            
            return model, processor
        except Exception as e:
            logger.error(f"加载视觉模型失败: {str(e)}")
            raise
    
    def _load_image_gen_model(self, model_path: str, kwargs: Dict) -> Tuple[Any, Any]:
        """
        加载图像生成模型（如StableDiffusion）
        """
        try:
            from diffusers import StableDiffusionPipeline
            
            # 准备加载参数
            pipeline_kwargs = kwargs.get('model_kwargs', {})
            pipeline_kwargs['torch_dtype'] = kwargs.get('torch_dtype', torch.float16 if torch.cuda.is_available() else torch.float32)
            
            # 加载管道
            pipe = StableDiffusionPipeline.from_pretrained(
                model_path,
                **pipeline_kwargs
            )
            
            # 移动到指定设备
            device = kwargs.get('device', 'cuda' if torch.cuda.is_available() else 'cpu')
            if device != 'auto':
                pipe = pipe.to(device)
            
            return pipe, None
        except Exception as e:
            logger.error(f"加载图像生成模型失败: {str(e)}")
            raise
    
    def _clean_model_resources(self, model_info: ModelInfo):
        """
        清理模型资源
        """
        # 清理模型对象
        if model_info.model_obj is not None:
            # 如果是PyTorch模型，转移到CPU并释放
            if hasattr(model_info.model_obj, 'to'):
                try:
                    model_info.model_obj.to('cpu')
                except:
                    pass
            
            # 清空引用
            model_info.model_obj = None
        
        # 清理分词器对象
        if model_info.tokenizer_obj is not None:
            model_info.tokenizer_obj = None
        
        # 更新状态
        model_info.is_loaded = False
        model_info.load_time = None
        model_info.memory_used = None
        
        # 触发垃圾回收
        gc.collect()
        
        # 如果使用PyTorch，释放GPU缓存
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    def _check_memory_available(self, estimated_required_gb: float = 0.0) -> Dict[str, Any]:
        """
        增强版内存可用性检查
        提供详细的内存状态评估，支持基于估计需求的内存预检查
        
        Args:
            estimated_required_gb: 估计需要的内存(GB)
            
        Returns:
            Dict: 包含可用性状态和详细信息的字典
        """
        result = {
            'available': True,
            'warnings': [],
            'details': {}
        }
        
        # 获取系统内存使用情况
        memory = psutil.virtual_memory()
        memory_usage_percent = memory.percent / 100.0
        memory_available_gb = memory.available / (1024**3)
        
        result['details']['system_memory'] = {
            'total_gb': round(memory.total / (1024**3), 2),
            'available_gb': round(memory_available_gb, 2),
            'used_percent': memory_usage_percent
        }
        
        # 系统内存检查
        if memory_usage_percent > self._memory_threshold:
            result['available'] = False
            result['warnings'].append(f"系统内存使用率过高: {memory_usage_percent:.2%}")
        elif estimated_required_gb > 0 and memory_available_gb < estimated_required_gb * 0.8:
            # 预估所需内存的80%应该可用
            result['available'] = False
            result['warnings'].append(f"系统内存可能不足: 需要约 {estimated_required_gb:.1f}GB，可用 {memory_available_gb:.1f}GB")
        
        # 检查GPU内存（如果可用）
        if torch.cuda.is_available():
            try:
                # 使用增强版GPU内存检测
                gpu_memory_stats = self.get_gpu_memory_stats()
                
                if gpu_memory_stats:
                    result['details']['gpu_memory'] = gpu_memory_stats
                    
                    # 检查总体GPU内存
                    if gpu_memory_stats['used_percent'] > self._gpu_memory_threshold:
                        result['available'] = False
                        result['warnings'].append(f"GPU内存使用率过高: {gpu_memory_stats['used_percent']:.2%}")
                    
                    # 检查是否有足够的可用GPU内存
                    available_gpu_gb = gpu_memory_stats['free'] / 1024.0
                    if estimated_required_gb > 0 and available_gpu_gb < estimated_required_gb * 0.9:
                        result['available'] = False
                        result['warnings'].append(f"GPU内存可能不足: 需要约 {estimated_required_gb:.1f}GB，可用 {available_gpu_gb:.1f}GB")
                    else:
                        # 当GPU可用且有足够可用显存时，覆盖CPU内存警告
                        if available_gpu_gb >= max(1.0, estimated_required_gb * 0.8):
                            result['available'] = True
                            logger.info("GPU显存充足，忽略系统内存警告，允许继续加载")
                    
                    # 检查每个GPU的状态
                    for gpu in gpu_memory_stats.get('gpus', []):
                        # 温度警告
                        if gpu.get('temperature_celsius', 0) > 85:
                            result['warnings'].append(f"GPU {gpu['index']} ({gpu['name']}) 温度过高: {gpu['temperature_celsius']}°C")
                        # 功耗警告
                        if gpu.get('power_draw_watts') and gpu.get('power_limit_watts'):
                            power_percent = gpu['power_draw_watts'] / gpu['power_limit_watts']
                            if power_percent > 0.95:
                                result['warnings'].append(f"GPU {gpu['index']} 接近功耗限制: {power_percent:.1%}")
                else:
                    # 基本检查
                    gpu_memory = torch.cuda.get_device_properties(0).total_memory
                    gpu_memory_used = torch.cuda.memory_allocated(0)
                    gpu_memory_reserved = torch.cuda.memory_reserved(0)
                    gpu_memory_usage = max(gpu_memory_used, gpu_memory_reserved) / gpu_memory
                    
                    result['details']['gpu_memory'] = {
                        'usage_percent': gpu_memory_usage,
                        'method': 'basic'
                    }
                    
                    if gpu_memory_usage > self._gpu_memory_threshold:
                        result['available'] = False
                        result['warnings'].append(f"GPU内存不足: {gpu_memory_usage:.2%}")
            except Exception as e:
                logger.warning(f"检查GPU内存时出错: {str(e)}")
                result['warnings'].append(f"无法检查GPU状态: {str(e)}")
        
        # 检查已加载模型数量
        loaded_count = len(self.get_loaded_models())
        result['details']['loaded_models_count'] = loaded_count
        
        if loaded_count >= self._max_models * 0.9:
            result['warnings'].append(f"已接近最大模型数限制: 当前 {loaded_count} 个，最大 {self._max_models} 个")
        
        # 记录详细警告
        for warning in result['warnings']:
            logger.warning(f"资源检查警告: {warning}")
        
        return result
    
    def get_gpu_memory_stats(self) -> Optional[Dict[str, Any]]:
        """
        获取GPU内存详细统计信息
        优先使用nvidia-smi获取更准确的信息，提供更全面的GPU状态监控
        
        Returns:
            包含GPU内存和利用率信息的详细字典
        """
        gpu_stats = {}
        
        # 首先尝试使用nvidia-smi获取更全面的信息
        try:
            if os.name == 'nt':  # Windows
                command = ['nvidia-smi', '--query-gpu=index,name,memory.total,memory.used,memory.free,utilization.gpu,utilization.memory,temperature.gpu,power.draw,power.limit', '--format=csv,noheader,nounits']
            else:  # Linux/Mac
                command = ['nvidia-smi', '--query-gpu=index,name,memory.total,memory.used,memory.free,utilization.gpu,utilization.memory,temperature.gpu,power.draw,power.limit', '--format=csv,noheader,nounits']
            
            result = subprocess.run(command, capture_output=True, text=True, check=True, timeout=5)
            output_lines = result.stdout.strip().split('\n')
            
            if output_lines:
                # 处理每个GPU的信息
                gpus = []
                for line in output_lines:
                    parts = line.split(',')
                    if len(parts) >= 10:
                        gpu_info = {
                            'index': int(parts[0]),
                            'name': parts[1].strip(),
                            'total_memory_mb': int(parts[2]),
                            'used_memory_mb': int(parts[3]),
                            'free_memory_mb': int(parts[4]),
                            'gpu_utilization_percent': int(parts[5]),
                            'memory_utilization_percent': int(parts[6]),
                            'temperature_celsius': int(parts[7]),
                            'power_draw_watts': float(parts[8]) if parts[8].strip() != 'N/A' else None,
                            'power_limit_watts': float(parts[9]) if parts[9].strip() != 'N/A' else None
                        }
                        gpu_info['used_percent'] = gpu_info['used_memory_mb'] / gpu_info['total_memory_mb'] if gpu_info['total_memory_mb'] > 0 else 0
                        gpus.append(gpu_info)
                
                # 整合所有GPU信息
                if gpus:
                    # 计算总览信息（所有GPU）
                    total_mem = sum(g['total_memory_mb'] for g in gpus)
                    used_mem = sum(g['used_memory_mb'] for g in gpus)
                    free_mem = sum(g['free_memory_mb'] for g in gpus)
                    
                    gpu_stats = {
                        'gpus': gpus,
                        'total': total_mem,
                        'used': used_mem,
                        'free': free_mem,
                        'used_percent': used_mem / total_mem if total_mem > 0 else 0,
                        'method': 'nvidia-smi'
                    }
                    return gpu_stats
        except (subprocess.SubprocessError, ValueError, IndexError, subprocess.TimeoutExpired) as e:
            logger.debug(f"使用nvidia-smi获取GPU信息失败: {str(e)}")
        
        # 如果nvidia-smi失败，回退到PyTorch API
        try:
            if torch.cuda.is_available():
                device_count = torch.cuda.device_count()
                gpus = []
                
                for i in range(device_count):
                    properties = torch.cuda.get_device_properties(i)
                    allocated = torch.cuda.memory_allocated(i)
                    reserved = torch.cuda.memory_reserved(i)
                    
                    # 估算可用内存（总内存减去已分配和缓存）
                    total_bytes = properties.total_memory
                    free_bytes_estimate = total_bytes - max(allocated, reserved)
                    
                    gpu_info = {
                        'index': i,
                        'name': properties.name,
                        'total_memory_mb': total_bytes // (1024 * 1024),
                        'used_memory_mb': max(allocated, reserved) // (1024 * 1024),
                        'free_memory_mb': free_bytes_estimate // (1024 * 1024),
                        'used_percent': max(allocated, reserved) / total_bytes if total_bytes > 0 else 0,
                        'details': {
                            'allocated_bytes': allocated,
                            'reserved_bytes': reserved,
                            'total_bytes': total_bytes
                        }
                    }
                    gpus.append(gpu_info)
                
                if gpus:
                    # 计算总览信息
                    total_mem = sum(g['total_memory_mb'] for g in gpus)
                    used_mem = sum(g['used_memory_mb'] for g in gpus)
                    free_mem = sum(g['free_memory_mb'] for g in gpus)
                    
                    gpu_stats = {
                        'gpus': gpus,
                        'total': total_mem,
                        'used': used_mem,
                        'free': free_mem,
                        'used_percent': used_mem / total_mem if total_mem > 0 else 0,
                        'method': 'torch.cuda'
                    }
                    return gpu_stats
        except Exception as e:
            logger.debug(f"使用PyTorch获取GPU信息失败: {str(e)}")
        
        return None
    
    def detect_system_resources(self) -> Dict[str, Any]:
        """
        增强版系统资源检测
        提供更详细的CPU、内存和GPU资源信息，支持更精确的监控
        
        Returns:
            包含详细系统资源信息的字典
        """
        resources = {
            'timestamp': time.time(),
            'monitoring_level': 'detailed'
        }
        
        # CPU信息
        try:
            resources['cpu_count'] = psutil.cpu_count(logical=True)
            resources['cpu_physical_count'] = psutil.cpu_count(logical=False)
            resources['cpu_percent'] = psutil.cpu_percent(interval=0.1)
            
            # 获取CPU频率信息（如果可用）
            cpu_freq = psutil.cpu_freq()
            if cpu_freq:
                resources['cpu_frequency'] = {
                    'current_mhz': cpu_freq.current,
                    'min_mhz': cpu_freq.min,
                    'max_mhz': cpu_freq.max
                }
            
            # 获取CPU使用率（每个核心）
            resources['cpu_cores_usage'] = psutil.cpu_percent(interval=0.1, percpu=True)
        except Exception as e:
            logger.warning(f"获取CPU信息失败: {str(e)}")
        
        # 内存信息
        try:
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            resources['system_memory'] = {
                'total_gb': round(memory.total / (1024**3), 2),
                'available_gb': round(memory.available / (1024**3), 2),
                'used_gb': round(memory.used / (1024**3), 2),
                'used_percent': memory.percent / 100.0,
                'free_gb': round(memory.free / (1024**3), 2),
                'cached_gb': round(memory.cached / (1024**3), 2) if hasattr(memory, 'cached') else None
            }
            
            resources['swap_memory'] = {
                'total_gb': round(swap.total / (1024**3), 2),
                'used_gb': round(swap.used / (1024**3), 2),
                'used_percent': swap.percent / 100.0,
                'free_gb': round(swap.free / (1024**3), 2)
            }
        except Exception as e:
            logger.warning(f"获取内存信息失败: {str(e)}")
        
        # 磁盘信息
        try:
            # 获取根目录磁盘使用情况
            disk_usage = psutil.disk_usage('/') if os.name != 'nt' else psutil.disk_usage('C:')
            resources['disk'] = {
                'total_gb': round(disk_usage.total / (1024**3), 2),
                'used_gb': round(disk_usage.used / (1024**3), 2),
                'used_percent': disk_usage.percent / 100.0,
                'free_gb': round(disk_usage.free / (1024**3), 2)
            }
        except Exception as e:
            logger.warning(f"获取磁盘信息失败: {str(e)}")
        
        # GPU信息
        resources['has_gpu'] = torch.cuda.is_available()
        if resources['has_gpu']:
            try:
                # 获取详细GPU信息
                gpu_stats = self.get_gpu_memory_stats()
                resources['gpu'] = {}
                
                if gpu_stats:
                    # 使用nvidia-smi或PyTorch获取的详细信息
                    resources['gpu'].update(gpu_stats)
                    try:
                        # 统一提供GB单位的快捷字段
                        resources['gpu_memory_total_gb'] = round(float(gpu_stats.get('total', 0)) / 1024.0, 2)
                        resources['gpu_memory_used_gb'] = round(float(gpu_stats.get('used', 0)) / 1024.0, 2)
                        resources['gpu_memory_free_gb'] = round(float(gpu_stats.get('free', 0)) / 1024.0, 2)
                    except Exception:
                        pass
                    
                    # 添加PyTorch设备属性
                    for i in range(torch.cuda.device_count()):
                        props = torch.cuda.get_device_properties(i)
                        # 查找对应的GPU信息
                        for gpu in gpu_stats.get('gpus', []):
                            if gpu['index'] == i:
                                gpu['compute_capability'] = f"{props.major}.{props.minor}"
                                gpu['multi_processor_count'] = props.multi_processor_count
                                gpu['device_id'] = props.name
                                break
                else:
                    # 基本GPU信息
                    resources['gpu']['gpu_count'] = torch.cuda.device_count()
                    resources['gpu']['gpu_names'] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
            except Exception as e:
                logger.warning(f"获取GPU信息失败: {str(e)}")
        
        # 进程信息
        try:
            process = psutil.Process()
            with process.oneshot():
                resources['process'] = {
                    'pid': process.pid,
                    'name': process.name(),
                    'created_at': process.create_time(),
                    'memory_info': {
                        'rss_gb': round(process.memory_info().rss / (1024**3), 3),
                        'vms_gb': round(process.memory_info().vms / (1024**3), 3),
                    },
                    'cpu_percent': process.cpu_percent(interval=0.1)
                }
        except Exception as e:
            logger.warning(f"获取进程信息失败: {str(e)}")
        
        # 检查是否有内存警告
        if resources.get('system_memory', {}).get('used_percent', 0) > self._memory_threshold:
            resources['memory_warning'] = f"系统内存使用率超过阈值: {resources['system_memory']['used_percent'] * 100:.1f}%"
        
        # 检查GPU内存警告
        if resources.get('gpu', {}).get('used_percent', 0) > self._gpu_memory_threshold:
            resources['gpu_memory_warning'] = f"GPU内存使用率超过阈值: {resources['gpu']['used_percent'] * 100:.1f}%"
        
        return resources
    
    def _adjust_defaults_based_on_resources(self):
        """
        根据系统资源情况调整默认配置
        """
        resources = self.system_resources
        
        # 根据GPU内存调整配置
        if resources.get('has_gpu', False):
            gpu_memory_gb = resources.get('gpu_memory_total_gb', 0)
            
            # 小显存GPU自动调整量化和阈值
            if gpu_memory_gb < 4:
                # 2GB以下显存，建议使用4位量化
                self._gpu_memory_threshold = 0.7  # 降低阈值
                logger.info("检测到小显存GPU (<4GB)，已降低GPU内存阈值并建议使用4位量化")
            elif gpu_memory_gb < 8:
                # 4-8GB显存，建议使用8位量化
                self._gpu_memory_threshold = 0.75
                logger.info("检测到中等显存GPU (4-8GB)，已调整GPU内存阈值并建议使用8位量化")
        else:
            # 无GPU时的调整
            self._max_models = max(1, self._max_models // 2)  # 减少最大模型数
            logger.info("未检测到GPU，已减少最大模型数")
    
    def estimate_required_memory(self, model_type: str, model_size: str = 'medium', quantization: str = None) -> float:
        """
        估算模型所需内存，考虑量化因素
        
        Args:
            model_type: 模型类型
            model_size: 模型大小 ('small', 'medium', 'large')
            quantization: 量化类型 ('4bit', '8bit', 'nf4', None)
            
        Returns:
            估算的内存需求（GB）
        """
        # 基础内存需求估计（GB）
        memory_estimates = {
            'llm': {
                'small': 4.0,
                'medium': 10.0,
                'large': 20.0
            },
            'embedding': {
                'small': 1.0,
                'medium': 3.0,
                'large': 8.0
            },
            'vision': {
                'small': 2.0,
                'medium': 5.0,
                'large': 12.0
            },
            'image_gen': {
                'small': 5.0,
                'medium': 12.0,
                'large': 24.0
            },
            'tts': {
                'small': 1.0,
                'medium': 2.0,
                'large': 5.0
            },
            'stt': {
                'small': 1.0,
                'medium': 3.0,
                'large': 8.0
            }
        }
        
        # 获取估计值，如果没有找到则返回默认值
        base_memory = memory_estimates.get(model_type, {}).get(model_size, 4.0)
        
        # 考虑量化对内存需求的影响
        # 量化系数：NF4 4位量化约为原始的25%，8位量化约为原始的50%
        quantization_factors = {
            '4bit': 0.25,
            'nf4': 0.25,  # NF4是4位量化的一种变体
            '8bit': 0.5
        }
        
        if quantization in quantization_factors:
            adjusted_memory = base_memory * quantization_factors[quantization]
            logger.debug(f"量化内存估计: 基础={base_memory}GB, 量化类型={quantization}, 调整后={adjusted_memory:.2f}GB")
            return adjusted_memory
        
        logger.debug(f"基础内存估计: 类型={model_type}, 大小={model_size}, 估计={base_memory}GB")
        return base_memory
    
    def _unload_oldest_model(self) -> bool:
        """
        卸载最久未使用的模型
        
        Returns:
            bool: 是否成功卸载
        """
        loaded_models = [(name, info) for name, info in self._models.items() if info.is_loaded and name not in getattr(self, '_pinned_models', set())]
        if not loaded_models:
            return False
        
        # 按最后使用时间排序，找到最久未使用的
        oldest_model = sorted(loaded_models, key=lambda x: x[1].last_used_time)[0]
        model_name = oldest_model[0]
        
        logger.info(f"准备卸载最久未使用的模型: {model_name}")
        return self.unload_model(model_name)
    
    def _estimate_model_memory(self, model: Any) -> float:
        """
        估算模型内存使用
        
        Args:
            model: 模型对象
            
        Returns:
            float: 估计内存使用量（MB）
        """
        # 对于PyTorch模型
        if hasattr(model, 'parameters'):
            total_size = 0
            for param in model.parameters():
                # 计算参数大小（字节）
                size = param.numel() * param.element_size()
                total_size += size
            
            # 转换为MB
            return total_size / (1024 * 1024)
        
        # 其他模型类型
        return 0.0
        
    def generate(
        self,
        model_name: str,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        **kwargs
    ) -> str:
        tokenizer = self.get_tokenizer(model_name)
        model = self.load_model(model_name)
        if model is None or tokenizer is None:
            raise RuntimeError(f"模型 {model_name} 未加载或分词器不存在")
        messages = [{"role": "user", "content": prompt}]
        use_chat = hasattr(tokenizer, "apply_chat_template")
        if use_chat:
            inputs = tokenizer.apply_chat_template(
                messages,
                tokenize=True,
                add_generation_prompt=True,
                return_tensors="pt"
            )
        else:
            enc = tokenizer(prompt, return_tensors="pt")
            inputs = enc
        try:
            device = next(model.parameters()).device
        except Exception:
            device = getattr(model, "device", "cpu")
        if use_chat:
            input_ids = inputs.to(device)
            attention_mask = None
        else:
            input_ids = inputs["input_ids"].to(device)
            attention_mask = inputs.get("attention_mask")
            if attention_mask is not None:
                attention_mask = attention_mask.to(device)
        generation_kwargs = dict(
            max_new_tokens=max_tokens,
            do_sample=True,
            temperature=temperature,
            top_p=top_p,
            eos_token_id=getattr(tokenizer, "eos_token_id", None),
        )
        rep = kwargs.get("repetition_penalty")
        if isinstance(rep, (int, float)) and rep and rep != 1.0:
            generation_kwargs["repetition_penalty"] = float(rep)
        import torch
        with torch.no_grad():
            if attention_mask is not None:
                output_ids = model.generate(input_ids=input_ids, attention_mask=attention_mask, **generation_kwargs)
            else:
                output_ids = model.generate(input_ids=input_ids, **generation_kwargs)
        base_len = input_ids.shape[-1]
        generated_ids = output_ids[0][base_len:]
        response = tokenizer.decode(generated_ids, skip_special_tokens=True)
        stop_strings = kwargs.get("stop_strings")
        if isinstance(stop_strings, (list, tuple)):
            cut_idx = None
            for s in stop_strings:
                if isinstance(s, str) and s:
                    i = response.find(s)
                    if i != -1:
                        cut_idx = i if cut_idx is None else min(cut_idx, i)
            if cut_idx is not None:
                response = response[:cut_idx]
        return response.strip()

# Models directory watcher
_models_observer = None
_models_loop = None
_models_debounce_timer = None

def _classify_model_type(path: str, name: str) -> str:
    lower = name.lower()
    if os.path.exists(os.path.join(path, "model_index.json")):
        return "image_gen"
    if any(k in lower for k in ["llm", "qwen", "llama", "gpt"]):
        return "llm"
    if any(k in lower for k in ["vit", "clip", "vision", "sam", "vl"]):
        return "vision"
    if any(
        os.path.exists(os.path.join(path, fname))
        for fname in [
            "adapter_config.json",
            "pytorch_lora_weights.bin",
            "lora.safetensors"
        ]
    ) or ("lora" in lower):
        return "lora"
    if any(
        os.path.exists(os.path.join(path, fname))
        for fname in [
            "model.safetensors",
            "model.safetensors.index.json",
            "pytorch_model.bin"
        ]
    ) and ("checkpoint" in lower or "ckpt" in lower or "safetensors" in lower):
        return "checkpoint"
    return "unknown"

def _scan_models(max_depth: int = 3) -> list:
    items = []
    try:
        project_root = os.path.dirname(os.path.dirname(__file__))
        models_dir = os.path.join(project_root, "models")
        def scan_dir(base: str, rel: str, depth: int = 0):
            full = os.path.join(base, rel) if rel else base
            if depth > max_depth:
                return
            try:
                for entry in os.listdir(full):
                    p = os.path.join(full, entry)
                    rel_path = os.path.join(rel, entry) if rel else entry
                    if os.path.isdir(p):
                        t = _classify_model_type(p, entry)
                        has_model_files = any(
                            os.path.exists(os.path.join(p, fname))
                            for fname in [
                                "model.safetensors",
                                "model.safetensors.index.json",
                                "pytorch_model.bin",
                                "model_index.json",
                                "adapter_config.json",
                                "pytorch_lora_weights.bin",
                                "lora.safetensors"
                            ]
                        )
                        valid = has_model_files
                        items.append({
                            "id": rel_path.replace("\\", "/"),
                            "name": entry,
                            "type": t,
                            "path": rel_path.replace("\\", "/"),
                            "valid": valid,
                            "load_config": {"device": "auto", "quantization": {"enabled": False}}
                        })
                        scan_dir(base, rel_path, depth + 1)
            except Exception:
                pass
        if os.path.isdir(models_dir):
            scan_dir(models_dir, "", 0)
    except Exception:
        pass
    items = [x for x in items if x.get("valid")]
    seen = {}
    for it in items:
        key = it["id"]
        prev = seen.get(key)
        if not prev or (it.get("valid") and not prev.get("valid")):
            seen[key] = it
    return list(seen.values())

def _broadcast_models_update(loop: asyncio.AbstractEventLoop):
    try:
        from core.fastapi_websocket_adapter import FastAPIWebSocketAdapter
        payload = {"type": "models_update", "data": {"models": _scan_models()}}
        fut = asyncio.run_coroutine_threadsafe(
            FastAPIWebSocketAdapter.get_instance(), loop
        )
        adapter = fut.result()
        asyncio.run_coroutine_threadsafe(adapter.broadcast_message(payload), loop)
    except Exception:
        pass

class _ModelsChangedHandler(_FSEH):
    def on_created(self, event):
        _schedule_models_broadcast()
    def on_deleted(self, event):
        _schedule_models_broadcast()
    def on_modified(self, event):
        _schedule_models_broadcast()

def _schedule_models_broadcast():
    global _models_debounce_timer
    try:
        if _models_debounce_timer:
            _models_debounce_timer.cancel()
        _models_debounce_timer = threading.Timer(0.2, lambda: _broadcast_models_update(_models_loop))
        _models_debounce_timer.daemon = True
        _models_debounce_timer.start()
    except Exception:
        pass

def start_models_watcher(loop: asyncio.AbstractEventLoop) -> bool:
    global _models_observer, _models_loop
    if _Observer is None:
        return False
    try:
        project_root = os.path.dirname(os.path.dirname(__file__))
        models_dir = os.path.join(project_root, "models")
        if not os.path.isdir(models_dir):
            return False
        _models_loop = loop
        handler = _ModelsChangedHandler()
        obs = _Observer()
        obs.schedule(handler, models_dir, recursive=True)
        obs.start()
        _models_observer = obs
        _broadcast_models_update(loop)
        return True
    except Exception:
        return False

def stop_models_watcher() -> None:
    global _models_observer
    try:
        if _models_observer:
            _models_observer.stop()
            _models_observer.join(timeout=1.0)
            _models_observer = None
    except Exception:
        pass


# 创建全局模型管理器实例
model_manager = ModelManager()


def get_model_manager() -> ModelManager:
    """
    获取模型管理器实例
    
    Returns:
        ModelManager: 模型管理器实例
    """
    return model_manager
