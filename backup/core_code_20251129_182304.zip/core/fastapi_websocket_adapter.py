#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FastAPI WebSocket适配器
连接FastAPI的WebSocket和现有的WebSocketManager
"""
import logging
from typing import Optional, Dict, Any
import asyncio
from fastapi import WebSocket
import json
import time
import re

logger = logging.getLogger(__name__)


# 全局实例
_instance = None

# 实例锁
_instance_lock = asyncio.Lock()


class FastAPIWebSocketAdapter:
    """
    FastAPI WebSocket适配器
    将FastAPI的WebSocket接口转换为与现有WebSocketManager兼容的格式
    """
    def __init__(self):
        # 延迟导入以避免循环依赖
        self.websocket_manager = None
        self._initialized = False
    
    async def initialize(self):
        """
        初始化适配器，连接到现有的WebSocketManager
        """
        if not self._initialized:
            try:
                # 导入现有的WebSocketManager
                from core.websocket_manager import WebSocketManager
                
                # 创建或获取现有的管理器实例
                if not hasattr(FastAPIWebSocketAdapter, '_instance'):
                    FastAPIWebSocketAdapter._instance = WebSocketManager()
                
                self.websocket_manager = FastAPIWebSocketAdapter._instance
                
                # 检查WebSocketManager是否已就绪
                # 注意：WebSocketManager可能没有start方法，我们直接使用它
                
                self._initialized = True
                logger.info("FastAPI WebSocket适配器初始化完成")
                
            except Exception as e:
                logger.error(f"初始化FastAPI WebSocket适配器失败: {str(e)}", exc_info=True)
                raise
    
    async def shutdown(self):
        """
        关闭适配器资源
        """
        if self._initialized:
            # 清理WebSocket管理器相关资源
            # 注意：避免调用可能不存在的方法
            self._initialized = False
            logger.info("FastAPI WebSocket适配器资源已释放")
    
    async def _process_message(self, websocket, message):
        try:
            if not isinstance(message, dict):
                logger.warning(f"接收到非字典消息: {message}")
                return

            msg_type = message.get("type")
            logger.debug(f"收到消息类型: {msg_type}")

            if msg_type == "ping":
                await websocket.send_json({
                    "type": "pong",
                    "timestamp": message.get("timestamp", time.time())
                })
                return

            if msg_type in ("message", "chat"):
                content = str(message.get("content", "") or "").strip()
                msg_id = message.get("message_id") or str(int(time.time() * 1000))
                conversation_id = message.get("conversation_id") or "websocket"
                model = message.get("model") or "default"

                await websocket.send_json({
                    "type": "message",
                    "subtype": "acknowledged",
                    "message_id": msg_id,
                    "timestamp": time.time()
                })

                if not content:
                    await websocket.send_json({
                        "type": "message",
                        "subtype": "response",
                        "content": "请提供有效的输入内容。",
                        "message_id": msg_id,
                        "timestamp": time.time()
                    })
                    return

                try:
                    from services.fallback_service import get_aveline_service
                    from core.config_manager import ConfigManager
                    svc = get_aveline_service()
                    timeout_seconds = ConfigManager().get("limits.message_timeout", 120)
                    import asyncio as _asyncio
                    def _call():
                        return svc.generate_response(
                            user_input=content,
                            conversation_id=conversation_id,
                            max_tokens=80,
                            temperature=0.7,
                            timeout=timeout_seconds
                        )
                    response_text, _metadata = await _asyncio.to_thread(_call)
                except Exception as e:
                    logger.error(f"生成回复失败: {e}", exc_info=True)
                    response_text = "抱歉，我暂时无法处理您的请求，请稍后再试。"

                de = "neutral"
                # 优先从回复文本中解析情绪: [EMO:{...}] 或 末尾 {emotion}
                try:
                    raw_for_emo = str(response_text or "")
                    m_tag = re.search(r"^\[EMO:\s*(\{.*?\})\]", raw_for_emo)
                    if m_tag:
                        try:
                            import json as _json
                            weights = _json.loads(m_tag.group(1))
                            # 选择权重最大的情绪
                            de = max(weights.items(), key=lambda kv: float(kv[1] or 0.0))[0]
                        except Exception:
                            pass
                    else:
                        m_brace = re.search(r"\{([a-zA-Z_]+)\}\s*$", raw_for_emo)
                        if m_brace:
                            de = m_brace.group(1).strip()
                except Exception:
                    pass
                # 若仍未解析到，则根据用户输入关键词回退
                if not de or de == "neutral":
                    try:
                        ml = content.lower()
                        emotion_keywords = {
                            "happy": ["开心", "喜欢", "愉快", "高兴"],
                            "angry": ["生气", "愤怒", "火大", "糟糕"],
                            "excited": ["兴奋", "期待", "激动"],
                            "sad": ["伤心", "难过", "失落", "委屈"],
                            "shy": ["害羞"],
                            "jealous": ["吃醋", "嫉妒"],
                        }
                        for emo, kws in emotion_keywords.items():
                            if any(k in ml for k in kws):
                                de = emo
                                break
                    except Exception:
                        pass

                

                payload = {
                    "type": "message",
                    "subtype": "response",
                    "content": response_text,
                    "message_id": msg_id,
                    "timestamp": time.time(),
                    "conversation_id": conversation_id,
                    "model": model
                }
                if de and de != "neutral":
                    payload["emotion"] = de
                await websocket.send_json(payload)
                return

        except Exception as e:
            logger.error(f"处理消息出错: {str(e)}")

    async def handle_connection(self, websocket: WebSocket):
        """
        处理FastAPI的WebSocket连接
        """
        if not self._initialized:
            await self.initialize()
        
        # 接受连接
        await websocket.accept()
        
        # 从查询参数或消息中获取用户信息
        query_params = dict(websocket.query_params)
        user_id = query_params.get("user_id") or query_params.get("client_id") or "anonymous"
        platform = query_params.get("platform", "fastapi")
        
        logger.info(f"FastAPI WebSocket连接请求: user_id={user_id}, platform={platform}")
        
        try:
            # 创建一个包装类来适配FastAPI的WebSocket到websockets库的接口
            class WebSocketWrapper:
                def __init__(self, fastapi_ws):
                    self.fastapi_ws = fastapi_ws
                    # 模拟remote_address
                    self.remote_address = ("127.0.0.1", 0)  # 简化处理
                
                async def send_text(self, data):
                    await self.fastapi_ws.send_text(data)
                
                async def send(self, data):
                    """
                    适配websockets库的send方法
                    """
                    if isinstance(data, str):
                        await self.fastapi_ws.send_text(data)
                    else:
                        # 假设是bytes或json对象(如果被误传)
                        await self.fastapi_ws.send_text(str(data))

                async def send_json(self, data):
                    await self.fastapi_ws.send_json(data)
                
                async def recv_text(self):
                    return await self.fastapi_ws.receive_text()
                
                async def recv_json(self):
                    return await self.fastapi_ws.receive_json()
                
                async def close(self, code=1000, reason=""):
                    await self.fastapi_ws.close(code=code, reason=reason)
                
                @property
                def closed(self):
                    # FastAPI的WebSocket没有直接的closed属性，需要通过状态判断
                    return not self.fastapi_ws.client
            
            # 创建包装器
            ws_wrapper = WebSocketWrapper(websocket)
            
            # 添加到现有管理器
            # 注意：这里假设websocket_manager有add_connection方法
            # 如果没有，可能需要适配
            added = await self.websocket_manager.add_connection(
                ws_wrapper,
                user_id=user_id,
                platform=platform
            )
            
            if not added:
                await websocket.close(code=1008, reason="Connection limit exceeded")
                return
            
            # 处理消息循环
            while True:
                try:
                    # 检查WebSocketManager是否有关闭连接
                    if ws_wrapper.closed:
                        break
                        
                    # 读取消息以保持连接活跃并检测断开
                    message_text = await websocket.receive_text()
                    
                    # 尝试解析为JSON
                    try:
                        message = json.loads(message_text)
                    except json.JSONDecodeError:
                        message = {"type": "text", "content": message_text}
                    
                    # 记录活动时间（模拟现有管理器的行为）
                    # 这里的访问方式依赖于WebSocketManager的内部结构，可能需要调整
                    # 但为了简单起见，我们先跳过直接修改内部状态，而是让_process_message处理
                    
                    # 处理消息
                    await self._process_message(ws_wrapper, message)
                    
                except Exception as e:
                    # 连接断开或其他错误
                    logger.debug(f"WebSocket循环中断: {str(e)}")
                    break
                    
        except Exception as e:
            logger.error(f"处理WebSocket连接时出错: {str(e)}")
        finally:
            # 清理连接
            if self.websocket_manager:
                try:
                    # 尝试移除连接
                    # 注意：这里假设websocket_manager有remove_connection方法
                    # 且参数签名可能不同，这里尝试传递ws_wrapper
                    if hasattr(self.websocket_manager, 'remove_connection'):
                        # 检查方法签名或尝试调用
                        # 假设签名是 remove_connection(ws)
                        await self.websocket_manager.remove_connection(ws_wrapper)
                except Exception as e:
                    logger.error(f"移除WebSocket连接时出错: {str(e)}")

    @classmethod
    async def get_instance(cls):
        """
        获取适配器实例（异步方式）
        """
        global _instance
        async with _instance_lock:
            if _instance is None:
                _instance = cls()
                await _instance.initialize()
        return _instance


# 同步版本的获取函数，用于依赖注入
def get_fastapi_websocket_adapter() -> Optional[FastAPIWebSocketAdapter]:
    """
    获取FastAPI WebSocket适配器实例（同步方式）
    用于依赖注入
    """
    global _instance
    if _instance is None:
        # 创建实例但不初始化（初始化需要在异步上下文中进行）
        _instance = FastAPIWebSocketAdapter()
    return _instance


async def initialize_websocket_adapter():
    """
    初始化WebSocket适配器
    被生命周期管理器调用
    """
    global _instance
    async with _instance_lock:
        if _instance is None:
            _instance = FastAPIWebSocketAdapter()
            await _instance.initialize()
            logger.info("WebSocket适配器初始化成功")
        else:
            logger.info("WebSocket适配器已初始化")
    return _instance


async def shutdown_websocket_adapter():
        """
        关闭WebSocket适配器
        被生命周期管理器调用
        """
        global _instance
        async with _instance_lock:
            if _instance is not None:
                try:
                    # 实现shutdown方法关闭相关资源
                    await _instance.shutdown()
                    logger.info("WebSocket适配器关闭成功")
                except Exception as e:
                    logger.error(f"关闭WebSocket适配器时出错: {str(e)}")
                finally:
                    _instance = None
            else:
                logger.info("WebSocket适配器未初始化，无需关闭")
