import argparse
import os
import sys
import uuid
import time
import asyncio

VOICE_MAP = {
    '妹妹': r'D:\AI\xiaoyou-core\ref_audio\female\妹妹.wav',
    '欢欢': r'D:\AI\xiaoyou-core\ref_audio\female\欢欢本音.wav',
    '欢欢1': r'D:\AI\xiaoyou-core\ref_audio\female\huanhuan.wav',
}

def _project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

def _default_output():
    ts = time.strftime('%Y%m%d_%H%M%S')
    name = f"tts_{ts}_{str(uuid.uuid4())[:8]}.wav"
    return os.path.join(_project_root(), 'output', 'voice', name)

def _ensure_dir(p):
    d = os.path.dirname(p)
    if not os.path.exists(d):
        os.makedirs(d, exist_ok=True)

sys.path.insert(0, _project_root())

async def _run(text, output, args):
    from core.voice import text_to_speech
    kwargs = {}
    if getattr(args, 'voice_id', ''):
        kwargs['voice_id'] = args.voice_id
    # 优先使用显式 reference_audio，其次使用 --voice 的内置映射
    ref = getattr(args, 'reference_audio', '')
    if ref:
        ra = ref
        if not os.path.isabs(ra):
            ra = os.path.join(_project_root(), ra)
        kwargs['reference_audio'] = ra
    else:
        voice_name = getattr(args, 'voice', '')
        if voice_name:
            mapped = VOICE_MAP.get(voice_name)
            if mapped:
                kwargs['reference_audio'] = mapped
    if args.text_language:
        kwargs['text_language'] = args.text_language
        kwargs['prompt_language'] = args.text_language
    kwargs['how_to_cut'] = args.how_to_cut
    kwargs['parallel_infer'] = args.parallel_infer
    kwargs['split_bucket'] = args.split_bucket
    kwargs['speed'] = args.speed
    kwargs['pitch'] = args.pitch
    kwargs['style'] = args.style
    kwargs['emotion'] = args.emotion
    kwargs['sing_mode'] = args.sing_mode
    _ensure_dir(output)
    await text_to_speech(text, output_path=output, **kwargs)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--text', type=str, default='')
    p.add_argument('--voice_id', type=str, default='')
    p.add_argument('--reference_audio', type=str, default='')
    p.add_argument('--voice', type=str, choices=list(VOICE_MAP.keys()), help='预置参考音频名')
    p.add_argument('--text_language', type=str, default='中文')
    p.add_argument('--how_to_cut', type=str, default='不切')
    p.add_argument('--parallel_infer', action='store_true')
    p.add_argument('--split_bucket', action='store_true')
    p.add_argument('--style', type=int, default=3)
    p.add_argument('--speed', type=float, default=1.0)
    p.add_argument('--pitch', type=float, default=1.0)
    p.add_argument('--emotion', type=float, default=0.5)
    p.add_argument('--sing_mode', action='store_true')
    p.add_argument('--output', type=str, default='')
    p.add_argument('--once', action='store_true')
    args = p.parse_args()
    if args.text:
        output = args.output or _default_output()
        asyncio.run(_run(args.text, output, args))
        if args.once:
            return
    while True:
        try:
            text = input('请输入文本(回车退出): ').strip()
        except EOFError:
            break
        if not text:
            break
        output = _default_output()
        asyncio.run(_run(text, output, args))

if __name__ == '__main__':
    main()
