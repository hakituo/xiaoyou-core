#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API路由模块
处理常规HTTP请求端点
"""
import logging
import asyncio
import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body
from fastapi.responses import JSONResponse
import base64
import io
import os
import json
import re

from core.task_scheduler_adapter import io_task
from core.cpu_task_processor import cpu_task

# 安全配置常量
MAX_FEEDBACK_LENGTH = 2000
MAX_CONVERSATION_ID_LENGTH = 64
VALID_FEEDBACK_TYPES = ["bug", "suggestion", "feedback", "question"]
SENSITIVE_FIELDS = ["password", "token", "key", "secret", "credit_card", "ssn", "phone", "email"]

# 导入真实的Aveline服务和配置管理器
from services.fallback_service import get_aveline_service as real_get_aveline_service
from core.config_manager import ConfigManager
from core.voice import get_tts_manager, get_speakers
from core.voice.utils.text_processor import TextProcessor
from core.model_manager import get_model_manager

def get_aveline_service():
    """获取Aveline服务实例"""
    return real_get_aveline_service()

logger = logging.getLogger(__name__)
# 初始化配置管理器
config_manager = ConfigManager()

router = APIRouter(prefix="/api/v1", tags=["api"])

def _project_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def _memory_dir():
    d = os.path.join(_project_root(), "output", "memory", "conversations")
    os.makedirs(d, exist_ok=True)
    return d

def _voice_dir():
    d = os.path.join(_project_root(), "output", "voice")
    os.makedirs(d, exist_ok=True)
    return d

def _append_memory(conversation_id: str, role: str, content: str, ts: float):
    path = os.path.join(_memory_dir(), f"{conversation_id}.json")
    data = {}
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
    if not isinstance(data, dict):
        data = {}
    if "id" not in data:
        data["id"] = conversation_id
    if "created_at" not in data:
        data["created_at"] = datetime.fromtimestamp(ts).isoformat()
    msgs = data.get("messages") or []
    if not isinstance(msgs, list):
        msgs = []
    msgs.append({"role": role, "content": content, "timestamp": datetime.fromtimestamp(ts).isoformat()})
    data["messages"] = msgs
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except Exception:
        pass


@router.post("/analyze_screen")
async def analyze_screen(
    data: Dict[str, Any] = Body(..., description="Screen image data")
):
    """
    Analyze screen image
    """
    import uuid
    import time
    
    request_id = str(uuid.uuid4())
    logger.info(f"Received screen analysis request: ID={request_id}")
    
    # Mock response
    return {
        "status": "success",
        "description": "Screen analysis simulated result: No specific content detected (Mock).",
        "elements": [],
        "request_id": request_id,
        "timestamp": time.time()
    }


@router.post("/message")
async def handle_message(
    message: Dict[str, Any] = Body(..., description="用户消息内容"),
    conversation_id: Optional[str] = Query(None, description="会话ID"),
    model: Optional[str] = Query("default", description="使用的模型")
):
    """
    处理用户消息 - 优化版
    支持与前端一致的消息格式和错误处理
    
    Args:
        message: 消息内容，包含content字段
        conversation_id: 会话ID，用于上下文管理
        model: 指定使用的模型
    """
    import uuid
    import time
    
    # 生成请求ID
    request_id = str(uuid.uuid4())
    
    try:
        # 验证消息格式
        if not isinstance(message, dict):
            return {
                "status": "error",
                "error_code": "INVALID_MESSAGE_FORMAT",
                "detail": "消息格式无效，必须是JSON对象",
                "request_id": request_id,
                "timestamp": time.time()
            }
        
        # 提取消息内容 - 支持多种字段命名以增强兼容性
        content = ""
        for field in ["content", "message", "text"]:
            if field in message:
                content = str(message[field]).strip()
                break
        
        if not content or not isinstance(content, str):
            return {
                "status": "error",
                "error_code": "EMPTY_CONTENT",
                "detail": "消息内容不能为空且必须是字符串",
                "request_id": request_id,
                "timestamp": time.time()
            }
        
        # 验证内容长度
        if len(content) > 10000:  # 限制消息长度
            return {
                "status": "error",
                "error_code": "CONTENT_TOO_LARGE",
                "detail": "消息内容过长，请减少内容后重试",
                "request_id": request_id,
                "timestamp": time.time()
            }
        
        # 记录请求信息（不记录具体内容，只记录长度和会话ID）
        logger.info(f"收到消息请求: 请求ID={request_id} 长度={len(content)} 会话ID={conversation_id or 'new'}")
        
        # 获取Aveline服务
        aveline_service = get_aveline_service()
        
        try:
            # 创建任务并设置超时
            task = asyncio.create_task(process_message_with_async(
                content=content,
                conversation_id=conversation_id,
                model=model,
                aveline_service=aveline_service
            ))
            
            # 从配置中获取超时时间
            timeout_seconds = config_manager.get("limits.message_timeout", 120)  # 默认120秒
            # 设置超时
            response = await asyncio.wait_for(task, timeout=timeout_seconds)
            
            # 统一响应格式 - 确保与前端期望格式一致
            response_data = {
                "status": "success",
                "response": response.get("reply", response.get("response", "")),
                "request_id": request_id,
                "timestamp": time.time(),
                "message_id": str(uuid.uuid4()),
                "conversation_id": response.get("conversation_id", conversation_id),
                "model": response.get("model", model)
            }
            try:
                s = str(response_data["response"] or "")
                s = re.sub(r"^\[EMO:\s*\{.*?\}\]\s*", "", s)
                s = re.sub(r"\s*\{neutral\}\s*", " ", s, flags=re.IGNORECASE)
                s = re.sub(r"\s*\{(happy|angry|excited|lost|wronged|jealous|coquetry|shy)\}\s*$", "", s, flags=re.IGNORECASE)
                response_data["response"] = s
            except Exception:
                pass
            
            try:
                raw_emotion = str(response.get("emotion", "")).strip().lower()
                if raw_emotion and raw_emotion != "neutral":
                    response_data["emotion"] = response.get("emotion")
            except Exception:
                pass
            
            

            try:
                if not response_data.get("emotion") or str(response_data.get("emotion")).strip().lower() == "neutral":
                    raw_for_emo = str(response_data.get("response") or "")
                    m_tag = re.search(r"^\[EMO:\s*(\{.*?\})\]", raw_for_emo)
                    found = None
                    if m_tag:
                        import json as _json
                        try:
                            weights = _json.loads(m_tag.group(1))
                            found = max(weights.items(), key=lambda kv: float(kv[1] or 0.0))[0]
                        except Exception:
                            pass
                    else:
                        m_brace = re.search(r"\{([a-zA-Z_]+)\}\s*$", raw_for_emo)
                        if m_brace:
                            found = m_brace.group(1).strip()
                        else:
                            m_paren = re.search(r"\((neutral|happy|angry|excited|lost|wronged|jealous|coquetry|shy)\)\s*$", raw_for_emo, re.IGNORECASE)
                            if m_paren:
                                found = m_paren.group(1).strip()
                    if found and str(found).strip().lower() != "neutral":
                        response_data["emotion"] = found
                    else:
                        s_low = raw_for_emo.lower()
                        if re.search(r"(生气|愤怒|火大|糟糕|讨厌|不爽|暴躁|烦)", s_low):
                            response_data["emotion"] = "angry"
                        elif re.search(r"(失落|伤心|难过|难受|沮丧|低落)", s_low):
                            response_data["emotion"] = "lost"
                        elif re.search(r"(委屈)", s_low):
                            response_data["emotion"] = "wronged"
                        elif re.search(r"(吃醋|嫉妒)", s_low):
                            response_data["emotion"] = "jealous"
                        elif re.search(r"(撒娇|傲娇|粘人|靠近|拥抱|亲吻|抱紧|靠在|贴着)", s_low):
                            response_data["emotion"] = "coquetry"
                        elif re.search(r"(害羞|脸红|不好意思|羞涩)", s_low):
                            response_data["emotion"] = "shy"
                        elif re.search(r"(兴奋|激动|期待|亢奋)", s_low):
                            response_data["emotion"] = "excited"
                        elif re.search(r"(开心|愉快|高兴|满足|喜悦)", s_low):
                            response_data["emotion"] = "happy"
            except Exception:
                pass

            # 如果有token使用信息，也返回
            if "tokens_used" in response:
                response_data["tokens_used"] = response["tokens_used"]
            
            return response_data
            
        except asyncio.TimeoutError:
            # 取消超时的任务
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
                
            logger.error(f"消息处理超时: 请求ID={request_id} 会话ID={conversation_id}")
            # 不抛异常而是直接返回错误响应，避免HTTP 504错误页面
            return {
                "status": "error",
                "error_code": "PROCESSING_TIMEOUT",
                "detail": "消息处理超时，请稍后再试",
                "request_id": request_id,
                "timestamp": time.time()
            }
        
    except Exception as e:
        # 记录详细错误日志，但返回通用错误信息
        logger.error(f"处理消息时出错: 请求ID={request_id} {str(e)}", exc_info=True)
        # 不抛异常而是直接返回错误响应，保持与前端的JSON交互一致性
        return {
            "status": "error",
            "error_code": "INTERNAL_SERVER_ERROR",
            "detail": "服务器内部错误，请稍后再试",
            "request_id": request_id,
            "timestamp": time.time()
        }


@io_task
async def _generate_tts_with_async(text: str, params: Dict[str, Any]) -> Dict[str, Any]:
    manager = await get_tts_manager()
    audio_np = await manager.synthesize(text, **params)
    try:
        sr = int(getattr(getattr(manager, "active_engine", None), "config", {}).get("sample_rate", getattr(getattr(manager, "active_engine", None), "sample_rate", 44100)))
    except Exception:
        sr = 24000
    import numpy as _np
    import soundfile as _sf
    buf = io.BytesIO()
    arr = _np.asarray(audio_np, dtype=_np.float32)
    m = float(_np.max(_np.abs(arr))) if arr.size else 0.0
    if m > 1.0:
        arr = (arr / m).astype(_np.float32)
    arr = arr.clip(-1.0, 1.0)
    pcm16 = (arr * 32767.0).astype(_np.int16)
    _sf.write(buf, pcm16, sr, format="WAV", subtype="PCM_16")
    audio_b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    out_dir = _voice_dir()
    fname = f"tts_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}.wav"
    fpath = os.path.join(out_dir, fname)
    try:
        _sf.write(fpath, pcm16, sr, format="WAV", subtype="PCM_16")
        rel = f"output/voice/{fname}"
    except Exception:
        rel = ""
    return {"audio_base64": f"data:audio/wav;base64,{audio_b64}", "sample_rate": sr, "file_path": rel, "text": text}


@router.post("/tts")
async def tts(
    payload: Dict[str, Any] = Body(...)
):
    request_id = str(uuid.uuid4())
    try:
        if not isinstance(payload, dict):
            return {
                "status": "error",
                "error_code": "INVALID_PAYLOAD",
                "detail": "请求体必须是JSON对象",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        text = str(payload.get("text", "")).strip()
        if not text:
            return {
                "status": "error",
                "error_code": "EMPTY_TEXT",
                "detail": "文本不能为空",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        if len(text) > 20000:
            text = text[:20000]
        # 文本清理与标记提取
        tp = TextProcessor(max_segment_length=1000)
        cleaned1, markers = tp.extract_markers(text)
        cleaned1 = tp.remove_bracketed(cleaned1)
        cleaned1 = re.sub(r"#([^#]{1,64})#", " ", cleaned1)
        cleaned1 = re.sub(r"\s{2,}", " ", cleaned1).strip()
        try:
            nm = str(payload.get("assistant_name") or "Aveline")
            cleaned1 = re.sub(r"^\s*(用户)\s*:\s*", "", cleaned1)
            cleaned1 = re.sub(r"^\s*" + re.escape(nm) + r"\s*:\s*", "", cleaned1)
        except Exception:
            pass
        params = payload.copy()
        params.pop("text", None)
        if "speed" not in params and "speed" in markers:
            params["speed"] = float(markers.get("speed", 1.0))
        if "pitch" not in params and "pitch" in markers:
            params["pitch"] = float(markers.get("pitch", 1.0))
        if "style" not in params and "style" in markers:
            params["style"] = markers.get("style")
        for k in ("xfade_ms", "pause_second", "noise_gate_threshold", "hp_cut", "lp_cut", "fade_ms"):
            if k in payload:
                params[k] = payload[k]
        if "xfade_ms" not in params:
            params["xfade_ms"] = 20
        if "pause_second" not in params:
            params["pause_second"] = 0.25
        if "noise_gate_threshold" not in params:
            params["noise_gate_threshold"] = 0.006
        if "hp_cut" not in params:
            params["hp_cut"] = 100.0
        if "lp_cut" not in params:
            params["lp_cut"] = 6000.0
        if "fade_ms" not in params:
            params["fade_ms"] = 20
        if "downsample_sr" in params and not params["downsample_sr"]:
            params.pop("downsample_sr", None)
        text = tp.normalize_text(cleaned1)
        timeout_seconds = ConfigManager().get("limits.tts_timeout", 120)
        task = asyncio.create_task(_generate_tts_with_async(text=text, params=params))
        result = await asyncio.wait_for(task, timeout=timeout_seconds)
        return {
            "status": "success",
            "data": result,
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
    except asyncio.TimeoutError:
        return {
            "status": "error",
            "error_code": "TTS_TIMEOUT",
            "detail": "语音合成超时",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"TTS生成失败: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "TTS_ERROR",
            "detail": "语音合成失败",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.post("/search/web")
async def search_web(
    payload: Dict[str, Any] = Body(...)
):
    request_id = str(uuid.uuid4())
    try:
        if not isinstance(payload, dict):
            return {
                "status": "error",
                "error_code": "INVALID_PAYLOAD",
                "detail": "请求体必须是JSON对象",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        query = str(payload.get("query", "")).strip()
        provider = str(payload.get("provider", "bocha")).lower()
        if not query:
            return {
                "status": "error",
                "error_code": "EMPTY_QUERY",
                "detail": "查询内容不能为空",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        if provider not in ("bocha", "tavily"):
            return {
                "status": "error",
                "error_code": "UNSUPPORTED_PROVIDER",
                "detail": f"不支持的provider: {provider}",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        if provider == "bocha":
            api_key = os.environ.get("BOCHA_API_KEY")
            if not api_key:
                return {
                    "status": "error",
                    "error_code": "MISSING_API_KEY",
                    "detail": "未配置BOCHA_API_KEY，已留API占位",
                    "request_id": request_id,
                    "timestamp": datetime.now().isoformat(),
                    "data": {"placeholder": True}
                }
            try:
                import requests as _req
                url = "https://api.bochaai.com/v1/web-search"
                body = {
                    "query": query,
                    "freshness": payload.get("freshness", "noLimit"),
                    "summary": bool(payload.get("summary", True)),
                    "count": int(payload.get("count", 3))
                }
                headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
                resp = _req.post(url, json=body, headers=headers, timeout=30)
                data = {}
                try:
                    data = resp.json()
                except Exception:
                    data = {"status_code": resp.status_code, "text": resp.text[:1000]}
                return {
                    "status": "success" if resp.status_code == 200 else "error",
                    "data": data,
                    "request_id": request_id,
                    "timestamp": datetime.now().isoformat()
                }
            except Exception as e:
                logger.error(f"Bocha搜索失败: {e}", exc_info=True)
                return {
                    "status": "error",
                    "error_code": "SEARCH_FAILED",
                    "detail": "搜索服务调用失败",
                    "request_id": request_id,
                    "timestamp": datetime.now().isoformat()
                }
        else:
            return {
                "status": "error",
                "error_code": "MISSING_API_KEY",
                "detail": "未配置TAVILY_API_KEY，已留API占位",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat(),
                "data": {"placeholder": True}
            }
    except Exception as e:
        logger.error(f"搜索接口失败: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "INTERNAL_SERVER_ERROR",
            "detail": "服务器内部错误",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }

@router.get("/voices")
async def list_voices():
    request_id = str(uuid.uuid4())
    try:
        spks = await get_speakers()
        voices = [{"id": str(s), "name": str(s)} for s in spks]
        return {
            "status": "success",
            "data": {"voices": voices},
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"获取声音列表失败: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "VOICES_ERROR",
            "detail": "无法获取声音列表",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }

@io_task
async def process_message_with_async(
    content: str,
    conversation_id: Optional[str],
    model: str,
    aveline_service
) -> Dict[str, Any]:
    """
    异步处理消息 - 优化版
    包含更健壮的错误处理和结构化响应
    """
    # 记录消息接收（不记录完整内容）
    logger.info(f"处理消息: 长度={len(content)} 会话ID={conversation_id or 'new'}")
    
    try:
        # 从配置获取超时设置
        config_manager = ConfigManager()
        timeout_seconds = config_manager.get("limits.message_timeout", 60)
        logger.info(f"使用消息处理超时设置: {timeout_seconds}秒")
        
        # 调用Aveline服务生成回复（注意：这不是异步方法）
        response_content, metadata = aveline_service.generate_response(
            user_input=content,
            conversation_id=conversation_id,
            max_tokens=256,
            temperature=0.7,
            timeout=timeout_seconds,
            model_hint=model
        )
        
        # 简单的情绪分析示例
        # 实际应用中可能由专门的情绪分析服务提供
        message_lower = content.lower()
        emotion_keywords = {
            "happy": ["开心", "喜欢", "好的", "棒", "优秀", "满意"],
            "angry": ["生气", "笨蛋", "糟糕", "差", "不好", "不满意"],
            "excited": ["兴奋", "期待", "激动"],
            "sad": ["伤心", "难过", "失落", "委屈"],
            "coquetry": ["撒娇", "靠近", "拥抱", "亲吻", "吻", "贴着", "抱紧", "粘人", "看着我", "靠在"],
            "neutral": []
        }
        
        detected_emotion = "neutral"
        for emotion, keywords in emotion_keywords.items():
            if any(keyword in message_lower for keyword in keywords):
                detected_emotion = emotion
                break
        
        
        
        # 结构化响应，添加额外信息
        result = {
            "reply": response_content,
            "response": response_content,
            "conversation_id": conversation_id,
            "model": model,
            "tokens_used": {
                "prompt": len(content.split()),
                "completion": len(response_content.split())
            },
            "status": "normal"
        }
        
        if detected_emotion != "neutral":
            result["emotion"] = detected_emotion
        cid = conversation_id or "default"
        now_ts = datetime.now().timestamp()
        _append_memory(cid, "user", content, now_ts)
        _append_memory(cid, "assistant", response_content, now_ts)
        
        return result
        
    except asyncio.CancelledError:
        # 任务被取消时的处理
        logger.info(f"消息处理任务被取消: 会话ID={conversation_id or 'new'}")
        raise
        
    except Exception as e:
        logger.error(f"生成回复时出错: {str(e)}")
        
        # 直接使用简单的备用回复，避免调用不存在的方法
        # 我们已经在AvelineService.generate_response中实现了完整的错误处理
        response_content = "抱歉，我暂时无法处理您的请求，请稍后再试。"
        
        return {
            "reply": response_content,
            "response": response_content,  # 同时提供两种键名以增加兼容性
            "conversation_id": conversation_id,
            "model": model,
            "status": "fallback",
            "emotion": "neutral"  # 错误情况下返回中性情绪
        }


@router.get("/conversations")
async def list_conversations(
    limit: int = Query(10, ge=1, le=100, description="返回记录数"),
    offset: int = Query(0, ge=0, description="偏移量"),
    sort_by: str = Query("created_at", regex="^(created_at|title|last_message)$", description="排序字段"),
    order: str = Query("desc", regex="^(asc|desc)$", description="排序方向")
):
    """
    获取会话列表 - 增强版
    添加了更严格的参数验证、安全日志和错误处理
    """
    # 生成请求ID用于跟踪
    request_id = str(uuid.uuid4())
    
    try:
        # 安全日志记录 - 不记录可能的敏感信息
        logger.info(f"获取会话列表请求, 请求ID: {request_id}, limit: {limit}, offset: {offset}")
        
        # 这里应该从数据库中获取会话列表，实际应用中应添加用户身份验证
        # 暂时返回模拟数据
        conversations = [
            {
                "id": f"conv_{i}",
                "title": f"会话 #{i}",
                "created_at": datetime.now().isoformat(),
                "last_message": f"这是会话{i}的最后一条消息"
            }
            for i in range(limit)
        ]
        
        # 统一响应格式
        return {
            "status": "success",
            "data": {
                "conversations": conversations,
                "total": 100,  # 模拟总数
                "limit": limit,
                "offset": offset
            },
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取会话列表时出错, 请求ID: {request_id}, 错误: {str(e)}", exc_info=True)
        # 不向客户端暴露具体的错误信息
        return {
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "detail": "获取会话列表失败，请稍后再试",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.get("/conversations/{conversation_id}")
async def get_conversation(
    conversation_id: str = Path(..., regex="^[a-zA-Z0-9_-]{1,64}$", description="会话ID")
):
    """
    获取会话详情 - 增强版
    添加了会话ID格式验证、安全检查和改进的错误处理
    """
    # 生成请求ID
    request_id = str(uuid.uuid4())
    
    try:
        # 安全日志记录
        logger.info(f"获取会话详情请求, 请求ID: {request_id}, 会话ID: {conversation_id}")
        
        # 在实际应用中，这里应该验证用户是否有权限访问此会话
        # 例如: if not await has_conversation_access(user_id, conversation_id):
        #         return {"status": "error", "error_code": "ACCESS_DENIED", ...}
        
        # 模拟会话详情
        conversation = {
            "id": conversation_id,
            "title": f"会话: {conversation_id}",
            "created_at": datetime.now().isoformat(),
            "messages": [
                {
                    "id": "msg_1",
                    "role": "user",
                    "content": "你好",
                    "timestamp": datetime.now().isoformat()
                },
                {
                    "id": "msg_2",
                    "role": "assistant",
                    "content": "你好！我是Aveline，很高兴为您服务。",
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }
        
        return {
            "status": "success",
            "data": conversation,
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取会话详情时出错, 请求ID: {request_id}, 会话ID: {conversation_id}, 错误: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "detail": "获取会话详情失败，请稍后再试",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(
    conversation_id: str = Path(..., regex="^[a-zA-Z0-9_-]{1,64}$", description="会话ID")
):
    """
    删除会话 - 增强版
    添加了会话ID验证、安全防护和事务性处理
    """
    # 生成请求ID
    request_id = str(uuid.uuid4())
    
    try:
        # 安全日志记录
        logger.info(f"删除会话请求, 请求ID: {request_id}, 会话ID: {conversation_id}")
        
        # 在实际应用中，这里应该:
        # 1. 验证用户是否有权限删除此会话
        # 2. 使用事务确保数据一致性
        # 3. 先检查会话是否存在
        
        # 模拟会话存在性检查
        if not conversation_id.startswith("conv_"):  # 简单的模拟检查
            return {
                "status": "error",
                "error_code": "NOT_FOUND",
                "detail": "会话不存在或已被删除",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        
        # 模拟删除操作
        # 在实际应用中，这里应该从数据库中删除会话及其相关消息
        logger.info(f"成功删除会话, 请求ID: {request_id}, 会话ID: {conversation_id}")
        
        return {
            "status": "success",
            "message": "会话已成功删除",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"删除会话时出错, 请求ID: {request_id}, 会话ID: {conversation_id}, 错误: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "detail": "删除会话失败，请稍后再试",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.delete("/memory/clear")
async def clear_memory():
    request_id = str(uuid.uuid4())
    try:
        base = _memory_dir()
        cleared = 0
        if os.path.isdir(base):
            for fn in os.listdir(base):
                fp = os.path.join(base, fn)
                try:
                    if os.path.isfile(fp):
                        os.remove(fp)
                        cleared += 1
                except Exception:
                    continue
        cache_cleared = 0
        try:
            svc = get_aveline_service()
            svc.cache_manager.clear()
            svc.response_cache = {}
            if hasattr(svc, '_cache'):
                try:
                    svc._cache.clear()
                except Exception:
                    pass
            if hasattr(svc, '_conversation_history'):
                try:
                    svc._conversation_history.clear()
                except Exception:
                    pass
            cache_cleared = 1
        except Exception:
            cache_cleared = 0
        return {
            "status": "success",
            "data": {"disk_files_cleared": cleared, "conversation_cache_cleared": bool(cache_cleared)},
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"清空记忆时出错: {e}")
        return {
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "detail": "清空记忆失败，请稍后再试",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.get("/memory/list")
async def memory_list():
    items = []
    base = _memory_dir()
    try:
        for fn in os.listdir(base):
            if fn.lower().endswith(".json"):
                p = os.path.join(base, fn)
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    mid = data.get("id") or os.path.splitext(fn)[0]
                    msgs = data.get("messages") or []
                    items.append({"id": mid, "messages": len(msgs), "path": f"output/memory/conversations/{fn}"})
                except Exception:
                    continue
    except Exception:
        pass
    return {"status": "success", "data": {"conversations": items}, "timestamp": datetime.now().isoformat()}


@router.get("/memory/history")
async def memory_history(conversation_id: str = Query(...)):
    p = os.path.join(_memory_dir(), f"{conversation_id}.json")
    if not os.path.exists(p):
        return {"status": "error", "error_code": "NOT_FOUND"}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {"status": "error", "error_code": "READ_ERROR"}
    return {"status": "success", "data": data, "timestamp": datetime.now().isoformat()}


@router.get("/models")
async def list_available_models(
    category: Optional[str] = Query(None, regex="^[a-zA-Z0-9_]{0,32}$", description="模型类别筛选")
):
    """
    获取可用的模型列表 - 增强版
    添加了类别筛选和安全检查
    """
    # 生成请求ID
    request_id = str(uuid.uuid4())
    
    try:
        # 安全日志记录
        logger.info(f"获取模型列表请求, 请求ID: {request_id}, 类别: {category or 'all'}")
        
        # 本地NF4 Transformers模型列表
        models = [
            {"id": "qwen", "name": "Qwen2.5-7B-Instruct NF4 (GPU)", "type": "transformers", "quant": "nf4", "path": "models/qwen/Qwen2___5-7B-Instruct", "status": "online"},
            {"id": "l3", "name": "L3-8B-Stheno-v3.2 NF4 (GPU)", "type": "transformers", "quant": "nf4", "path": "models/L3-8B-Stheno-v3.2", "status": "online"}
        ]
        
        # 如果指定了类别，进行筛选
        if category:
            models = [model for model in models if model.get("category") == category]
        
        return {
            "status": "success",
            "data": {
                "models": models,
                "total": len(models)
            },
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取模型列表时出错, 请求ID: {request_id}, 错误: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "detail": "获取模型列表失败，请稍后再试",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.post("/models/load")
async def load_model_endpoint(payload: Dict[str, Any] = Body(...)):
    request_id = str(uuid.uuid4())
    try:
        model_name = str(payload.get("model_name") or payload.get("id") or "").strip()
        if not model_name:
            return {
                "status": "error",
                "error_code": "INVALID_MODEL_NAME",
                "detail": "缺少模型名称",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        if model_name not in ("qwen", "l3"):
            return {"status": "error", "error_code": "UNSUPPORTED_MODEL", "detail": "仅支持qwen或l3", "request_id": request_id, "timestamp": datetime.now().isoformat()}
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        local_map = {
            "qwen": os.path.join(base, "models", "qwen", "Qwen2___5-7B-Instruct"),
            "l3": os.path.join(base, "models", "L3-8B-Stheno-v3.2")
        }
        chosen_path = local_map[model_name]
        try:
            os.environ["XIAOYOU_TEXT_MODEL_PATH"] = chosen_path
        except Exception:
            pass
        try:
            svc = get_aveline_service()
            svc.model_adapter.text_adapter.config.update({'model_type': 'transformers', 'text_model_path': chosen_path})
            new_name = f"text_transformers_{hash(chosen_path)}"
            svc.model_adapter.text_adapter.set_model_name(new_name)
            svc.model_adapter.text_adapter.load_model()
        except Exception:
            pass
        return {"status": "success", "data": {"loaded": True, "model_name": model_name, "path": chosen_path}, "request_id": request_id, "timestamp": datetime.now().isoformat()}
    except Exception as e:
        logger.error(f"加载模型失败: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "LOAD_FAILED",
            "detail": "模型加载失败",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.get("/models/status")
async def model_status(model_name: Optional[str] = Query(None)):
    request_id = str(uuid.uuid4())
    try:
        if not model_name:
            return {"status": "success", "data": {"loaded_models": ["qwen", "l3"]}, "request_id": request_id, "timestamp": datetime.now().isoformat()}
        return {"status": "success", "data": {"model_name": model_name, "loaded": model_name in ("qwen", "l3")}, "request_id": request_id, "timestamp": datetime.now().isoformat()}
    except Exception as e:
        logger.error(f"获取模型状态失败: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "STATUS_FAILED",
            "detail": "无法获取模型状态",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }


@router.post("/feedback")
async def submit_feedback(
    feedback: Dict[str, Any] = Body(
        ...,
        description="用户反馈内容",
        example={
            "type": "bug",  # bug, suggestion, feedback
            "rating": 5,     # 1-5
            "message": "反馈内容",
            "context": {"page": "chat", "model": "default"}
        }
    )
):
    """
    提交用户反馈 - 增强版
    添加了严格的输入验证和敏感信息过滤
    """
    # 生成请求ID
    request_id = str(uuid.uuid4())
    
    try:
        # 安全日志记录 - 先验证再记录
        logger.info(f"收到反馈请求, 请求ID: {request_id}")
        
        # 验证反馈数据
        # 1. 检查必需字段
        required_fields = ["message"]
        for field in required_fields:
            if field not in feedback or not feedback[field]:
                return {
                    "status": "error",
                    "error_code": "MISSING_FIELD",
                    "detail": f"缺少必需字段: {field}",
                    "request_id": request_id,
                    "timestamp": datetime.now().isoformat()
                }
        
        # 2. 验证反馈类型
        if "type" in feedback and feedback["type"] not in VALID_FEEDBACK_TYPES:
            return {
                "status": "error",
                "error_code": "INVALID_TYPE",
                "detail": "无效的反馈类型",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        
        # 3. 验证评分
        if "rating" in feedback:
            try:
                rating = int(feedback["rating"])
                if rating < 1 or rating > 5:
                    return {
                        "status": "error",
                        "error_code": "INVALID_RATING",
                        "detail": "评分必须在1-5之间",
                        "request_id": request_id,
                        "timestamp": datetime.now().isoformat()
                    }
            except ValueError:
                return {
                    "status": "error",
                    "error_code": "INVALID_RATING",
                    "detail": "评分必须是数字",
                    "request_id": request_id,
                    "timestamp": datetime.now().isoformat()
                }
        
        # 4. 限制消息长度
        message_length = len(feedback["message"])
        if message_length > MAX_FEEDBACK_LENGTH:
            return {
                "status": "error",
                "error_code": "MESSAGE_TOO_LONG",
                "detail": f"反馈内容过长，请控制在{MAX_FEEDBACK_LENGTH}字符以内",
                "request_id": request_id,
                "timestamp": datetime.now().isoformat()
            }
        
        # 过滤敏感信息
        filtered_feedback = feedback.copy()
        for field in SENSITIVE_FIELDS:
            if field in filtered_feedback:
                filtered_feedback[field] = "[REDACTED]"
        
        # 安全记录过滤后的反馈（不记录完整消息内容）
        logger.info(f"反馈已验证, 请求ID: {request_id}, 类型: {filtered_feedback.get('type', 'general')}, 长度: {message_length}")
        
        # 在实际应用中，这里应该将反馈保存到数据库
        # await feedback_service.save_feedback(filtered_feedback)
        
        return {
            "status": "success",
            "message": "感谢您的反馈，我们会认真处理",
            "feedback_id": f"fb_{uuid.uuid4()[:8]}",  # 生成反馈ID
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"处理反馈时出错, 请求ID: {request_id}, 错误: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "detail": "提交反馈失败，请稍后再试",
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
